# Workspace artifact removal regression

The backend and frontend fix is implemented. Production port 8000 was not restarted by this task; the parent task will verify the two original live sessions after its running jobs finish.

## Cause and behavior

The native-tool inventory scan only emitted `artifact.discovered` for new or changed files. Moving `outputs/report_payload.json` to `build/` left its Artifact database row intact, so the workspace continued offering a URL that returned 404.

The runtime now signals completed inventory scans. The service confirms each known output directly with the existing descriptor-safe `open_safe_file`; it never treats absence from the bounded scan as deletion. During execution, absence must occur at two consecutive tool boundaries. Temporary disappearance for one scan and truncating an existing file do not remove it. A final reconciliation runs after execution cleanup, and authenticated reads also reconcile legacy missing output records only for idle sessions.

Removal deletes only current output metadata and atomically appends `artifact.removed` with the previous artifact metadata. Historical creation/tool/message events remain. Authorization, output-path constraints, symlink checks, and safe file opening remain in force; access/path errors are not treated as evidence of absence. An unsafe or replaced output directory skips reconciliation rather than blocking terminal persistence or inventory reads. Uploads remain untouched.

The frontend consumes `artifact.removed`, removes the current workspace entry, closes its preview, and updates an already-open global file list without refetching it. Repeated removals, old connections, unrelated sessions, and history replay are covered.

## Evidence

- `backend-before.log`: five new assertions failed on the original behavior; the temporary-file case passed.
- `backend-after.log`: all eight new API/runtime regressions passed, including output-directory safety cases.
- `unsafe-directory-before.log`: two added tests first failed when output-directory replacement prevented terminal persistence; both passed after the conservative guard.
- `python-suite.log`: 215 tests passed before the two additional directory-safety tests; the parent task will run the final whole suite.
- `frontend/before`: the authored browser scenario failed because the removed file's preview remained open.
- `frontend/after`: the same Chromium scenario passed with no page errors. This uses authored API/SSE fixtures, not a live provider.
- `legacy-before.json`: preserves the original factory `9f7aa38a6f1c42b7a19dc06b97d0d984` and three-body `8373a90c254047419b8a7cf345dccf1a` artifact metadata for post-restart verification.

Frontend typecheck, preview, timeline and rendering suites passed. Ruff and diff whitespace checks passed. No commit or push was made.

## Changed files

- backend/app/runtime.py: completed scan signal and rediscovery after disappearance.
- backend/app/service.py: conservative live/terminal/idle reconciliation and durable removal events.
- backend/app/main.py: authorized idle reconciliation before inventory responses.
- backend/tests/test_artifact_removal.py and tests/test_artifact_scan.py: API and real-SDK regressions.
- frontend/src/lib/useRunStream.ts and useWorkspace.ts: removal event/state handling.
- frontend/src/App.tsx and components/Artifacts.tsx: update an already-open global file list.
- frontend/tests/artifact-removal.mjs: browser regression; parent added it to test:rendering.
