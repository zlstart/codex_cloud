# Docker sandbox setup

- Date: 2026-11-04 (UTC)
- Project: `/workspace/codex_cloud`
- Branch: `qa/complex-regression-20261104`
- Existing Docker daemon: 28.4.0, `vfs` storage driver, local Unix socket
- Image: `famsun-sandbox:latest`
- Image ID: `sha256:3586b7701f70dbe3d2ffae2a9d7c36912002c24a623fb51c7881535622d704f0`
- Image size: 752,346,599 bytes
- Image user: `1000:1000`

No daemon restart or project source edits were needed. The original build failed
because `/home/agent/.docker/buildx` is read-only. Setting only `BUILDX_CONFIG`
to a writable artifact directory resolved this; Docker config and credentials
remained unchanged. Docker operations require the execution tool's additional
network permission to reach the local Unix socket in this environment.

The existing platform proxy configuration was preserved. The system CA bundle
was supplied to pip through the Dockerfile's `proxy_ca` BuildKit secret. TLS
verification remained enabled, and the certificate was not copied into image
layers. Runtime probes mount the system bundle read-only and configure Python
trust settings for that mount.

## Rebuild

From `/workspace/codex_cloud`, using `with_additional_permissions` with network
enabled:

```bash
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS \
  -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  BUILDX_CONFIG=/workspace/qa-artifacts/environment/buildx \
  docker --host=unix:///var/run/docker.sock build --progress=plain \
  --secret id=proxy_ca,src=/etc/ssl/certs/ca-certificates.crt \
  -t famsun-sandbox:latest -f sandbox/Dockerfile sandbox
```

Build output: `docker-build.log`.

## Direct container smoke

`bash /workspace/qa-artifacts/environment/run-docker-mount-smoke.sh`

Result: PASS (`docker-mount-smoke.log`). Verified non-root execution, dropped
capabilities, read-only rootfs and `/workspace/uploads`, writable outputs,
absence of Docker socket and API keys, verified HTTPS access, Python dependency
imports, and Node/ripgrep/curl availability.

## Project SDK smoke

From `/workspace/codex_cloud`, using the same execution permission:

```bash
env -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  DOCKER_HOST=unix:///var/run/docker.sock PYTHONPATH=backend \
  FAMSUN_SANDBOX_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt \
  .venv/bin/python -u tests/docker_smoke.py
```

Output: `docker-sdk-smoke.log`. This suite calls no model.

Result: PASS, exit code 0. Verified native exec/patch/file/image/Skills, resource
limits, isolated chats, TLS-verified outbound HTTPS, persistent files, refreshed
skill staging, container removal, cancellation cleanup, and aggregate quota
enforcement.
