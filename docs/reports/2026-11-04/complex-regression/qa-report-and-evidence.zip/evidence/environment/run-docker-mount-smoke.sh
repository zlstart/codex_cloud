#!/usr/bin/env bash
set -euo pipefail
artifact_dir=/workspace/qa-artifacts/environment
probe_workspace="$artifact_dir/mount-smoke"
mkdir -p "$probe_workspace/uploads" "$probe_workspace/outputs"
printf 'read-only fixture\n' > "$probe_workspace/uploads/input.txt"
cp "$artifact_dir/docker-mount-probe.py" "$probe_workspace/probe.py"
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  docker --host=unix:///var/run/docker.sock run --rm \
  --name famsun-qa-mount-smoke --label famsun.qa=mount-smoke \
  --user 1000:1000 --read-only --cap-drop ALL --security-opt no-new-privileges:true \
  --memory 512m --memory-swap 512m --cpus 1 --pids-limit 64 \
  --tmpfs /tmp:rw,exec,nosuid,nodev,size=128m,mode=1777 \
  --mount "type=bind,src=$probe_workspace,dst=/workspace" \
  --mount "type=bind,src=$probe_workspace/uploads,dst=/workspace/uploads,readonly" \
  --mount type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/run/famsun-ca.pem,readonly \
  --env SSL_CERT_FILE=/run/famsun-ca.pem \
  --env REQUESTS_CA_BUNDLE=/run/famsun-ca.pem \
  --env PIP_CERT=/run/famsun-ca.pem \
  --env OPENBLAS_NUM_THREADS=1 --env OMP_NUM_THREADS=1 \
  famsun-sandbox:latest python /workspace/probe.py
test "$(cat "$probe_workspace/outputs/proof.txt")" = 'writable output verified'
