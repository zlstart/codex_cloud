import errno
import json
import os
import subprocess
import urllib.request
from pathlib import Path

import pandas
import matplotlib
import docx
import pptx
import reportlab

assert os.getuid() == 1000, os.getuid()
assert not os.getenv('AGENT_API_KEY') and not os.getenv('OPENAI_API_KEY')
assert not Path('/var/run/docker.sock').exists()
assert '0000000000000000' in next(
    line for line in Path('/proc/self/status').read_text().splitlines()
    if line.startswith('CapEff:')
)
assert Path('/workspace/uploads/input.txt').read_text() == 'read-only fixture\n'
for protected in ('/workspace/uploads/input.txt', '/usr/readonly-proof'):
    try:
        Path(protected).write_text('must fail')
    except OSError as exc:
        assert exc.errno in (errno.EROFS, errno.EACCES), (protected, str(exc))
    else:
        raise AssertionError(f'Protected path was writable: {protected}')
Path('/workspace/outputs/proof.txt').write_text('writable output verified\n')
assert Path('/workspace/outputs/proof.txt').read_text() == 'writable output verified\n'
with urllib.request.urlopen('https://example.com', timeout=30) as response:
    assert response.status == 200
for command in (['node', '--version'], ['rg', '--version'], ['curl', '--version']):
    subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
print(json.dumps({
    'status': 'PASS', 'uid': os.getuid(),
    'rootfs': 'readonly', 'uploads': 'readonly', 'outputs': 'writable',
    'capabilities': 'none', 'https': 'certificate verified',
    'python_dependencies': 'imported', 'tools': ['node', 'rg', 'curl']
}))
