"""Bounded real-provider probe; synthetic history only, no shell tool execution."""
import asyncio
import hashlib
import json
import os
import time
from collections import Counter
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from urllib.parse import urlsplit

from agents.sandbox.capabilities import Compaction, StaticCompactionPolicy
from openai import AsyncOpenAI

DEST = Path(__file__).parent
TOOL = {
    "type": "function", "name": "verify_memory", "description": "Verify remembered project facts.",
    "parameters": {"type": "object", "properties": {
        "project": {"type": "string"}, "release": {"type": "string"},
    }, "required": ["project", "release"], "additionalProperties": False}, "strict": True,
}


def seed(rows):
    filler = "\n".join(
        f"record {i}: synthetic operational note; inspection completed; quantity {i % 97}; "
        "warehouse north; all values are generated test data and carry no project facts."
        for i in range(rows)
    )
    return [
        {"role": "user", "content": "Remember project ALPHA-731. Release is initially release-17. "
         "These facts remain relevant; use the latest correction if any."},
        {"role": "assistant", "content": "I will retain these project facts."},
        {"type": "function_call", "name": "verify_memory", "arguments":
         '{"project":"ALPHA-731","release":"release-17"}', "call_id": "seed_call"},
        {"type": "function_call_output", "call_id": "seed_call", "output": filler},
        {"role": "assistant", "content": "Synthetic record inspection is complete."},
        {"role": "user", "content": "Correction: current release is release-42. Earlier release is obsolete."},
        {"role": "assistant", "content": "The release correction is recorded."},
        {"role": "user", "content": "Call verify_memory once using the remembered project and current release. "
         "Do not repeat the records. Do not invent missing facts."},
    ]


async def request(client, model, history, compaction, tool_choice):
    params = compaction.sampling_params({"model": model})
    started = time.monotonic()
    stream = await client.responses.create(
        model=model, input=history, store=False, stream=True, tools=[TOOL],
        tool_choice=tool_choice, max_output_tokens=1536, **params,
    )
    response = None
    event_types = Counter()
    stream_compaction_ids = []
    async with stream:
        async for event in stream:
            event_types[event.type] += 1
            item = getattr(event, "item", None)
            if getattr(item, "type", None) == "compaction":
                stream_compaction_ids.append(getattr(item, "id", None))
            if event.type in {"response.completed", "response.incomplete", "response.failed"}:
                response = event.response
    if response is None:
        raise RuntimeError("No terminal response event")
    output = [item.model_dump(exclude_none=True) for item in response.output]
    serialized = json.dumps(history, ensure_ascii=False).encode()
    record = {
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "response_id": response.id, "status": response.status,
        "request_context_management": params["context_management"],
        "input_item_count": len(history), "input_bytes": len(serialized),
        "input_sha256": hashlib.sha256(serialized).hexdigest(),
        "input_types": dict(Counter(item.get("type", item.get("role")) for item in history)),
        "usage": response.usage.model_dump() if response.usage else None,
        "output_types": [item["type"] for item in output],
        "compaction_item_count": sum(item["type"] == "compaction" for item in output),
        "stream_compaction_ids": sorted(set(stream_compaction_ids)),
        "events": dict(event_types), "output_text": response.output_text,
        "function_calls": [{key: item.get(key) for key in ("name", "arguments", "call_id")}
                           for item in output if item["type"] == "function_call"],
    }
    return output, record


async def main():
    model = os.environ["AGENT_MODEL"]
    base_url = os.environ["AGENT_BASE_URL"].rstrip("/").removesuffix("/responses")
    report = {
        "started_at": datetime.now(timezone.utc).isoformat(), "model": model,
        "provider_host": urlsplit(base_url).hostname,
        "agents_version": version("openai-agents"), "openai_version": version("openai"),
        "protocol": "Responses", "live_provider": True, "cases": [],
        "scope": "Direct provider probe using the installed SDK Compaction policy and process_context; "
                 "does not substitute for product Docker/UI testing.",
    }
    def save():
        (DEST / "live-provider-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    save()
    async with AsyncOpenAI(api_key=os.environ["AGENT_API_KEY"], base_url=base_url,
                           timeout=90, max_retries=0) as client:
        for threshold, rows in [(1024, 180), (32000, 1200)]:
            case = {"threshold": threshold, "synthetic_rows": rows, "responses": []}
            report["cases"].append(case)
            try:
                capability = Compaction(policy=StaticCompactionPolicy(threshold=threshold))
                history = seed(rows)
                output, record = await request(client, model, history, capability,
                                                {"type": "function", "name": "verify_memory"})
                case["responses"].append(record)
                calls = [item for item in output if item["type"] == "function_call"]
                case["facts_before_continuation"] = bool(calls) and all(
                    json.loads(call["arguments"]) == {"project": "ALPHA-731", "release": "release-42"}
                    for call in calls)
                history = capability.process_context(history + output)
                for call in calls:
                    history.append({"type": "function_call_output", "call_id": call["call_id"],
                                    "output": json.dumps({"valid": case["facts_before_continuation"]})})
                history.append({"role": "user", "content": "Continue after verification. Reply with only "
                                "the remembered project and current release as JSON; no tool needed."})
                output2, record2 = await request(client, model, history, capability, "none")
                case["responses"].append(record2)
                case["continuation_facts_retained"] = all(
                    fact in record2["output_text"] for fact in ("ALPHA-731", "release-42"))
                case["compaction_observed"] = any(r["compaction_item_count"] for r in case["responses"])
                case["compacted_continuation_verified"] = bool(record["compaction_item_count"]) and (
                    case["continuation_facts_retained"] and record2["status"] == "completed")
                case["threshold_exceeded_by_reported_input"] = any(
                    r["usage"] and r["usage"]["input_tokens"] > threshold for r in case["responses"])
            except Exception as exc:
                # Exception bodies may contain headers or request material. Do not persist them.
                case["error_type"] = type(exc).__name__
                case["http_status"] = getattr(exc, "status_code", None)
            save()
            print(json.dumps({k: v for k, v in case.items() if k != "responses"}), flush=True)
    report["completed_at"] = datetime.now(timezone.utc).isoformat()
    save()


if __name__ == "__main__":
    asyncio.run(main())
