"""Live application runtime, real Docker, isolated synthetic history; no API/UI mocks."""
import asyncio
import json
import os
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from agents import SQLiteSession
from openai import AsyncOpenAI

from app import runtime

DEST = Path(__file__).parent
ROOT = DEST / "runtime"


async def main():
    requests = []

    async def capture(request):
        if request.method == "POST" and request.url.path.endswith("/responses"):
            body = json.loads(request.content)
            items = body.get("input", [])
            requests.append({
                "context_management": body.get("context_management"),
                "input_item_count": len(items),
                "input_types": dict(Counter(item.get("type", item.get("role")) for item in items)),
                "has_original_project": "ALPHA-731" in json.dumps(items),
                "tool_calls": [item.get("call_id") for item in items
                               if item.get("type") in {"function_call", "custom_tool_call"}],
                "tool_outputs": [item.get("call_id") for item in items
                                 if item.get("type") in {"function_call_output", "custom_tool_call_output"}],
            })

    def client_factory(**kwargs):
        return AsyncOpenAI(**kwargs, http_client=httpx.AsyncClient(event_hooks={"request": [capture]}))

    runtime.AsyncOpenAI = client_factory
    config = runtime.RuntimeConfig(
        base_url=os.environ["AGENT_BASE_URL"].rstrip("/").removesuffix("/responses"),
        api_key=os.environ["AGENT_API_KEY"], model=os.environ["AGENT_MODEL"],
        state_dir=ROOT / "history", session_id="compactionqa", user_id="compactionqa",
        run_id="compactionqa1", compaction_threshold=1024, max_turns=6, max_runtime_seconds=180,
    )
    workspace = ROOT / "workspace"
    (workspace / "outputs").mkdir(parents=True, exist_ok=True)
    (workspace / "uploads").mkdir(parents=True, exist_ok=True)
    filler = "\n".join(f"Synthetic record {i}: inspected north warehouse, quantity {i % 89}; "
                       "generated QA data without additional project facts." for i in range(180))
    report = {
        "started_at": datetime.now(timezone.utc).isoformat(), "model": config.model,
        "provider_host": urlsplit(config.base_url).hostname, "live_provider": True,
        "sandbox": "real Docker through app.run_agent", "threshold": config.compaction_threshold,
        "runs": [], "requests": requests,
    }

    async def approval(*args):
        raise AssertionError("No external approvals expected")

    def save():
        (DEST / "live-runtime-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))

    inputs = [
        [{"role": "user", "content": "记住项目代号 ALPHA-731，旧版本 release-17。"},
         {"role": "assistant", "content": filler},
         {"role": "user", "content": "更新：当前版本为 release-42，旧版本已失效。无需工具，"
          "只用JSON回答已记住的项目代号和当前版本。"}],
        [{"role": "user", "content": "继续。先用 exec_command 执行 printf 'continuation-ready\\n'，"
          "确认成功后只用JSON给出先前记住的项目代号和当前版本。不要重新读取其他文件。"}],
    ]
    for index, messages in enumerate(inputs, 1):
        run = {"index": index, "events": []}
        report["runs"].append(run)

        async def emit(kind, data):
            run["events"].append({"type": kind, "data": data})
            save()

        started = time.monotonic()
        try:
            run["final_output"] = await runtime.run_agent(
                config=config, workspace=workspace, messages=messages, emit=emit,
                cancel_event=asyncio.Event(), request_approval=approval,
            )
            run["completed"] = True
            run["facts_retained"] = all(fact in run["final_output"]
                                         for fact in ("ALPHA-731", "release-42"))
        except Exception as exc:
            run["completed"] = False
            run["error_type"] = type(exc).__name__
        run["elapsed_seconds"] = round(time.monotonic() - started, 3)
        session = SQLiteSession("compactionqa:compactionqa", ROOT / "history/compactionqa/compactionqa.sqlite3")
        try:
            items = await session.get_items()
            run["persisted_types"] = dict(Counter(item.get("type", item.get("role")) for item in items))
            run["persisted_compaction_count"] = sum(item.get("type") == "compaction" for item in items)
        finally:
            session.close()
        save()
        print(json.dumps({key: value for key, value in run.items() if key != "events"}, ensure_ascii=False), flush=True)
        if not run["completed"]:
            break
    report["completed_at"] = datetime.now(timezone.utc).isoformat()
    save()


if __name__ == "__main__":
    asyncio.run(main())
