# 上下文压缩调查与修复（2026-11-04）

本报告针对 `/workspace/codex_cloud`、SDK `openai-agents 0.24.0` / `openai 3.41.0`。既有 Responses 协议及环境模型未改变；未输出或落盘 API 密钥。初版通用方案见 `/workspace/scratch/context-compaction-test-plan.md`。

## 已确认结论

1. 当前环境模型实际是 **DashScope `qwen3.8-flash`**。旧报告中的 `glm-5.3` 不是本次模型。
2. 真实服务接受 `context_management`，并成功完成超过配置阈值的请求，但本次 **7 个实际 Responses 响应均未返回 `type=compaction`**。没有证据证明当前服务已完成原生压缩；也不能仅凭本次观察断言它在任何配置下都不支持压缩。
3. 找到并修复一个独立的应用侧缺陷：**同一个 run 中接收 compaction 后，下一次工具往返仍发送压缩前历史**。既有测试仅覆盖新 run 重新加载历史，所以没有捕获它。
4. 原实现只在收到条目时展示 `context.compacted`，对“输入已超阈值，但未观察到压缩产物”没有状态。现新增脱敏 `context.status`，前端实时与回放展示由协作代理完成。

运行时长不决定阈值：等待工具不会自动增加输入 tokens；阈值触发由模型服务端负责。本轮没有访问用户之前的原始长会话，因此不把上述现象追溯断言为原会话的唯一原因。

## 真实服务证据

直接探针使用安装版本的 SDK `Compaction.sampling_params` 及 `process_context`，合成用户事实、历史工具结果与更正信息，实际调用现有服务。后续请求保留返回的真实工具调用与相同 `call_id` 的结果。

| 阈值 | 第一轮实际 input tokens | 后续实际 input tokens | compaction 条目 | 事实与工具继续 |
| --- | ---: | ---: | ---: | --- |
| 1,024 | 6,526 | 6,405 | 0 | 通过 |
| 默认 32,000 | 41,296 | 41,167 | 0 | 通过 |

- 脚本：`live_probe.py`；结果：`live-provider-results.json`。
- 检查事实为早期 `ALPHA-731` 及后来纠正后的 `release-42`，后续提问没有重述答案。
- 流式事件类型、响应 ID、输入结构/哈希、实际 usage、参数和输出类别均保存；推理正文及任何压缩密文不保存到诊断字段。
- token 轻微下降不能当压缩证据：两档第二轮请求依然携带完整旧历史，均无 compaction 产物。

另通过应用真实 `run_agent`、原生 Docker、SQLiteSession 完成两轮运行：第一轮建立历史，第二轮重新打开会话，实际执行原生 `exec_command` 的 `printf 'continuation-ready\n'`，退出码 0，随后正确回答早期事实和最新纠正。

| 应用运行 | 实际 input tokens | 阈值 | 新状态 | 持久化 compaction |
| --- | ---: | ---: | --- | ---: |
| 第一轮 | 10,775 | 1,024 | threshold_exceeded | 0 |
| 重开会话，发起工具 | 11,063 | 1,024 | threshold_exceeded | 0 |
| 工具返回后继续 | 11,171 | 1,024 | threshold_exceeded | 0 |

- 脚本：`runtime_probe.py`；结果：`live-runtime-results.json`。
- 请求钩子仅观测结构，没有替换服务返回或沙箱；模型命令在真实 Docker 中运行。
- native call/output IDs 相同，SQLite 中保留完整工具对；工作区与历史库分离。
- 这些是真实的**未压缩历史继续与新状态验证**，不冒充“压缩后事实保留”验收。
- 该真实 runtime 验证发生在观测修复之后、同 run 输入过滤修复之前；随后新增过滤修复由明确包含原生 compaction 条目的 SDK 协议回归验证。当前服务没有返回压缩条目，所以不能做真实压缩后语义质量验收。

## 应用修复与依据

### 同一次运行的压缩边界

新增协议场景先完成旧工具调用，再让 Responses 返回真实协议形状的 compaction + 两个新工具调用。修复前第三次请求仍含旧 `call_id=old`，断言失败；当时扩展测试结果为 `1 failed, 43 passed`。

安装 SDK 源码显示，sandbox input preparation 处理 run 的 original input；模型循环之后拼接本 run 的 generated items。原生 `Compaction.process_context` 因而未必能看到本 run 新产生的 compaction。

修复通过官方 `RunConfig.call_model_input_filter` 在每次完整模型请求上组合：

1. 既有 SDK `ToolOutputTrimmer`（相同配置，仍只负责旧工具输出预览）。
2. SDK `Compaction.process_context`（仅以已收到的最新 compaction item 为边界）。

不自写摘要、不虚构 compaction item、不改变模型、不降级 Chat Completions、不删除完整 SQLite 审计历史。新 run 和同 run 都采用 SDK 原生边界，压缩后的有效工具调用对及 instructions 保留。

### 观测事件

每个成功 `response.completed` 发出一次 `context.status`，按 response ID 与父工具调用 scope 去重：

```text
item_id, response_id, agent_id, agent_name, parent_call_id,
status: compacted | threshold_exceeded | not_observed,
input_tokens: integer | null, threshold: integer, compaction_count: integer
```

- `compacted` 必须有实际返回的 compaction item；token 降低或参数被接受均不算。
- `threshold_exceeded` 表示提供方报告的输入 tokens 大于阈值且无产物，不等于服务端内部计数必然相同，不直接宣判不支持。
- 缺 usage 记录 null，不捏造 0；密文、私有推理、请求正文和密钥不进入事件。
- 既有 `context.compacted` 保留；工具输出裁剪与语义压缩继续分开。

## 自动化覆盖与结果

针对性命令：

```bash
.venv/bin/pytest backend/tests/test_runtime_events.py tests/test_provider_protocol.py backend/tests/test_runtime_history.py -q
```

**44 passed**（见 `regression.log`），覆盖：

- 已报告输入在阈值下、等于、超过阈值和缺 usage 时的诚实状态；真实条目优先于 token 数判断。
- 同响应去重、不同 child 调用隔离、密文不泄露。
- 无产物时保留原始历史、不伪造成功。
- 收到 compaction 后同 run 中新工具调用/结果双向配对，旧工具对从后续请求移除。
- 再次压缩后重新打开 SQLite，仅使用最新 compaction 窗口。
- compaction 后提供方 400，重新打开会话仍保留可恢复的条目和完整工具对。
- 已有不支持参数、原生能力、委派、审批、持久化等回归。

这些协议回归使用真实 SDK 和 HTTP 测试替身，明确不计作真实供应商压缩支持。最初一次未给本地网络权限的测试进程卡住，已终止；带环境所需网络权限后运行完成。独立事件单测先观察到缺少新参数/行为的失败，再实现并通过。

完整 Python 回归 **209 passed in 10.43s**，见 `full-regression.log`；本任务所改 Python 文件 Ruff 与 `git diff --check` 已通过。主代理最终汇总若包含其他并行修复，以其最终检查结果为准。

## 官方资料与剩余边界

官方资料已下载为 `official-*.html`/`.txt`，并在项目 `docs/SDK-CAPABILITY-AUDIT.md` 记录所选 SDK primitive 与安装源码。

- https://openai.github.io/openai-agents-python/ref/sandbox/capabilities/compaction/
- https://openai.github.io/openai-agents-python/ref/run/
- https://openai.github.io/openai-agents-python/ref/extensions/tool_output_trimmer/
- https://developers.openai.com/api/docs/guides/compaction

当前实现没有公开的手动压缩入口，因此未发明手动 API。未验证真实 provider 压缩后语义保真、透明摘要质量、真实压缩产物跨服务重启及崩溃时事务恢复；本次 provider 没有产物，不能用协议测试或普通事实保留代替这些结论。也未探测替代模型或供应商。
