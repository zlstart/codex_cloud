import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { chromium } from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';

const root = '/workspace/test-report-2026-11-04';
const evidence = '/workspace/qa-artifacts/report-validation-final';
const html = await readFile(`${root}/report.html`, 'utf8');
const browser = await chromium.launch({executablePath:'/usr/bin/chromium', args:['--no-sandbox']});
const checks = {source:'Unmodified self-contained report.html, offline Chromium setContent', views:[], errors:[], remote_requests:[]};
try {
  const context = await browser.newContext({offline:true});
  const page = await context.newPage();
  page.on('pageerror', error => checks.errors.push(error.message));
  page.on('request', request => {
    if (/^https?:/.test(request.url())) checks.remote_requests.push(request.url());
  });
  for (const [name, width, height] of [['desktop',1440,1000],['mobile',390,844]]) {
    await page.setViewportSize({width,height});
    await page.setContent(html, {waitUntil:'load'});
    await page.locator('img').evaluateAll(async nodes => {
      for (const node of nodes) node.loading='eager';
      await Promise.all(nodes.map(node=>node.decode()));
    });
    const state=await page.evaluate(()=>({
      viewport:innerWidth, document:document.documentElement.scrollWidth,
      images:document.images.length,
      failed_images:Array.from(document.images).filter(node=>!node.naturalWidth).length,
      details:document.querySelectorAll('details').length,
      title:document.title,
    }));
    assert.ok(state.document<=state.viewport, `${name}: horizontal overflow`);
    assert.ok(state.images>10 && state.failed_images===0, `${name}: screenshot decoding`);
    assert.ok(state.details>30, `${name}: per-tool audit is present`);
    const first=page.locator('details').first();
    await first.locator('summary').click();
    assert.equal(await first.getAttribute('open'), '');
    await first.locator('summary').click();
    await page.evaluate(()=>scrollTo(0,0));
    await page.screenshot({path:`${evidence}/${name}.png`});
    checks.views.push({name,...state,expand_collapse:'passed'});
  }
  await page.setViewportSize({width:1440,height:1000});
  await page.emulateMedia({media:'print'});
  await page.pdf({path:`${root}/report.pdf`,format:'A4',printBackground:true,
    margin:{top:'12mm',bottom:'12mm',left:'10mm',right:'10mm'},
    displayHeaderFooter:true,headerTemplate:'<span></span>',
    footerTemplate:'<div style="font-size:8px;width:100%;text-align:center;color:#667">FAMSUN QA · 2026-11-04 · <span class="pageNumber"></span> / <span class="totalPages"></span></div>'});
  assert.equal(checks.errors.length,0,'report JavaScript errors');
  assert.equal(checks.remote_requests.length,0,'report makes no remote requests');
  checks.pdf='report.pdf (summary and screenshot edition; full expandable tool audit remains in HTML/results.json)';
  checks.result='passed';
} catch(error) {
  checks.result='failed';
  checks.failure=String(error);
  throw error;
} finally {
  await writeFile(`${evidence}/browser-checks.json`,JSON.stringify(checks,null,2)+'\n');
  await browser.close();
}
console.log(JSON.stringify(checks,null,2));
