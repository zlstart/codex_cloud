#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""三体问题数值模拟：二维牛顿引力 + 固定步长四阶 Runge-Kutta (RK4)。

物理模型（无量纲/正则化单位）：
    d^2 r_i / dt^2 = sum_{j != i} G * m_j * (r_j - r_i) / |r_j - r_i|^3
    G = 1, m1 = m2 = m3 = 1，不加软化因子（no softening）。

数值方法：经典 RK4，固定步长 dt = 1e-3，从 t = 0 积分到 t = 12.65（含端点）。
轨迹完全来自逐步积分，不使用任何参数化“8 字曲线”公式，也不使用外部轨迹数据。

运行方式：
    python3 outputs/simulate_three_body.py
依赖：numpy, matplotlib
产出：outputs/three_body.csv, outputs/metrics.json, outputs/three_body.png,
      outputs/three_body.html
"""
from __future__ import annotations

import datetime
import json
import math
import os
import sys

import numpy as np

# ----------------------------------------------------------------------------
# 配置：验收输入（见 uploads/..._three_body_seed.txt）
# ----------------------------------------------------------------------------
G = 1.0
MASS = np.array([1.0, 1.0, 1.0])
R0 = np.array(
    [
        [-0.97000436, 0.24308753],
        [0.97000436, -0.24308753],
        [0.0, 0.0],
    ]
)
V0 = np.array(
    [
        [0.466203685, 0.43236573],
        [0.466203685, 0.43236573],
        [-0.93240737, -0.86473146],
    ]
)
DT = 1.0e-3
T_START = 0.0
T_END = 12.65
SAMPLE_EVERY = 10              # 每 10 步导出一个样本
CONVERGENCE_FACTOR = 10         # 自检：用 dt/10 再积一次，比较同一批时刻
PRECISION = 9                   # CSV / HTML 数值保留的小数位数

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(OUT_DIR, "three_body.csv")
JSON_PATH = os.path.join(OUT_DIR, "metrics.json")
PNG_PATH = os.path.join(OUT_DIR, "three_body.png")
HTML_PATH = os.path.join(OUT_DIR, "three_body.html")

CSV_COLUMNS = [
    "t",
    "x1", "y1", "vx1", "vy1",
    "x2", "y2", "vx2", "vy2",
    "x3", "y3", "vx3", "vy3",
]


# ----------------------------------------------------------------------------
# 物理量
# ----------------------------------------------------------------------------
def acceleration(r: np.ndarray) -> np.ndarray:
    """二维牛顿引力加速度，无软化项。r: (3,2) -> (3,2)。"""
    diff = r[None, :, :] - r[:, None, :]          # diff[i, j] = r_j - r_i
    d2 = np.einsum("ijk,ijk->ij", diff, diff)     # |r_j - r_i|^2
    np.fill_diagonal(d2, np.inf)
    with np.errstate(divide="ignore", invalid="ignore"):
        inv_d3 = d2 ** (-1.5)
        coef = G * MASS[None, :] * inv_d3          # (3,3)，按列指标 j 取质量 m_j
        acc = (coef[..., None] * diff).sum(axis=1)
    if not np.all(np.isfinite(acc)):
        raise FloatingPointError("发生粒子重合（间距为 0），无软化模型下力发散")
    return acc


def derivative(r: np.ndarray, v: np.ndarray):
    return v, acceleration(r)


def rk4_step(r: np.ndarray, v: np.ndarray, dt: float):
    """经典四阶 Runge-Kutta 单步。"""
    k1r, k1v = derivative(r, v)
    k2r, k2v = derivative(r + 0.5 * dt * k1r, v + 0.5 * dt * k1v)
    k3r, k3v = derivative(r + 0.5 * dt * k2r, v + 0.5 * dt * k2v)
    k4r, k4v = derivative(r + dt * k3r, v + dt * k3v)
    rn = r + (dt / 6.0) * (k1r + 2.0 * k2r + 2.0 * k3r + k4r)
    vn = v + (dt / 6.0) * (k1v + 2.0 * k2v + 2.0 * k3v + k4v)
    return rn, vn


def energy(r: np.ndarray, v: np.ndarray) -> float:
    """总能量 E = 动能 + 势能（无软化）。"""
    ke = 0.5 * float(np.sum(MASS[:, None] * v * v))
    pe = 0.0
    n = r.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            pe -= G * MASS[i] * MASS[j] / float(np.linalg.norm(r[j] - r[i]))
    return ke + pe


def angular_momentum(r: np.ndarray, v: np.ndarray) -> float:
    """对原点的总角动量 z 分量 L = sum m_i (x_i v_yi - y_i v_xi)。"""
    return float(np.sum(MASS * (r[:, 0] * v[:, 1] - r[:, 1] * v[:, 0])))


def center_of_mass(r: np.ndarray) -> np.ndarray:
    return (MASS[:, None] * r).sum(axis=0) / float(MASS.sum())


def min_pair_distance(r: np.ndarray) -> float:
    n = r.shape[0]
    return min(
        float(np.linalg.norm(r[j] - r[i]))
        for i in range(n)
        for j in range(i + 1, n)
    )


# ----------------------------------------------------------------------------
# 积分主循环
# ----------------------------------------------------------------------------
def integrate(dt: float, n_steps: int, sample_every: int) -> dict:
    """固定步长 RK4 积分；返回导出样本 + 每一步的守恒量诊断序列。"""
    r = R0.copy()
    v = V0.copy()

    e0 = energy(r, v)
    l0 = angular_momentum(r, v)

    e_all, l_all, com_all, mind_all = [], [], [], []
    s_t, s_r, s_v = [], [], []

    for k in range(n_steps + 1):
        e_all.append(energy(r, v))
        l_all.append(angular_momentum(r, v))
        com_all.append(float(np.linalg.norm(center_of_mass(r))))
        mind_all.append(min_pair_distance(r))
        if k % sample_every == 0:
            s_t.append(T_START + k * dt)
            s_r.append(r.copy())
            s_v.append(v.copy())
        if k < n_steps:
            r, v = rk4_step(r, v, dt)
        if not (np.all(np.isfinite(r)) and np.all(np.isfinite(v))):
            raise FloatingPointError(f"第 {k} 步出现非有限数值，积分发散")

    return {
        "dt": dt,
        "n_steps": n_steps,
        "sample_every": sample_every,
        "t": np.asarray(s_t),
        "r": np.asarray(s_r),        # (nsample, 3, 2)
        "v": np.asarray(s_v),
        "e_all": np.asarray(e_all),
        "l_all": np.asarray(l_all),
        "com_all": np.asarray(com_all),
        "mind_all": np.asarray(mind_all),
        "e0": e0,
        "l0": l0,
    }


def sample_energy(run: dict) -> np.ndarray:
    return np.array([energy(r, v) for r, v in zip(run["r"], run["v"])])


def diagnostics(run: dict) -> dict:
    """由逐步诊断序列计算守恒量误差（覆盖全部积分步，不只是导出样本）。"""
    e_all, l_all, dt = run["e_all"], run["l_all"], run["dt"]
    e0, l0 = run["e0"], run["l0"]
    rel_e = np.abs(e_all - e0) / abs(e0)
    abs_l = np.abs(l_all - l0)
    ie = int(np.argmax(rel_e))
    imin = int(np.argmin(run["mind_all"]))
    return {
        "initial_energy": float(e0),
        "final_energy": float(e_all[-1]),
        "max_relative_energy_error": float(rel_e.max()),
        "max_relative_energy_error_time": float(T_START + ie * dt),
        "initial_angular_momentum": float(l0),
        "final_angular_momentum": float(l_all[-1]),
        "max_absolute_angular_momentum_error": float(abs_l.max()),
        "max_center_of_mass_norm": float(run["com_all"].max()),
        "minimum_pair_distance": float(run["mind_all"].min()),
        "minimum_pair_distance_time": float(T_START + imin * dt),
        "max_relative_energy_error_at_samples": float(
            np.abs(sample_energy(run) - e0).max() / abs(e0)
        ),
    }


# ----------------------------------------------------------------------------
# 自检：收敛性 + CSV 是否真的满足运动方程
# ----------------------------------------------------------------------------
def validate(run: dict, fine: dict) -> dict:
    # 1) 同一批时刻上的轨迹差异（dt 与 dt/10）
    n = min(len(run["t"]), len(fine["t"]))
    dpos = float(np.linalg.norm(run["r"][:n] - fine["r"][:n], axis=2).max())
    dvel = float(np.linalg.norm(run["v"][:n] - fine["v"][:n], axis=2).max())

    # 2) 导出样本是否满足 ODE：中心差分 dv/dt 对比由位置算出的加速度
    t, r, v = run["t"], run["r"], run["v"]
    hs = float(t[1] - t[0])
    dvdt = (v[2:] - v[:-2]) / (2.0 * hs)
    acc = np.array([acceleration(ri) for ri in r[1:-1]])
    resid = float(np.abs(dvdt - acc).max())

    # 3) 总动量守恒（初值总动量应几乎不变）
    p0 = (MASS[:, None] * V0).sum(axis=0)
    pend = (MASS[:, None] * run["v"][-1]).sum(axis=0)

    return {
        "rk4_reference_dt": fine["dt"],
        "rk4_reference_steps": int(fine["n_steps"]),
        "max_position_diff_vs_dt_over_10": dpos,
        "max_velocity_diff_vs_dt_over_10": dvel,
        "ode_residual_max_abs_dvdt_minus_accel": resid,
        "ode_residual_note": "中心差分步长为样本间隔 %.3g，残差含截断误差" % hs,
        "initial_total_momentum": [float(p0[0]), float(p0[1])],
        "final_total_momentum": [float(pend[0]), float(pend[1])],
        "max_abs_momentum_drift": float(np.abs(pend - p0).max()),
    }


def recurrence(run: dict) -> dict:
    """状态相对初值的偏离（相空间，按样本），用于检查轨道的准回归特性。"""
    dr = np.linalg.norm(run["r"] - R0, axis=2).max(axis=1)
    dv = np.linalg.norm(run["v"] - V0, axis=2).max(axis=1)
    dev = np.maximum(dr, dv)
    dev[0] = np.inf
    k = int(np.argmin(dev))
    return {
        "min_state_deviation_from_initial": float(dev[k]),
        "min_state_deviation_time": float(run["t"][k]),
        "state_deviation_at_t_end": float(dev[-1]),
        "note": "该初值对应近似 8 字族周期轨道，偏离极小处即准回归时刻",
    }


# ----------------------------------------------------------------------------
# 输出：CSV / metrics.json
# ----------------------------------------------------------------------------
def write_csv(run: dict) -> int:
    t = np.round(run["t"], PRECISION)
    r = np.round(run["r"], PRECISION)
    v = np.round(run["v"], PRECISION)
    lines = [",".join(CSV_COLUMNS)]
    for i in range(len(t)):
        vals = [t[i],
                r[i, 0, 0], r[i, 0, 1], v[i, 0, 0], v[i, 0, 1],
                r[i, 1, 0], r[i, 1, 1], v[i, 1, 0], v[i, 1, 1],
                r[i, 2, 0], r[i, 2, 1], v[i, 2, 0], v[i, 2, 1]]
        lines.append(",".join(f"{float(x):.{PRECISION}f}" for x in vals))
    with open(CSV_PATH, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(lines) - 1


def build_payload(run: dict) -> str:
    """与 CSV 完全相同的采样数据（同样按 9 位小数取整），供 HTML 内嵌。"""
    t = np.round(run["t"], PRECISION)
    r = np.round(run["r"], PRECISION)
    v = np.round(run["v"], PRECISION)
    rows = []
    for i in range(len(t)):
        rows.append([
            float(t[i]),
            float(r[i, 0, 0]), float(r[i, 0, 1]), float(v[i, 0, 0]), float(v[i, 0, 1]),
            float(r[i, 1, 0]), float(r[i, 1, 1]), float(v[i, 1, 0]), float(v[i, 1, 1]),
            float(r[i, 2, 0]), float(r[i, 2, 1]), float(v[i, 2, 0]), float(v[i, 2, 1]),
        ])
    payload = {
        "columns": CSV_COLUMNS,
        "dt": DT,
        "sampleStrideSteps": SAMPLE_EVERY,
        "sampleInterval": float(SAMPLE_EVERY * DT),
        "tStart": T_START,
        "tEnd": T_END,
        "rows": rows,
    }
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)


def write_metrics(diag: dict, chk: dict, sample_count: int, run: dict) -> dict:
    metrics = {
        "G": G,
        "masses": [float(m) for m in MASS],
        "method": "fixed-step RK4 (classical 4th-order Runge-Kutta, no softening)",
        "dimension": 2,
        "dt": DT,
        "t_start": T_START,
        "t_end": T_END,
        "steps": int(run["n_steps"]),
        "sample_stride_steps": SAMPLE_EVERY,
        "sample_interval": float(SAMPLE_EVERY * DT),
        "sample_count": int(sample_count),
        "initial_positions": [[float(x), float(y)] for x, y in R0],
        "initial_velocities": [[float(vx), float(vy)] for vx, vy in V0],
        "initial_energy": diag["initial_energy"],
        "final_energy": diag["final_energy"],
        "max_relative_energy_error": diag["max_relative_energy_error"],
        "max_relative_energy_error_at_samples": diag["max_relative_energy_error_at_samples"],
        "max_relative_energy_error_time": diag["max_relative_energy_error_time"],
        "initial_angular_momentum": diag["initial_angular_momentum"],
        "final_angular_momentum": diag["final_angular_momentum"],
        "max_absolute_angular_momentum_error": diag["max_absolute_angular_momentum_error"],
        "max_center_of_mass_norm": diag["max_center_of_mass_norm"],
        "minimum_pair_distance": diag["minimum_pair_distance"],
        "minimum_pair_distance_time": diag["minimum_pair_distance_time"],
        "units": "无量纲（正则化）单位：G=1，m=1；长度与时间由初始条件给定",
        "diagnostics_coverage": "守恒量误差按全部 %d 个积分步统计（非仅导出样本）" % run["n_steps"],
        "validation": chk,
        "csv": "three_body.csv",
        "plot": "three_body.png",
        "animation": "three_body.html",
        "generator": os.path.basename(__file__),
        "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
    }
    with open(JSON_PATH, "w", encoding="utf-8") as fh:
        json.dump(metrics, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    return metrics


def check_outputs(metrics: dict, sample_count: int) -> None:
    """交付前的硬性自检：样本数、表头、首末行必须与初值/终值一致。"""
    assert sample_count >= 1000, f"样本数不足: {sample_count}"
    with open(CSV_PATH, encoding="utf-8") as fh:
        header = fh.readline().strip()
    assert header == ",".join(CSV_COLUMNS), f"CSV 列名不符: {header}"
    data = np.genfromtxt(CSV_PATH, delimiter=",", names=True)
    assert len(data) == sample_count, "CSV 行数与样本数不符"
    assert math.isclose(float(data["t"][0]), T_START, abs_tol=1e-12)
    assert math.isclose(float(data["t"][-1]), T_END, abs_tol=1e-12)
    for i in range(3):
        assert math.isclose(float(data[f"x{i+1}"][0]), R0[i, 0], abs_tol=1e-9)
        assert math.isclose(float(data[f"y{i+1}"][0]), R0[i, 1], abs_tol=1e-9)
        assert math.isclose(float(data[f"vx{i+1}"][0]), V0[i, 0], abs_tol=1e-9)
        assert math.isclose(float(data[f"vy{i+1}"][0]), V0[i, 1], abs_tol=1e-9)
    for key in (
        "G", "masses", "method", "dt", "t_start", "t_end", "sample_count",
        "initial_positions", "initial_velocities", "initial_energy",
        "max_relative_energy_error", "initial_angular_momentum",
        "max_absolute_angular_momentum_error", "max_center_of_mass_norm",
        "minimum_pair_distance",
    ):
        assert key in metrics, f"metrics.json 缺少字段 {key}"


# ----------------------------------------------------------------------------
# 输出：PNG 轨迹图
# ----------------------------------------------------------------------------
def make_figure(run: dict, diag: dict, sample_count: int) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.font_manager as fm
    import matplotlib.pyplot as plt

    available = {f.name for f in fm.fontManager.ttflist}
    for family in ("Noto Sans CJK SC", "WenQuanYi Zen Hei", "DejaVu Sans"):
        if family in available:
            plt.rcParams["font.family"] = family
            break
    plt.rcParams["axes.unicode_minus"] = False

    t, r = run["t"], run["r"]
    colors = ["#d62728", "#1f77b4", "#2ca02c"]
    names = ["星 1 (m=1)", "星 2 (m=1)", "星 3 (m=1)"]

    fig = plt.figure(figsize=(10.5, 8.2), dpi=150)
    ax = fig.add_axes([0.06, 0.09, 0.76, 0.80])
    for i in range(3):
        ax.plot(r[:, i, 0], r[:, i, 1], color=colors[i], lw=1.5, alpha=0.9, label=names[i])
        ax.plot(R0[i, 0], R0[i, 1], marker="o", mfc="none", mec=colors[i], ms=11, mew=2)
        ax.annotate(
            "%s 初值\nr=(%+.8f, %+.8f)\nv=(%+.9f, %+.8f)"
            % (names[i], R0[i, 0], R0[i, 1], V0[i, 0], V0[i, 1]),
            xy=(R0[i, 0], R0[i, 1]),
            xytext=(16, -4 - 30 * i),
            textcoords="offset points",
            fontsize=7.4,
            color=colors[i],
        )
        ax.plot(r[-1, i, 0], r[-1, i, 1], marker="*", ms=13, color=colors[i])

    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(True, ls=":", alpha=0.45)
    ax.axhline(0.0, color="k", lw=0.6, alpha=0.5)
    ax.axvline(0.0, color="k", lw=0.6, alpha=0.5)
    ax.set_xlabel("位置 x（无量纲单位：G = 1，m = 1）")
    ax.set_ylabel("位置 y（无量纲单位）")
    ax.set_title(
        "三体问题数值模拟轨迹（二维牛顿引力，固定步长 RK4，dt = 1e-3，0 ≤ t ≤ 12.65）",
        fontsize=12,
    )
    ax.legend(loc="upper left", fontsize=9, framealpha=0.9)

    info = (
        "成果来自逐步数值积分（非参数化曲线、非三体通解）\n"
        "积分步数 = %d，导出样本 = %d（每 %d 步一个）\n"
        "初值能量 E0 = %.12f\n"
        "最大相对能量误差 = %.3e\n"
        "初值角动量 L0 = %.3e\n"
        "最大 |ΔL| = %.3e\n"
        "最大 |质心偏离| = %.3e\n"
        "最小两星间距 = %.6f\n"
        "标记：圆环 = 初值位置，星形 = 末值位置 (t = 12.65)"
    ) % (
        run["n_steps"], sample_count, SAMPLE_EVERY,
        diag["initial_energy"], diag["max_relative_energy_error"],
        diag["initial_angular_momentum"], diag["max_absolute_angular_momentum_error"],
        diag["max_center_of_mass_norm"], diag["minimum_pair_distance"],
    )
    ax.text(
        0.985, 0.02, info, transform=ax.transAxes, ha="right", va="bottom",
        fontsize=8.0,
        bbox=dict(boxstyle="round,pad=0.5", fc="#f7f7f7", ec="#999", alpha=0.94),
    )

    # 能量相对误差随时间（对数坐标），佐证轨迹来自真实积分
    axin = fig.add_axes([0.855, 0.13, 0.125, 0.28])
    rel_e = np.abs(run["e_all"] - run["e0"]) / abs(run["e0"])
    axin.plot(T_START + np.arange(len(rel_e)) * run["dt"], rel_e, color="#7b4f9d", lw=1.1)
    axin.set_yscale("log")
    axin.set_xlabel("t", fontsize=7)
    axin.set_ylabel("|ΔE|/|E0|", fontsize=7)
    axin.tick_params(labelsize=6)
    axin.grid(True, ls=":", alpha=0.4)
    axin.set_title("能量相对误差", fontsize=7.5)

    fig.savefig(PNG_PATH)
    plt.close(fig)


# ----------------------------------------------------------------------------
# 输出：自包含 HTML 动画（模板见 HTML_TEMPLATE）
# ----------------------------------------------------------------------------
def write_html(run: dict, metrics: dict) -> int:
    html = (
        HTML_TEMPLATE
        .replace("__DATA_JSON__", build_payload(run))
        .replace("__METRICS_JSON__", json.dumps(metrics, ensure_ascii=False, separators=(",", ":")))
        .replace("__GENERATED__", metrics["generated_at_utc"])
    )
    with open(HTML_PATH, "w", encoding="utf-8") as fh:
        fh.write(html)
    return len(html)


def main() -> int:
    n_steps = int(round((T_END - T_START) / DT))
    if abs(T_START + n_steps * DT - T_END) > 1e-12:
        raise ValueError(f"dt 无法整除积分区间: n_steps={n_steps}")

    print(f"[1/5] RK4 主积分：dt={DT}，{n_steps} 步（t=0..{T_END}，含端点）")
    run = integrate(DT, n_steps, SAMPLE_EVERY)
    print(f"      导出样本 {len(run['t'])} 个（每 {SAMPLE_EVERY} 步）")

    fine_steps = n_steps * CONVERGENCE_FACTOR
    print(f"[2/5] 收敛性自检：dt={DT / CONVERGENCE_FACTOR}，{fine_steps} 步（同批时刻对比）")
    fine = integrate(DT / CONVERGENCE_FACTOR, fine_steps, SAMPLE_EVERY * CONVERGENCE_FACTOR)

    diag = diagnostics(run)
    chk = validate(run, fine)
    chk.update(recurrence(run))

    print("[3/5] 写出 CSV 与 metrics.json")
    sample_count = write_csv(run)
    metrics = write_metrics(diag, chk, sample_count, run)

    print("[4/5] 写出 PNG 轨迹图")
    make_figure(run, diag, sample_count)

    print("[5/5] 写出自包含 HTML 动画")
    html_size = write_html(run, metrics)

    check_outputs(metrics, sample_count)

    print("\n===== 结果摘要 =====")
    print(f"样本数: {sample_count}  (t=0 与 t={T_END} 均已包含)")
    print(f"E0 = {diag['initial_energy']:.12f}   E(t_end) = {diag['final_energy']:.12f}")
    print(f"最大相对能量误差 = {diag['max_relative_energy_error']:.6e}")
    print(f"导出样本上的最大相对能量误差 = {diag['max_relative_energy_error_at_samples']:.6e}")
    print(f"L0 = {diag['initial_angular_momentum']:.12e}")
    print(f"最大 |ΔL| = {diag['max_absolute_angular_momentum_error']:.6e}")
    print(f"max |COM| = {diag['max_center_of_mass_norm']:.6e}")
    print(f"最小两星间距 = {diag['minimum_pair_distance']:.8f} @ t={diag['minimum_pair_distance_time']:.3f}")
    print(f"与 dt/10 参考解最大位置偏差 = {chk['max_position_diff_vs_dt_over_10']:.3e}")
    print(f"运动方程残差(中心差分) = {chk['ode_residual_max_abs_dvdt_minus_accel']:.3e}")
    print(f"状态回归：t={chk['min_state_deviation_time']:.3f} 时与初值最大偏离 {chk['min_state_deviation_from_initial']:.3e}")
    print(f"HTML 大小 = {html_size / 1024:.1f} KB")
    return 0


# ----------------------------------------------------------------------------
# HTML 动画模板：完全自包含，不引用任何外部资源（可离线直接打开）
# ----------------------------------------------------------------------------
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>三体数值模拟动画（RK4 真实积分结果）</title>
<style>
:root{
  --bg:#080d1a; --panel:#111a2e; --panel2:#0d1524; --ink:#e9eefb; --muted:#9db0d0;
  --line:#25324f; --accent:#3ea6ff;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  background:var(--bg); color:var(--ink); line-height:1.6; -webkit-text-size-adjust:100%;
  font-family:"Noto Sans CJK SC","PingFang SC","Hiragino Sans GB","Microsoft YaHei",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
}
header{padding:18px 16px 6px;max-width:1200px;margin:0 auto}
h1{font-size:20px;margin:0 0 6px}
h2{font-size:15px;margin:0 0 8px;color:var(--accent)}
.sub{margin:0;color:var(--muted);font-size:13px}
main{max-width:1200px;margin:0 auto;padding:12px 16px 28px;display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:14px;align-items:start}
.stage{grid-column:1;position:relative;background:var(--panel2);border:1px solid var(--line);border-radius:14px;overflow:hidden}
#cv{display:block;width:100%;aspect-ratio:1/1;touch-action:pan-y}
.hud{position:absolute;left:10px;top:10px;background:rgba(8,13,26,.72);border:1px solid var(--line);border-radius:10px;padding:8px 10px;font-size:12.5px;line-height:1.5;pointer-events:none}
.hud b{color:var(--accent);font-variant-numeric:tabular-nums}
.hud .state{color:#ffc53d}
.controls{grid-column:1;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px}
.btns{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:10px}
button{font:inherit;font-size:15px;min-height:44px;min-width:104px;padding:8px 18px;border-radius:999px;border:1px solid var(--line);background:#18233c;color:var(--ink);cursor:pointer}
button:hover{border-color:var(--accent)}
button.primary{background:var(--accent);border-color:var(--accent);color:#04101f;font-weight:700}
.inline{display:flex;gap:8px;align-items:center;font-size:13px;color:var(--muted)}
select{font:inherit;min-height:38px;background:#18233c;color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:4px 8px}
.sliderbox{margin-top:4px}
.sliderbox label{display:block;font-size:13.5px;margin-bottom:6px;font-variant-numeric:tabular-nums}
#tslider{width:100%;height:34px;accent-color:var(--accent);touch-action:pan-y;cursor:pointer}
.ticks{display:flex;justify-content:space-between;font-size:11.5px;color:var(--muted)}
.checks{display:flex;flex-wrap:wrap;gap:14px;margin-top:8px;font-size:13px;color:var(--muted)}
.info{grid-column:2;grid-row:1 / span 2;display:flex;flex-direction:column;gap:12px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th,td{text-align:left;padding:4px 6px;border-bottom:1px solid #1b2740;vertical-align:top}
th{color:var(--muted);font-weight:600;white-space:nowrap}
td{font-variant-numeric:tabular-nums;word-break:break-all}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px}
.note{font-size:12.5px;color:var(--muted);margin:0}
.warn{border-left:3px solid #ffc53d;padding-left:10px}
footer{max-width:1200px;margin:0 auto;padding:0 16px 24px;color:var(--muted);font-size:12px}
@media (max-width:900px){
  main{grid-template-columns:minmax(0,1fr);padding:10px 12px 24px}
  .stage,.controls,.info{grid-column:1}
  .info{grid-row:auto}
  h1{font-size:18px}
  .hud{font-size:11px;padding:6px 8px}
}
</style>
</head>
<body>
<header>
<h1>三体问题数值模拟动画（特定初值 · RK4 真实积分）</h1>
<p class="sub">二维牛顿引力，G = 1，m₁ = m₂ = m₃ = 1；固定步长四阶 Runge–Kutta，dt = 0.001，t ∈ [0, 12.65]（含端点），不加软化项。动画内嵌数据与 three_body.csv 的同批采样点完全一致。</p>
</header>
<main>
<section class="stage">
  <canvas id="cv" aria-label="三体运动轨迹动画画布"></canvas>
  <div class="hud" id="hud"></div>
</section>

<section class="controls">
  <div class="btns">
    <button id="toggle" class="primary" aria-label="暂停或继续动画">暂停</button>
    <button id="reset" aria-label="重置到 t=0 并暂停">重置</button>
    <span class="inline">播放速度
      <select id="speed" aria-label="播放速度">
        <option value="0.25">0.25×</option>
        <option value="0.5">0.5×</option>
        <option value="1" selected>1×</option>
        <option value="2">2×</option>
        <option value="4">4×</option>
      </select>
    </span>
  </div>
  <div class="sliderbox">
    <label for="tslider" id="tlabel">模拟时间 t（拖动滑块可定位）</label>
    <input id="tslider" type="range" min="0" max="1" step="1" value="0" aria-label="模拟时间 t 滑块，拖动可定位到任意采样时刻">
    <div class="ticks"><span>t = 0.000</span><span id="tickmid"></span><span id="tickend"></span></div>
  </div>
  <div class="checks">
    <label><input type="checkbox" id="showAll" checked> 显示全程轨迹（淡色参考）</label>
    <label><input type="checkbox" id="showVel"> 显示速度矢量</label>
    <label><input type="checkbox" id="showGrid" checked> 显示坐标网格</label>
  </div>
</section>

<aside class="info">
  <div class="card">
    <h2>初始条件</h2>
    <table id="tinit"></table>
    <p class="note" style="margin-top:8px">初值总动量 Σm·v = <span id="tmom"></span>（理想为 0），因此质心保持静止。</p>
  </div>
  <div class="card">
    <h2>数值方法与设置</h2>
    <table id="tmeth"></table>
  </div>
  <div class="card">
    <h2>守恒量误差（真实积分统计）</h2>
    <table id="tcons"></table>
    <p class="note" style="margin-top:8px">误差按全部积分步统计；画面左上角同时显示当前时刻的实时守恒量。</p>
  </div>
  <div class="card">
    <h2>收敛性与自检</h2>
    <table id="tval"></table>
  </div>
  <div class="card note warn">
    <h2>说明</h2>
    <p class="note">本页展示的是<b>这一组给定初值</b>下逐步数值积分得到的三体运动（轨道近似“8 字”族解，但每个坐标都由 RK4 积分产生，未使用任何参数化曲线公式），<b>不是三体问题的通解</b>：换一组初值就会得到完全不同的运动，且三体问题不存在一般的封闭解析解。页面不加载任何外部资源，可离线直接打开。</p>
  </div>
</aside>
</main>
<footer>数据与图表由 simulate_three_body.py 生成 · 生成时间（UTC）：__GENERATED__</footer>

<script>
'use strict';
const DATA = __DATA_JSON__;
const METRICS = __METRICS_JSON__;
const ROWS = DATA.rows, N = ROWS.length;
const GC = METRICS.G, MASS = METRICS.masses;
const COLS = ['#e5484d', '#3ea6ff', '#ffc53d'];
const NAMES = ['星 1', '星 2', '星 3'];
const E0 = METRICS.initial_energy, L0 = METRICS.initial_angular_momentum;
const WALL_SECONDS = 40;

function px(row, i){ return row[1 + 4 * i]; }
function py(row, i){ return row[2 + 4 * i]; }
function vx(row, i){ return row[3 + 4 * i]; }
function vy(row, i){ return row[4 + 4 * i]; }

function energyOf(row){
  let ke = 0, pe = 0;
  for (let i = 0; i < 3; i++) ke += 0.5 * MASS[i] * (vx(row, i) * vx(row, i) + vy(row, i) * vy(row, i));
  for (let i = 0; i < 3; i++) for (let j = i + 1; j < 3; j++) {
    const d = Math.hypot(px(row, j) - px(row, i), py(row, j) - py(row, i));
    pe -= GC * MASS[i] * MASS[j] / d;
  }
  return ke + pe;
}
function angOf(row){
  let l = 0;
  for (let i = 0; i < 3; i++) l += MASS[i] * (px(row, i) * vy(row, i) - py(row, i) * vx(row, i));
  return l;
}
function comOf(row){
  let x = 0, y = 0, m = 0;
  for (let i = 0; i < 3; i++) { x += MASS[i] * px(row, i); y += MASS[i] * py(row, i); m += MASS[i]; }
  return Math.hypot(x, y) / m;
}
function minPairOf(row){
  let best = Infinity;
  for (let i = 0; i < 3; i++) for (let j = i + 1; j < 3; j++)
    best = Math.min(best, Math.hypot(px(row, j) - px(row, i), py(row, j) - py(row, i)));
  return best;
}

// 前缀统计：显示“到目前为止”的守恒量极值
const preMinPair = new Float64Array(N);
const acc = { d: Infinity };
for (let i = 0; i < N; i++) {
  acc.d = Math.min(acc.d, minPairOf(ROWS[i]));
  preMinPair[i] = acc.d;
}

// 视野范围（含边距），x/y 使用同一比例
let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
for (const r of ROWS) for (let i = 0; i < 3; i++) {
  minX = Math.min(minX, px(r, i)); maxX = Math.max(maxX, px(r, i));
  minY = Math.min(minY, py(r, i)); maxY = Math.max(maxY, py(r, i));
}
const pad = 0.10 * Math.max(maxX - minX, maxY - minY);
minX -= pad; maxX += pad; minY -= pad; maxY += pad;

const cv = document.getElementById('cv'), ctx = cv.getContext('2d');
const hud = document.getElementById('hud');
const slider = document.getElementById('tslider'), tlabel = document.getElementById('tlabel');
const btnToggle = document.getElementById('toggle'), btnReset = document.getElementById('reset');
const sel = document.getElementById('speed');
const cbAll = document.getElementById('showAll'), cbVel = document.getElementById('showVel'), cbGrid = document.getElementById('showGrid');
slider.max = String(N - 1);

const state = { idx: 0, playing: true, dragging: false, speed: 1 };
let W = 0, H = 0;

function resize(){
  const rect = cv.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  W = Math.max(1, Math.round(rect.width)); H = Math.max(1, Math.round(rect.height));
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resize);

function fit(){
  const s = Math.min(W / (maxX - minX), H / (maxY - minY));
  const ox = (W - s * (maxX - minX)) / 2, oy = (H - s * (maxY - minY)) / 2;
  return { s: s, x: function (wx) { return ox + s * (wx - minX); },
             y: function (wy) { return H - oy - s * (wy - minY); } };
}

function rowAt(f){
  const i0 = Math.max(0, Math.min(N - 1, Math.floor(f)));
  const i1 = Math.min(N - 1, i0 + 1), a = Math.max(0, Math.min(1, f - i0));
  const A = ROWS[i0], B = ROWS[i1], out = new Array(13);
  for (let c = 0; c < 13; c++) out[c] = A[c] + (B[c] - A[c]) * a;
  return out;
}

function niceStep(span){
  const raw = span / 6;
  const cand = [0.1, 0.2, 0.25, 0.5, 1, 2, 5, 10];
  for (const c of cand) if (c >= raw) return c;
  return 20;
}

function drawGrid(T){
  const st = niceStep(Math.max(maxX - minX, maxY - minY));
  ctx.font = '11px sans-serif';
  for (let x = Math.ceil(minX / st) * st; x <= maxX; x += st) {
    const X = T.x(x);
    ctx.strokeStyle = (Math.abs(x) < 1e-9) ? 'rgba(157,176,208,.5)' : 'rgba(120,150,200,.16)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(X, 0); ctx.lineTo(X, H); ctx.stroke();
    ctx.fillStyle = 'rgba(157,176,208,.75)'; ctx.textAlign = 'center';
    ctx.fillText(x.toFixed(2), X, H - 4);
  }
  for (let y = Math.ceil(minY / st) * st; y <= maxY; y += st) {
    const Y = T.y(y);
    ctx.strokeStyle = (Math.abs(y) < 1e-9) ? 'rgba(157,176,208,.5)' : 'rgba(120,150,200,.16)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, Y); ctx.lineTo(W, Y); ctx.stroke();
    ctx.fillStyle = 'rgba(157,176,208,.75)'; ctx.textAlign = 'left';
    ctx.fillText(y.toFixed(2), 4, Y - 3);
  }
}

function drawPath(T, i, upto, alpha, width, endRow){
  ctx.beginPath();
  ctx.strokeStyle = COLS[i]; ctx.globalAlpha = alpha; ctx.lineWidth = width; ctx.lineJoin = 'round';
  for (let k = 0; k <= upto; k++) {
    const X = T.x(px(ROWS[k], i)), Y = T.y(py(ROWS[k], i));
    if (k === 0) ctx.moveTo(X, Y); else ctx.lineTo(X, Y);
  }
  if (endRow) ctx.lineTo(T.x(px(endRow, i)), T.y(py(endRow, i)));
  ctx.stroke(); ctx.globalAlpha = 1;
}

function draw(){
  const T = fit();
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#070c17'; ctx.fillRect(0, 0, W, H);
  if (cbGrid.checked) drawGrid(T);

  const i0 = Math.max(0, Math.min(N - 1, Math.floor(state.idx)));
  const row = rowAt(state.idx);
  if (cbAll.checked) for (let i = 0; i < 3; i++) drawPath(T, i, N - 1, 0.13, 1, null);
  for (let i = 0; i < 3; i++) drawPath(T, i, i0, 0.85, 2, row);
  for (let i = 0; i < 3; i++) {           // 初值位置标记
    const X = T.x(px(ROWS[0], i)), Y = T.y(py(ROWS[0], i));
    ctx.strokeStyle = COLS[i]; ctx.globalAlpha = 0.5; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(X, Y, 7, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 0.85; ctx.fillStyle = COLS[i]; ctx.font = '11px sans-serif'; ctx.textAlign = 'left';
    ctx.fillText(NAMES[i] + ' 初值', X + 10, Y - 9);
    ctx.globalAlpha = 1;
  }

  const rad = Math.max(6, Math.min(14, T.s * 0.022));
  for (let i = 0; i < 3; i++) {           // 运动星体
    const X = T.x(px(row, i)), Y = T.y(py(row, i));
    const g = ctx.createRadialGradient(X, Y, 0, X, Y, rad * 3.2);
    g.addColorStop(0, COLS[i]); g.addColorStop(0.35, COLS[i]); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = 0.5; ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(X, Y, rad * 3.2, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1; ctx.fillStyle = COLS[i];
    ctx.beginPath(); ctx.arc(X, Y, rad, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = '#0b1220'; ctx.stroke();
    ctx.fillStyle = '#0b1220'; ctx.font = 'bold ' + Math.round(rad) + 'px sans-serif';
    ctx.textAlign = 'center'; ctx.fillText(String(i + 1), X, Y + rad * 0.36);
    if (cbVel.checked) {
      const ux = vx(row, i), uy = -vy(row, i), n = Math.hypot(ux, uy) || 1, L = rad * 3.4;
      ctx.strokeStyle = COLS[i]; ctx.globalAlpha = 0.9; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X + ux / n * L, Y + uy / n * L); ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }
  ctx.textAlign = 'left';

  const e = energyOf(row), l = angOf(row);
  hud.innerHTML =
    't = <b>' + row[0].toFixed(3) + '</b> / ' + METRICS.t_end.toFixed(2) + '<br>' +
    '样本 <b>' + (i0 + 1) + '</b> / ' + N + '<br>' +
    'E(t) = <b>' + e.toFixed(8) + '</b><br>' +
    '|ΔE|/|E₀| = <b>' + (Math.abs(e - E0) / Math.abs(E0)).toExponential(2) + '</b><br>' +
    '|ΔL| = <b>' + Math.abs(l - L0).toExponential(2) + '</b><br>' +
    '|质心偏离| = <b>' + comOf(row).toExponential(2) + '</b><br>' +
    '至今最小间距 = <b>' + preMinPair[i0].toFixed(4) + '</b><br>' +
    '状态：<span class="state">' + (state.playing ? '播放中' : (i0 >= N - 1 ? '已到终点（暂停）' : '已暂停')) + '</span>';
}

function syncSlider(){
  const i0 = Math.max(0, Math.min(N - 1, Math.round(state.idx)));
  if (document.activeElement !== slider) slider.value = String(i0);
  tlabel.textContent = '模拟时间 t = ' + ROWS[i0][0].toFixed(3) + '（第 ' + (i0 + 1) + '/' + N +
    ' 个样本，样本间隔 ' + DATA.sampleInterval.toFixed(3) + '）— 拖动滑块定位';
}

function syncToggle(){
  btnToggle.textContent = state.playing ? '暂停' : '继续';
}

let last = performance.now();
function loop(now){
  const dtms = Math.min(now - last, 100); last = now;
  if (state.playing && !state.dragging) {
    state.idx += (dtms / 1000) * ((N - 1) / WALL_SECONDS) * state.speed;
    if (state.idx >= N - 1) { state.idx = N - 1; state.playing = false; syncToggle(); }
    syncSlider();
  }
  draw();
  requestAnimationFrame(loop);
}

btnToggle.addEventListener('click', function () {
  if (!state.playing && state.idx >= N - 1) state.idx = 0;   // 已到终点后点“继续”则重新播放
  state.playing = !state.playing;
  syncToggle(); syncSlider();
});
btnReset.addEventListener('click', function () {
  state.idx = 0; state.playing = false; state.dragging = false;
  slider.value = '0'; syncToggle(); syncSlider(); draw();
});
sel.addEventListener('change', function () { state.speed = parseFloat(sel.value); });
slider.addEventListener('input', function () { state.idx = parseFloat(slider.value); syncSlider(); draw(); });
slider.addEventListener('pointerdown', function () { state.dragging = true; });
window.addEventListener('pointerup', function () { state.dragging = false; });
slider.addEventListener('change', function () { state.dragging = false; });
[cbAll, cbVel, cbGrid].forEach(function (cb) { cb.addEventListener('change', draw); });

// 侧栏表格
function fill(tbl, list){
  document.getElementById(tbl).innerHTML = list.map(function (kv) {
    return '<tr><th>' + kv[0] + '</th><td>' + kv[1] + '</td></tr>';
  }).join('');
}
function sci(x){ return Number(x).toExponential(3); }
function pair(v){ return '(' + v[0].toFixed(8) + ', ' + v[1].toFixed(8) + ')'; }

const initRows = [];
for (let i = 0; i < 3; i++) {
  initRows.push(['<span class="dot" style="background:' + COLS[i] + '"></span>' + NAMES[i] + ' 位置 r', pair(METRICS.initial_positions[i])]);
  initRows.push([NAMES[i] + ' 速度 v', pair(METRICS.initial_velocities[i])]);
}
fill('tinit', initRows);

let pmx = 0, pmy = 0;
for (let i = 0; i < 3; i++) { pmx += MASS[i] * METRICS.initial_velocities[i][0]; pmy += MASS[i] * METRICS.initial_velocities[i][1]; }
document.getElementById('tmom').textContent = '(' + pmx.toExponential(2) + ', ' + pmy.toExponential(2) + ')';

fill('tmeth', [
  ['积分方法', METRICS.method],
  ['模型', '二维牛顿引力（' + METRICS.dimension + ' 维，无软化项，质点间距离平方反比）'],
  ['G / 质量', 'G = ' + METRICS.G + '，m = [' + METRICS.masses.join(', ') + ']'],
  ['步长 dt', METRICS.dt],
  ['时间区间', '[' + METRICS.t_start + ', ' + METRICS.t_end + ']（含端点）'],
  ['积分步数', METRICS.steps],
  ['导出规则', '每 ' + METRICS.sample_stride_steps + ' 步导出 1 个样本'],
  ['样本数', METRICS.sample_count + '（含 t = 0 初值与 t = 12.65 终值）'],
  ['单位', METRICS.units]
]);

fill('tcons', [
  ['初值能量 E₀', E0.toFixed(12)],
  ['末值能量 E(t_end)', METRICS.final_energy.toFixed(12)],
  ['最大相对能量误差', sci(METRICS.max_relative_energy_error)],
  ['误差极值时刻', 't = ' + METRICS.max_relative_energy_error_time.toFixed(3)],
  ['初值角动量 L₀', L0.toFixed(12)],
  ['最大 |ΔL|', sci(METRICS.max_absolute_angular_momentum_error)],
  ['最大 |质心偏离|', sci(METRICS.max_center_of_mass_norm)],
  ['最小两星间距', METRICS.minimum_pair_distance.toFixed(6) + '（t = ' + METRICS.minimum_pair_distance_time.toFixed(3) + '）']
]);

fill('tval', [
  ['参考解', 'dt/10 = ' + METRICS.validation.rk4_reference_dt + '（' + METRICS.validation.rk4_reference_steps + ' 步）'],
  ['最大位置偏差', sci(METRICS.validation.max_position_diff_vs_dt_over_10)],
  ['最大速度偏差', sci(METRICS.validation.max_velocity_diff_vs_dt_over_10)],
  ['运动方程残差', sci(METRICS.validation.ode_residual_max_abs_dvdt_minus_accel)],
  ['总动量漂移', sci(METRICS.validation.max_abs_momentum_drift)],
  ['状态回归检查', 't = ' + METRICS.validation.min_state_deviation_time.toFixed(3) + ' 时与初值最大偏离 ' + sci(METRICS.validation.min_state_deviation_from_initial)],
  ['统计范围', METRICS.diagnostics_coverage]
]);

document.getElementById('tickmid').textContent = 't = ' + (METRICS.t_end / 2).toFixed(2);
document.getElementById('tickend').textContent = 't = ' + METRICS.t_end.toFixed(2);

resize(); syncSlider(); syncToggle(); draw();
requestAnimationFrame(loop);
</script>
</body>
</html>
"""


if __name__ == "__main__":
    sys.exit(main())