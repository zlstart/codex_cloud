勘误已完成，只新建一个文件，未做任何积分或数值重算。

**交付链接**
- [three_body.csv](outputs/three_body.csv)
- [metrics.json](outputs/metrics.json)
- [three_body_final.html](outputs/three_body_final.html)
- [three_body_final.png](outputs/three_body_final.png)
- [convergence_final.json](outputs/convergence_final.json)

**勘误结果**
- 唯一差异路径：`/conclusion/practical_verdict`，顶层字段名与顺序完全一致，三档 dt（0.001、0.0005、0.00025）、比较时刻数组与全部数值原样保留
- 修正内容：8.8081e-12 是 h=0.001 与 h/2=0.0005 之差，5.8616e-13 是 h/2=0.0005 与 h/4=0.00025 之差；删去原句中不正确的相对尺度描述；保留 CSV 9 位小数约 5e-10 的舍入本底说明，并结论 dt=0.001 对给定初值与 t 到 12.65 时程足够

**数据状态**
- 1266 个等间隔样本（每 10 步一个，间隔 0.01，含 t=0 初值与 t=12.65 终值），来自二维牛顿引力的固定步长 RK4 真实逐步积分，非三体问题通解，也未使用任何参数化 8 字曲线
- 原有文件哈希保持不变：three_body.csv `7a9f3803cf84`、metrics.json `469d3485bbff`、three_body.html `3130f206b046`、three_body.png `723c8b1f5634`、simulate_three_body.py `40dec7d31fc0`、convergence.json `a93eb61e14fb`