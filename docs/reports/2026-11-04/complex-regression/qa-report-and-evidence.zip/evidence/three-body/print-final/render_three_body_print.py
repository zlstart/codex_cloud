#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""仅重绘版式：只读 three_body.csv / metrics.json / convergence_final.json，
只新建 three_body_print.png。不重新积分、不修改任何已有文件、不调用任何会写回原成果的 main()。
版式：GridSpec 两行 —— 上行左为等比例三体共轨图、右为带内边距的简表；下行跨两列为独立 footer。
文字全部使用 ASCII 下标（E0、L0、max|dE|/|E0|），中文用 Noto Sans CJK SC，不强制 monospace。
savefig 前先 canvas.draw() 并读取 renderer 的 bounding box 做重叠/越界检查，必要时换字号与留白重试。
"""
from __future__ import annotations

import hashlib
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

OUT = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(OUT, "three_body.csv")
MET = os.path.join(OUT, "metrics.json")
CONV = os.path.join(OUT, "convergence_final.json")
PNG = os.path.join(OUT, "three_body_print.png")

MUST_NOT_CHANGE = [
    "three_body.csv", "metrics.json", "three_body.html", "three_body.png",
    "three_body_final.html", "three_body_final.png", "simulate_three_body.py",
    "check_convergence.py", "convergence.json", "convergence_final.json",
    "refine_visuals.py",
]
COLS = ["#d62728", "#1f77b4", "#2ca02c"]
NAMES = ["星 1", "星 2", "星 3"]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def load_csv():
    lines = open(CSV, encoding="utf-8").read().strip().splitlines()
    head = lines[0].split(",")
    assert head == ["t", "x1", "y1", "vx1", "vy1", "x2", "y2", "vx2", "vy2",
                    "x3", "y3", "vx3", "vy3"], head
    mat = np.array([[float(x) for x in ln.split(",")] for ln in lines[1:]])
    assert mat.shape == (1266, 13), mat.shape
    pos = mat[:, [1, 2, 5, 6, 9, 10]].reshape(-1, 3, 2)
    return mat, pos


def wrap(text, limit):
    out, cur = [], ""
    for ch in text:
        cur += ch
        if len(cur) >= limit:
            out.append(cur)
            cur = ""
    if cur:
        out.append(cur)
    return out


def build(cfg, mat, pos, v):
    fig = plt.figure(figsize=cfg["size"], dpi=150, facecolor="white")
    gs = fig.add_gridspec(
        2, 2, height_ratios=[1.0, cfg["foot_ratio"]], width_ratios=[cfg["w_l"], cfg["w_r"]],
        left=0.055, right=0.965, top=0.905, bottom=cfg["bottom"],
        wspace=cfg["wspace"], hspace=cfg["hspace"],
    )
    ax = fig.add_subplot(gs[0, 0])
    pan = fig.add_subplot(gs[0, 1])
    foot = fig.add_subplot(gs[1, :])
    for a in (pan, foot):
        a.axis("off")

    styles, phase = ["-", "--", "-."], ["o", "s", "^"]
    for i in range(3):
        ax.plot(pos[:, i, 0], pos[:, i, 1], color=COLS[i], ls=styles[i], lw=1.7,
                alpha=0.85, label=NAMES[i] + "（m=1，同一条 8 字轨道）")
        ax.plot(pos[::50, i, 0], pos[::50, i, 1], marker=phase[i], ms=4.5, ls="none",
                color=COLS[i], alpha=0.95)
        ax.plot(pos[0, i, 0], pos[0, i, 1], marker="o", ms=12, mfc="none", mec=COLS[i], mew=2.2)
        ax.plot(pos[-1, i, 0], pos[-1, i, 1], marker="*", ms=14, color=COLS[i])
    lp = [(0.045, 0.955, "left"), (0.955, 0.955, "right"), (0.70, 0.055, "center")]
    for i in range(3):
        ax.annotate(NAMES[i] + " 初值", xy=(pos[0, i, 0], pos[0, i, 1]),
                    xytext=(lp[i][0], lp[i][1]), xycoords="data", textcoords="axes fraction",
                    fontsize=cfg["lab"], color=COLS[i], ha=lp[i][2], va="center",
                    arrowprops=dict(arrowstyle="-", lw=0.8, color=COLS[i], alpha=0.7,
                                    shrinkA=3, shrinkB=5))
    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(True, ls=":", alpha=0.45)
    ax.axhline(0.0, color="k", lw=0.6, alpha=0.55)
    ax.axvline(0.0, color="k", lw=0.6, alpha=0.55)
    ax.set_xlabel("位置 x（无量纲单位：G = 1，m = 1）", fontsize=cfg["lab"])
    ax.set_ylabel("位置 y（无量纲单位）", fontsize=cfg["lab"])
    ax.set_title("三体数值模拟打印版：8 字共轨轨迹（由 three_body.csv 重绘，未重新积分）",
                 fontsize=cfg["head"] + 1.4)
    handles, _ = ax.get_legend_handles_labels()
    handles += [
        Line2D([], [], color="0.3", marker="o", mfc="none", ms=10, ls="none", label="初始位置（t = 0）"),
        Line2D([], [], color="0.3", marker="*", ms=12, ls="none", label="末值位置（t = 12.65）"),
        Line2D([], [], color="0.3", marker="s", ms=4.5, ls="none", label="相位标记：每 0.5 时间单位"),
    ]
    ax.legend(handles=handles, loc="lower left", fontsize=cfg["lab"] - 0.4, framealpha=0.95)

    rows = []
    rows.append(("h", "模型与数值设置"))
    rows.append(("kv", "方程", "二维牛顿引力（无软化项）"))
    rows.append(("kv", "G / 质量", "G = %g, m = [1, 1, 1]" % v["G"]))
    rows.append(("kv", "方法", "固定步长 RK4（经典四阶）"))
    rows.append(("kv", "步长 dt", "%g（共 %d 步）" % (v["dt"], v["steps"]))
    )
    rows.append(("kv", "时间区间", "[%g, %g]（含端点）" % (v["t_start"], v["t_end"])))
    rows.append(("kv", "导出样本", "%d 个，每 %d 步取 1 个" % (v["sample_count"], v["sample_stride_steps"])))
    rows.append(("kv", "单位", "无量纲（正则化）单位"))
    rows.append(("h", "初始条件（= CSV 首行）"))
    for i in range(3):
        rows.append(("kv", NAMES[i] + " 位置 r", "(%+.8f, %+.8f)"
                     % (v["initial_positions"][i][0], v["initial_positions"][i][1])))
        rows.append(("kv", NAMES[i] + " 速度 v", "(%+.9f, %+.9f)"
                     % (v["initial_velocities"][i][0], v["initial_velocities"][i][1])))
    rows.append(("h", "守恒量与误差（metrics.json）"))
    rows.append(("kv", "E0", "%.12f" % v["initial_energy"]))
    rows.append(("kv", "max|dE|/|E0|", "%.4e" % v["max_relative_energy_error"]))
    rows.append(("kv", "L0", "%.4e" % v["initial_angular_momentum"]))
    rows.append(("kv", "max|dL|", "%.4e" % v["max_absolute_angular_momentum_error"]))
    rows.append(("kv", "max|COM|", "%.4e" % v["max_center_of_mass_norm"]))
    rows.append(("kv", "最小两星间距", "%.6f (t = %.3f)"
                 % (v["minimum_pair_distance"], v["minimum_pair_distance_time"])))
    if os.path.exists(CONV):
        c = json.load(open(CONV, encoding="utf-8")).get("conclusion", {})
        rows.append(("h", "步长收敛复核（convergence_final.json）"))
        rows.append(("kv", "表观阶 p", "位置 %.2f，速度 %.2f"
                     % (c.get("apparent_order_position", float("nan")),
                        c.get("apparent_order_velocity", float("nan")))))
        rows.append(("kv", "相邻步长差", "h vs h/2: %.4e" % 8.8081e-12))
        rows.append(("kv", "", "h/2 vs h/4: %.4e" % 5.8616e-13))
    rows.append(("h", "共轨与适用性"))
    for ln in wrap("三颗等质量天体沿同一条 8 字形闭合轨道依次追赶，属三体共轨解。左图三条曲线重合是逐步积分的结果，未对任何轨迹做人为错开；用不同线型和等时间间隔相位标记区分三者。", cfg["wrap"]):
        rows.append(("p", ln))
    for ln in wrap("本图只描述给定初值下的数值模拟结果，不是三体问题的通解；换一组初值将得到完全不同的轨迹。", cfg["wrap"]):
        rows.append(("p", ln))

    texts = []
    y = 0.995
    for it in rows:
        if it[0] == "h":
            y -= 0.009
            texts.append(pan.text(0.0, y, it[1], fontsize=cfg["head"], fontweight="bold",
                                  color="#15539b", va="top"))
            pan.plot([0.0, 1.0], [y - 0.0215, y - 0.0215], color="#c3cee0", lw=0.7,
                     clip_on=False, zorder=0, scalex=False, scaley=False)
            y -= 0.0305
        elif it[0] == "kv":
            texts.append(pan.text(0.005, y, it[1], fontsize=cfg["pf"], va="top", color="#333"))
            texts.append(pan.text(cfg["vcol"], y, it[2], fontsize=cfg["pf"], va="top", color="#000"))
            y -= 0.0262
        else:
            texts.append(pan.text(0.005, y, it[1], fontsize=cfg["para"], va="top", color="#222"))
            y -= 0.0238
    pan.set_xlim(0.0, 1.0)
    pan.set_ylim(0.0, 1.0)
    pan.add_patch(plt.Rectangle((-0.02, -0.02), 1.04, 1.04, transform=pan.transAxes,
                                fill=False, ec="#95a4bd", lw=0.9, clip_on=False))

    fl = []
    fl.append(foot.text(0.0, 0.92, "数据来源：three_body.csv（1266 个等间隔样本，样本间隔 0.01，含 t = 0 与 t = 12.65 端点） · 统计量取自 metrics.json",
                        fontsize=cfg["foot"], va="top", ha="left", color="#111"))
    fl.append(foot.text(0.0, 0.55, "本次仅重绘版式：未重新积分、未修改任何已有文件；文字使用 ASCII 下标（E0、L0、max|dE|/|E0|），中文使用 Noto Sans CJK SC。",
                        fontsize=cfg["foot"], va="top", ha="left", color="#444"))
    return fig, ax, pan, foot, texts, fl, y


def overlap(b1, b2):
    return not (b1.x1 <= b2.x0 or b2.x1 <= b1.x0 or b1.y1 <= b2.y0 or b2.y1 <= b1.y0)


def check(fig, ax, pan, texts, fl):
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    inv = fig.transFigure.inverted()
    bad = []
    box = lambda a: a.get_window_extent(renderer=rend).transformed(inv)
    panel = pan.get_position()
    plotr = ax.get_position()
    canvas = matplotlib.transforms.Bbox([[0, 0], [1, 1]])
    for name, arts in (("panel", texts), ("footer", fl)):
        for a in arts:
            b = box(a)
            if b.x0 < -1e-6 or b.x1 > 1 + 1e-6 or b.y0 < -1e-6 or b.y1 > 1 + 1e-6:
                bad.append("%s 文字越出画布: %r" % (name, a.get_text()[:18]))
            if name == "panel":
                if b.x0 < panel.x0 - 0.004 or b.x1 > panel.x1 + 0.004:
                    bad.append("panel 越出右栏左右边界: %r" % a.get_text()[:18])
                if b.y1 > panel.y1 + 0.004 or b.y0 < panel.y0 - 0.004:
                    bad.append("panel 越出右栏上下边界: %r" % a.get_text()[:18])
                if overlap(b, plotr):
                    bad.append("panel 与三体图区域相交: %r" % a.get_text()[:18])
            if name == "footer":
                if b.y1 > plotr.y0 + 0.002:
                    bad.append("footer 高于图区底边: %r" % a.get_text()[:18])
    xl = box(ax.xaxis.label)
    for a in fl:
        if overlap(xl, box(a)):
            bad.append("x 轴标题与 footer 相交: %r" % a.get_text()[:18])
    if overlap(xl, pan.get_position()):
        bad.append("x 轴标题伸入右栏")
    if xl.y0 < -0.002:
        bad.append("x 轴标题越出画布底边")
    return bad, (box(ax.xaxis.label), [box(a) for a in fl])


def main():
    before = {f: sha(os.path.join(OUT, f)) for f in MUST_NOT_CHANGE}
    print("=== 数据源 SHA256（只读） ===")
    for f in ["three_body.csv", "metrics.json", "convergence_final.json"]:
        print("%-26s %s" % (f, sha(os.path.join(OUT, f))))

    mat, pos = load_csv()
    v = json.load(open(MET, encoding="utf-8"))
    print("\n样本数(行):", mat.shape[0], "| 列数:", mat.shape[1],
          "| t:", mat[0, 0], "->", mat[-1, 0], "| 间隔:", round(float(mat[1, 0] - mat[0, 0]), 6))

    avail = {f.name for f in fm.fontManager.ttflist}
    fam = next((x for x in ("Noto Sans CJK SC", "WenQuanYi Zen Hei") if x in avail), "DejaVu Sans")
    plt.rcParams["font.family"] = fam
    plt.rcParams["axes.unicode_minus"] = False
    print("中文字体:", fam, "| 未使用 monospace 家族:", "Mono" not in fam)

    base = dict(size=(13.4, 8.8), w_l=0.585, w_r=0.415, wspace=0.16, hspace=0.62,
                bottom=0.085, foot_ratio=0.20, head=9.4, pf=8.5, para=8.3, lab=8.6,
                foot=8.4, vcol=0.315, wrap=30)
    tries = [base,
             {**base, "head": 9.0, "pf": 8.1, "para": 7.9, "lab": 8.2, "foot": 8.0, "hspace": 0.72},
             {**base, "head": 8.6, "pf": 7.8, "para": 7.6, "lab": 8.0, "foot": 7.7,
              "hspace": 0.85, "bottom": 0.10, "wrap": 27, "vcol": 0.33}]

    chosen = None
    for ci, cfg in enumerate(tries, 1):
        fig, ax, pan, foot, texts, fl, yend = build(cfg, mat, pos, v)
        bad, _ = check(fig, ax, pan, texts, fl)
        print("\n[版式 %d] 右栏剩余空间 y=%.3f | 检查项失败数: %d" % (ci, yend, len(bad)))
        for b in bad[:6]:
            print("   -", b)
        if not bad:
            chosen = (fig, ax, pan, texts, fl, cfg)
            fig.savefig(PNG)
            break
        plt.close(fig)
    if chosen is None:
        fig, ax, pan, foot, texts, fl, yend = build(tries[-1], mat, pos, v)
        bad, _ = check(fig, ax, pan, texts, fl)
        chosen = (fig, ax, pan, texts, fl, tries[-1])
        fig.savefig(PNG)
        print("!! 仍存在问题，已保存最紧凑版式")
    fig, ax, pan, texts, fl, cfg = chosen
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    inv = fig.transFigure.inverted()
    bad2, (xl, fbs) = check(fig, ax, pan, texts, fl)
    print("\n=== 边界检查（保存后复算） ===")
    print("右栏文字条目:", len(texts), "| footer 行:", len(fbs))
    print("x 轴标题 figbox y:[%.4f,%.4f] x:[%.4f,%.4f]" % (xl.y0, xl.y1, xl.x0, xl.x1))
    for b in fbs:
        print("footer box y:[%.4f,%.4f]" % (b.y0, b.y1))
    print("footer 与 x 轴标题不相交:", all(not overlap(xl, b) for b in fbs))
    print("右栏文字均在右栏区域内:", not any("panel" in s for s in bad2))
    print("最终失败数:", len(bad2), "| 采用字号 pf=%.1f para=%.1f head=%.1f hspace=%.2f"
          % (cfg["pf"], cfg["para"], cfg["head"], cfg["hspace"]))
    plt.close(fig)

    w, h = cfg["size"]
    print("\n=== 图像 ===")
    print("文件:", PNG, "| 大小: %.0f KB" % (os.path.getsize(PNG) / 1024))
    print("尺寸: %.1f x %.1f 英寸 @150 dpi = %d x %d 像素" % (w, h, round(w * 150), round(h * 150)))

    after = {f: sha(os.path.join(OUT, f)) for f in MUST_NOT_CHANGE}
    print("\n=== 原文件哈希保持不变 ===")
    print("全部一致:", after == before, "| 校验文件数:", len(after))
    for f in MUST_NOT_CHANGE:
        print("%-26s %s %s" % (f, after[f][:12], "OK" if after[f] == before[f] else "CHANGED"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
