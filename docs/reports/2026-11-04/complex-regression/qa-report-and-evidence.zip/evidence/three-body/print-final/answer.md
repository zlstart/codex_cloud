版式修复完成，边界检查 0 失败，所有原文件 SHA256 保持一致。

**最终链接**
- [three_body.csv](outputs/three_body.csv)
- [metrics.json](outputs/metrics.json)
- [three_body_final.html](outputs/three_body_final.html)
- [three_body_print.png](outputs/three_body_print.png)
- [convergence_final.json](outputs/convergence_final.json)

**说明**
- 只重绘版式：全部 1266 个样本点直接读自 `three_body.csv`，统计值读自 `metrics.json`（收敛数字引用 `convergence_final.json`），没有重新积分、没有重算任何数值，未修改任何已有文件（11 个既有文件哈希逐一比对全部 OK，含 CSV `7a9f3803cf84`、metrics `469d3485bbff`、两份 HTML、两份既有 PNG、四个 JSON/脚本）
- 三处缺陷已消除：底部 x 轴标题（figbox y 0.3365–0.3502）与跨两列的独立 footer（y 0.1269–0.1810）不再相交；右栏 54 条文字全部落在右栏区域内（含右下来源已移入 footer）；改用 ASCII 的 `E0`、`L0`、`max|dE|/|E0|`，中文字体为 `Noto Sans CJK SC` 且未强制 monospace，不再出现方框字形
- 布局为 GridSpec 两行：左上等比例共轨图（三色线型、初值圆环、末值星形、每 0.5 时间单位相位标记、引线式初值标签、图例），右上带内边距的模型/初值/误差/共轨简表（每颗星分位置与速度两行），下行跨两列 footer
- 三颗星仍共用同一条 8 字闭合轨道，未做人为错开；这是该初值下的 RK4 数值模拟，不是三体问题通解
- 图像：`three_body_print.png`，13.4×8.8 英寸 @150 dpi = 2010×1320 像素，376 KB；绘图脚本为 `outputs/render_three_body_print.py`
- 需告知：本应一次调用完成，实际用了 5 次——脚本初版含三处小错（`Path.exists` 误用、matplotlib 3.11 无 `Bbox.contains_x/intersects`、右栏分隔线 autoscale 压缩文字导致越界），逐次修正后版式 1 通过全部检查