"""Build a read-only, reproducible audit of persisted real-run events."""
from __future__ import annotations
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path('/workspace/qa-artifacts/three-body')

def read(name, default=None):
    p=ROOT/name
    return json.loads(p.read_text()) if p.exists() else default

def redact(s):
    if not isinstance(s,str): return s
    # Do not emit credentials if a future output accidentally contains them.
    s=re.sub(r'(?im)\b(authorization|x-api-key|api-key|cookie)\s*:\s*[^\r\n]+', r'\1: [REDACTED]', s)
    s=re.sub(r'\bsk-[A-Za-z0-9_-]{16,}\b', '[REDACTED_API_KEY]', s)
    return s

def clean(value):
    if isinstance(value,dict):return {k:('[REDACTED]' if re.fullmatch(r'(?i)(api[_-]?key|authorization|cookie|password|access[_-]?token)',k) else clean(v)) for k,v in value.items()}
    if isinstance(value,list):return [clean(v) for v in value]
    return redact(value)

def generate(events_name='events.json', state_name='run-state.json', report_name='report.json', prefix='tool-audit'):
    report=read(report_name,{})
    state=read(state_name,{})
    events=read(events_name,[])
    groups=defaultdict(lambda:{'started':[],'completed':[]})
    for idx,e in enumerate(events):
        if e['type'] in ('tool.started','tool.completed'):
            groups[e.get('data',{}).get('call_id','')][e['type'].split('.')[1]].append((idx,e))
    errors=[]
    seq=[e['sequence'] for e in events]
    ordered=all(a<b for a,b in zip(seq,seq[1:]))
    unique=len(set(seq))==len(seq)
    if not ordered:errors.append('Events are not strictly ordered')
    if not unique:errors.append('Duplicate event sequence')
    calls=[]
    for cid, pair in groups.items():
        starts=pair['started']; dones=pair['completed']
        first=starts[0][1] if starts else dones[0][1]
        terminal=dones[-1][1] if dones else None
        data=first['data']; final=terminal['data'] if terminal else {}
        output=final.get('output','')
        if not isinstance(output,str): output=json.dumps(output,ensure_ascii=False)
        exitcodes=[int(n) for n in re.findall(r'Process exited with code\s+(-?\d+)',output)]
        timeout=bool(re.search(r'Process stopped:\s*timeout',output,re.I))
        reported_status=final.get('status')
        metadata_keys=('item_id','call_id','agent_id','agent_name','parent_call_id','name')
        metadata_equal=bool(terminal) and all(data.get(k)==final.get(k) for k in metadata_keys)
        semantic_error = None
        semantic_error_signals = []
        if data.get('name') == 'apply_patch' and re.search(r"(?:^apply_patch input must|^Invalid Context|^Failed to|^Error:|patch failed|not found)", output, re.I):
            semantic_error = 'apply_patch rejected model-supplied patch'
            semantic_error_signals.append(semantic_error)
        if data.get('name') in ('exec_command','write_stdin'):
            if re.search(r'(?m)^sh:.*: not found', output): semantic_error_signals.append('shell command not found')
            if re.search(r'(?m)^sh:.*Bad substitution', output): semantic_error_signals.append('shell incompatible substitution')
            if 'Traceback (most recent call last):' in output: semantic_error_signals.append('Python traceback: '+(re.findall(r'(?m)^([A-Za-z_]+Error:.*)$',output)[-1] if re.findall(r'(?m)^([A-Za-z_]+Error:.*)$',output) else 'exception'))
            if semantic_error_signals: semantic_error = '; '.join(semantic_error_signals)
        classification='none'
        if any(n!=0 for n in exitcodes):classification='model_command_failure'
        elif timeout:classification='command_timeout'
        elif semantic_error:classification='model_tool_input_failure' if data.get('name')=='apply_patch' else 'model_command_failure'
        elif reported_status in ('failed','error','cancelled'):classification='tool_or_runtime_failure_requires_review'
        elif re.search(r'\b(?:Error calling tool|Tool execution failed|Invalid tool call)\b',output,re.I):classification='tool_protocol_or_runtime_error'
        entry={
            'call_id':cid,'name':data.get('name'),'item_id':data.get('item_id'),
            'agent_id':data.get('agent_id'),'agent_name':data.get('agent_name'),
            'parent_call_id':data.get('parent_call_id'),
            'started_sequences':[e['sequence'] for _,e in starts],
            'completed_sequences':[e['sequence'] for _,e in dones],
            'started_at':first.get('created_at'),'completed_at':terminal.get('created_at') if terminal else None,
            'metadata_consistent':metadata_equal,
            'arguments_consistent':bool(terminal) and data.get('arguments')==final.get('arguments'),
            'arguments':clean(data.get('arguments')),
            'output':clean(output),'output_characters':len(output),
            'output_sha256':hashlib.sha256(output.encode()).hexdigest(),
            'reported_status':reported_status,'actual_exit_codes':exitcodes,
            'command_timeout':timeout,'error_classification':classification,
            'semantic_error':semantic_error,'semantic_error_signals':semantic_error_signals,
            'masked_command_failure_despite_exit_zero':bool(semantic_error) and bool(exitcodes) and all(c==0 for c in exitcodes),
            'failure_missing_status':classification!='none' and reported_status not in ('failed','error','cancelled'),
            'semantic_failure_missing_status':bool(semantic_error) and reported_status not in ('failed','error','cancelled'),
            'completion_means_command_success':False,
            'output_truncated_by_application':'[内容过长，显示已截断。]' in output,
            'audit_truncation':'none; structured JSON retains all persisted tool text after credential redaction',
            'raw_event_reference':{'path':str(ROOT/events_name),'started_zero_based_indices':[i for i,_ in starts],'completed_zero_based_indices':[i for i,_ in dones]},
            'recovery_note':'No failure observed.' if classification=='none' else 'Needs manual review of subsequent calls; do not infer recovery solely from tool.completed.',
        }
        if len(starts)!=1:errors.append(f'{cid}: expected one tool.started, got {len(starts)}')
        if len(dones)!=1 and state.get('status') in ('completed','failed','cancelled'):errors.append(f'{cid}: expected one tool.completed, got {len(dones)}')
        if terminal and not metadata_equal:errors.append(f'{cid}: start/complete metadata mismatch')
        if terminal and not entry['arguments_consistent']:errors.append(f'{cid}: start/complete arguments mismatch')
        if terminal and starts and starts[0][1]['sequence']>=terminal['sequence']:errors.append(f'{cid}: completion precedes start')
        recovery_notes = read('audit-recovery-notes.json', {})
        if cid in recovery_notes: entry['recovery_note'] = recovery_notes[cid]
        calls.append(entry)
    phase_by_id={}
    text_done={}
    for e in events:
        d=e.get('data',{}); item=d.get('item_id')
        if item and d.get('phase'):phase_by_id[item]=d['phase']
        if e['type']=='text.completed':text_done[item]=d.get('text','')
    final_items=[{'item_id':i,'text':t} for i,t in text_done.items() if phase_by_id.get(i)=='final']
    event_final='\n\n'.join(x['text'] for x in final_items).strip()
    reported_answer=report.get('answer','').strip()
    session=read('session.json',{})
    session_answer='\n\n'.join(m.get('content','') for m in session.get('messages',[]) if m.get('role')=='assistant' and m.get('run_id')==report.get('run_id')).strip()
    artifact_links=[]
    known_files=session.get('files',report.get('files',[]))
    for label,href in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',reported_answer):
        href=unquote(href)
        filename=Path(urlparse(href).path).name
        match=next((f for f in known_files if f.get('name')==filename or f.get('url')==href or ('/api/files/'+str(f.get('id'))+'/') in href),None)
        if match or href.startswith(('outputs/','/workspace/outputs/','sandbox:','/api/files/')):
            artifact_links.append({'label':label,'href':href,'matched_file_id':match.get('id') if match else None,'matched_file_name':match.get('name') if match else None,'exists_in_session_artifacts':bool(match)})
    required=['three_body.csv','metrics.json','three_body.png','three_body.html']
    linked_names={a['matched_file_name'] for a in artifact_links}
    artifact_consistency={'links':artifact_links,'all_artifact_links_resolve':all(a['exists_in_session_artifacts'] for a in artifact_links),'required_files_linked':{n:n in linked_names for n in required}}
    finals={'artifact_consistency':artifact_consistency,'events_final_items':final_items,'event_final_equals_report_answer':event_final==reported_answer if final_items else None,'report_answer_equals_session_message':reported_answer==session_answer if session else None,'final_answer_present':bool(reported_answer),'note':'Intermediate text is not counted as the independently visible final answer.'}
    if state.get('status')=='completed' and not reported_answer:errors.append('Completed run has no final answer in report snapshot')
    if final_items and event_final!=reported_answer:errors.append('Event final text differs from report answer')
    if session and reported_answer!=session_answer:errors.append('Report answer differs from assistant session message')
    failed=[c for c in calls if c['error_classification']!='none']
    result={
        'generated_at':datetime.now(timezone.utc).isoformat(),
        'run_id':report.get('run_id'),'session_id':report.get('session_id'),
        'live_provider':report.get('live_provider'),
        'snapshot_status':state.get('status'),'snapshot_is_terminal':state.get('status') in ('completed','failed','cancelled'),
        'run_outcome':{'status':state.get('status'),'error':state.get('error',report.get('error')),'duration_seconds':report.get('duration_seconds'),'successful':state.get('status')=='completed' and bool(reported_answer),'output_files_present':[f.get('name') for f in known_files if f.get('kind')=='output'],'artifact_presence_does_not_imply_run_success':True,'failure_category':'application_run_timeout' if state.get('status')=='failed' and '超时' in str(state.get('error','')) else None},
        'sources':{'events':str(ROOT/events_name),'state':str(ROOT/state_name),'report':str(ROOT/report_name)},
        'ordered_events':{'count':len(events),'strictly_increasing':ordered,'unique_sequences':unique,'sequence_gaps_are_permitted':True,'types':dict(Counter(e['type'] for e in events))},
        'tool_call_count':len(calls),'tool_failure_count':len(failed),
        'semantic_failures_missing_status':[c['call_id'] for c in calls if c['semantic_failure_missing_status']],
        'failures_missing_status':[c['call_id'] for c in calls if c['failure_missing_status']],
        'masked_command_failures_despite_exit_zero':[c['call_id'] for c in calls if c['masked_command_failure_despite_exit_zero']],
        'calls':calls,
        'final_answer_consistency':finals,'integrity_errors':errors,
        'integrity_pass':not errors,'failure_classification_notes':{
            'model_command_failure':'Actual nonzero exit code found in command output. A tool.completed event alone does not imply the command succeeded.',
            'model_tool_input_failure':'The tool output semantically rejects the model-supplied tool arguments (for example malformed patch or invalid context); no process exit code is available. Missing failed status is recorded separately as an application status-propagation defect.',
            'tool_or_runtime_failure_requires_review':'Tool status or protocol error needs source-level classification.',
            'test_harness_failure':'Not inferred from model event log; inspect the separate acceptance report harness_error field.'},
        'test_harness_error':report.get('harness_error')
    }
    (ROOT/(prefix+'.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    lines=['# 三体真实运行工具审计','',f"Run `{result['run_id']}` · 会话 `{result['session_id']}` · 当前状态 `{result['snapshot_status']}`。",'',f"持久化事件 {len(events)} 条；序号严格递增：{ordered}；唯一：{unique}。序号间隙允许，不视为遗漏。",f"工具调用 {len(calls)} 次；发现失败 {len(failed)} 次；事件完整性检查：{'通过' if not errors else '失败'}。",'',
        '| 序号（开始→完成） | 工具 | call_id | 输出实际退出码 | 事件状态 | 错误类别 |',
        '| --- | --- | --- | --- | --- | --- |']
    for c in calls:
        lines.append(f"| {','.join(map(str,c['started_sequences']))} → {','.join(map(str,c['completed_sequences'])) or '未完成'} | {c['name']} | `{c['call_id']}` | {c['actual_exit_codes'] or '未提供/不适用'} | {c['reported_status'] or '未提供'} | {c['error_classification']} |")
    lines+=['', '运行结论：'+('成功完成。' if result['run_outcome']['successful'] else '未成功完成；'+str(result['run_outcome']['error'] or '尚未结束'))+' 产物存在不能替代 run 成功与最终答复。', '最终答复存在：'+str(bool(reported_answer))+'；产物数：'+str(len(result['run_outcome']['output_files_present']))+'。', '', '完整参数与持久化输出保存在同名 JSON 中；仅对凭据模式脱敏，没有额外内容截断。应用自身截断会逐条标注；原始事件路径和索引逐条可追溯。','', '## 调用明细','']
    for c in calls:
        lines += [f"### {c['name']} · `{c['call_id']}`",'',f"item_id：`{c['item_id']}`；agent_id：`{c['agent_id']}`；parent_call_id：`{c['parent_call_id']}`。",f"开始/完成身份一致：{c['metadata_consistent']}；参数一致：{c['arguments_consistent']}。",'', '参数：','```json',json.dumps(c['arguments'],ensure_ascii=False,indent=2),'```','','输出：','```text',c['output'],'```','',f"恢复说明：{c['recovery_note']}",'']
    lines += ['## 最终答复一致性','', '```json',json.dumps(finals,ensure_ascii=False,indent=2),'```','', '## 完整性问题','',json.dumps(errors,ensure_ascii=False,indent=2),'']
    (ROOT/(prefix+'.md')).write_text('\n'.join(lines))
    print(json.dumps({'snapshot_status':result['snapshot_status'],'event_count':len(events),'call_count':len(calls),'tool_failure_count':len(failed),'integrity_pass':not errors,'integrity_errors':errors},ensure_ascii=False))
    return result

if __name__=='__main__':
    generate()
