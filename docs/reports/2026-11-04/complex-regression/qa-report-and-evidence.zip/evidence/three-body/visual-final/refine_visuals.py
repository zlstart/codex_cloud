#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""仅做视觉修正，不进行任何积分，也不新增数值计算任务。

输入（只读）：outputs/three_body.csv, outputs/metrics.json, outputs/convergence.json,
             outputs/three_body.html
输出（新建）：outputs/three_body_final.png, outputs/three_body_final.html

PNG：等比例坐标区只放轨迹/初值点/末值点/图例；说明、初值、误差统计移到右侧独立文字区，
     不再用 inset 压住星 2 的初值注释。三颗星共用同一条 8 字轨道（共轨）如实标注，
     未对物理轨迹做任何错开。全部坐标只取自既有 CSV。
HTML：HUD 从画布覆盖层移出，改为画布下方的独立多列信息条（390px 手机不再遮挡星 1 初值标记）；
     初值标签按左右位置翻转对齐并限制在画布范围内，避免星 2 标签被裁切。
     暂停/继续、重置回 t=0 并暂停、时间滑块等逻辑完全保留；内嵌 1266 行数值与原 CSV 逐值一致。
"""
from __future__ import annotations

import json
import os
import re

import numpy as np

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(OUT_DIR, "three_body.csv")
METRICS_PATH = os.path.join(OUT_DIR, "metrics.json")
CONV_PATH = os.path.join(OUT_DIR, "convergence.json")
HTML_IN = os.path.join(OUT_DIR, "three_body.html")
PNG_OUT = os.path.join(OUT_DIR, "three_body_final.png")
HTML_OUT = os.path.join(OUT_DIR, "three_body_final.html")

COLS = ["#d62728", "#1f77b4", "#2ca02c"]
NAMES = ["星 1", "星 2", "星 3"]


def csv_matrix():
    lines = open(CSV_PATH, encoding="utf-8").read().strip().splitlines()
    header = lines[0].split(",")
    expect = ["t", "x1", "y1", "vx1", "vy1", "x2", "y2", "vx2", "vy2", "x3", "y3", "vx3", "vy3"]
    assert header == expect, f"CSV 表头异常: {header}"
    mat = np.array([[float(x) for x in ln.split(",")] for ln in lines[1:]])
    assert mat.shape == (1266, 13), f"CSV 形状异常: {mat.shape}"
    return mat


def pick_font():
    import matplotlib.font_manager as fm

    have = {f.name for f in fm.fontManager.ttflist}
    sans = next((f for f in ("Noto Sans CJK SC", "WenQuanYi Zen Hei") if f in have), None)
    mono = next((f for f in ("Noto Sans Mono CJK SC", "WenQuanYi Zen Hei Mono") if f in have), None)
    return sans, mono


def wrap_cjk(text, limit):
    out, cur = [], ""
    for ch in text:
        cur += ch
        if len(cur) >= limit:
            out.append(cur)
            cur = ""
    if cur:
        out.append(cur)
    return out


def make_png(metrics, conv):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    mat = csv_matrix()
    t = mat[:, 0]
    pos = mat[:, [1, 2, 5, 6, 9, 10]].reshape(-1, 3, 2)

    sans, mono = pick_font()
    if sans:
        plt.rcParams["font.family"] = sans
    plt.rcParams["axes.unicode_minus"] = False

    fig = plt.figure(figsize=(13.8, 8.8), dpi=150)
    ax = fig.add_axes([0.040, 0.075, 0.535, 0.840])
    pan = fig.add_axes([0.612, 0.075, 0.375, 0.840])
    pan.axis("off")

    styles = ["-", "--", "-."]
    LABEL_POS = [(0.035, 0.945), (0.965, 0.945), (0.775, 0.055)]
    LABEL_HA = ["left", "right", "center"]
    phase = ["o", "s", "^"]
    for i in range(3):
        ax.plot(pos[:, i, 0], pos[:, i, 1], color=COLS[i], ls=styles[i], lw=1.7,
                alpha=0.85, label=NAMES[i] + "（m=1，同一条 8 字轨道）")
        ax.plot(pos[::50, i, 0], pos[::50, i, 1], marker=phase[i], ms=4.6, ls="none",
                color=COLS[i], alpha=0.95)
        ax.plot(pos[0, i, 0], pos[0, i, 1], marker="o", ms=13, mfc="none", mec=COLS[i], mew=2.2)
        ax.plot(pos[-1, i, 0], pos[-1, i, 1], marker="*", ms=15, color=COLS[i])
        ax.annotate(NAMES[i] + " 初值", xy=(pos[0, i, 0], pos[0, i, 1]),
                    xytext=LABEL_POS[i], textcoords="axes fraction",
                    fontsize=8.8, color=COLS[i], ha=LABEL_HA[i], va="center",
                    arrowprops=dict(arrowstyle="-", color=COLS[i], lw=0.8, alpha=0.75,
                                    shrinkA=3, shrinkB=5))

    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(True, ls=":", alpha=0.45)
    ax.axhline(0.0, color="k", lw=0.6, alpha=0.55)
    ax.axvline(0.0, color="k", lw=0.6, alpha=0.55)
    ax.set_xlabel("位置 x（无量纲单位：G = 1，m = 1）")
    ax.set_ylabel("位置 y（无量纲单位）")
    ax.set_title("三体数值模拟：8 字共轨轨迹（仅由 three_body.csv 重绘，未重新积分）", fontsize=12.2)
    handles, _ = ax.get_legend_handles_labels()
    handles += [
        Line2D([], [], color="0.35", marker="o", mfc="none", ms=11, ls="none",
               label="初始位置（t = 0）"),
        Line2D([], [], color="0.35", marker="*", ms=13, ls="none",
               label="末值位置（t = 12.65）"),
        Line2D([], [], color="0.35", marker="s", ms=5, ls="none",
               label="相位标记：每 0.5 时间单位一点"),
    ]
    ax.legend(handles=handles, loc="lower left", fontsize=8.4, framealpha=0.95)

    lines = []

    def head(s):
        lines.append(("h", s))

    def kv(k, s):
        lines.append(("kv", k, s))

    def para(s):
        for w in wrap_cjk(s, 39):
            lines.append(("p", w))

    v = metrics
    head("模型与数值设置")
    kv("方程", "二维牛顿引力，不加软化项")
    kv("G / 质量", "G = %g，m = %s" % (v["G"], v["masses"]))
    kv("积分方法", "固定步长 RK4（经典四阶）")
    kv("步长 dt", "%g（共 %d 步）" % (v["dt"], v["steps"]))
    kv("时间区间", "[%g, %g]（含端点）" % (v["t_start"], v["t_end"]))
    kv("导出样本", "%d 个，每 %d 步取 1 个" % (v["sample_count"], v["sample_stride_steps"]))
    kv("单位", "无量纲（正则化）单位")
    head("初始条件（等于 CSV 首行）")
    for i in range(3):
        kv(NAMES[i], "r=(%+.8f, %+.8f)  v=(%+.9f, %+.8f)"
           % (v["initial_positions"][i][0], v["initial_positions"][i][1],
              v["initial_velocities"][i][0], v["initial_velocities"][i][1]))
    head("守恒量与误差（取自 metrics.json）")
    kv("E₀", "%.12f" % v["initial_energy"])
    kv("max|ΔE|/|E₀|", "%.4e" % v["max_relative_energy_error"])
    kv("L₀", "%.4e" % v["initial_angular_momentum"])
    kv("max|ΔL|", "%.4e" % v["max_absolute_angular_momentum_error"])
    kv("max|质心偏离|", "%.4e" % v["max_center_of_mass_norm"])
    kv("最小两星间距", "%.6f（t = %.3f）"
       % (v["minimum_pair_distance"], v["minimum_pair_distance_time"]))
    head("共轨（choreography）说明")
    para("三颗等质量天体沿同一条“8”字形闭合轨道依次追赶，属于三体共轨解。左图三条曲线在几何上完全重合，"
         "这是该初值下逐步积分得到的物理事实；本图未对任何轨迹做人为错开或偏移，"
         "改用不同线型与等时间间隔的相位标记（每 0.5）来区分三者的相位。")
    if conv:
        c = conv.get("conclusion", {})
        head("步长收敛复核（引用 convergence.json）")
        kv("表观阶 p", "位置 %.2f，速度 %.2f"
           % (c.get("apparent_order_position", float("nan")),
              c.get("apparent_order_velocity", float("nan"))))
        kv("相邻步长差比", "位置 %.2f，速度 %.2f"
           % (c.get("diff_ratio_position", float("nan")),
              c.get("diff_ratio_velocity", float("nan"))))
        para("守恒量误差已接近双精度舍入本底，减半 dt 不会按 h 的四次方缩小 16 倍。")
    head("适用性与限制")
    para("这是给定初值下的数值模拟结果，只描述这一组初始条件的三体运动，不是三体问题的通解；"
         "三体问题不存在一般的封闭解析解，换一组初值将得到完全不同的轨迹。")
    para("绘图数据来源：outputs/three_body.csv（1266 个等间隔样本，含 t = 0 与 t = 12.65）。")

    y = 0.998
    for item in lines:
        if item[0] == "h":
            y -= 0.009
            pan.text(0.0, y, item[1], fontsize=9.3, fontweight="bold", color="#15539b", va="top")
            pan.plot([0.0, 1.0], [y - 0.0200, y - 0.0200], color="#b8c4d8", lw=0.7,
                     clip_on=False, zorder=0)
            y -= 0.0232
        elif item[0] == "kv":
            pan.text(0.004, y, item[1], fontsize=8.3, va="top", color="#333",
                     family=mono or None)
            pan.text(0.275, y, item[2], fontsize=8.3, va="top", color="#000",
                     family=mono or None)
            y -= 0.0226
        else:
            pan.text(0.004, y, item[1], fontsize=8.1, va="top", color="#222")
            y -= 0.0208
    assert y > -0.02, "右侧文字区超出版面，请精简内容"
    pan.add_patch(plt.Rectangle((-0.014, -0.014), 1.028, 1.028, transform=pan.transAxes,
                                fill=False, ec="#9aa7bd", lw=0.9, clip_on=False))

    fig.text(0.040, 0.026,
             "修订说明：仅调整版面（统计/初值移入独立文字区，取消覆盖轨迹的 inset）；轨迹与数值未重新计算。",
             fontsize=8.3, color="#444")
    fig.savefig(PNG_OUT)
    plt.close(fig)
    return len(t)


def payload_of(text):
    return re.search(r"const DATA = (\{.*?\});\n", text, re.S).group(1)


def make_html():
    orig = open(HTML_IN, encoding="utf-8").read()
    html = orig

    # 1) HUD：由画布覆盖层 -> 画布下方独立信息条（多列，390px 也不遮挡标记）
    rules = [
        ".hud{position:static;display:block;column-count:3;column-gap:22px;background:#0b1424;"
        "border-top:1px solid var(--line);border-radius:0;padding:9px 12px;font-size:12.5px;"
        "line-height:1.75;pointer-events:auto}",
        ".hud{column-count:2;column-gap:14px;font-size:11.5px;line-height:1.65;padding:8px 10px}",
    ]
    seen = {"n": 0}

    def hud_repl(_match):
        rule = rules[min(seen["n"], len(rules) - 1)]
        seen["n"] += 1
        return rule

    html, n_hit = re.subn(r"\.hud\{[^}]*\}", hud_repl, html)
    assert n_hit == 2, f"HUD 样式命中数异常: {n_hit}"

    # 2) 初值标签：右侧的星体标签向左对齐，并把标签位置限制在画布内
    old_label = "    ctx.fillText(NAMES[i] + ' 初值', X + 10, Y - 9);"
    new_label = (
        "    (function (idx, X0, Y0) { var flip = X0 > W * 0.60;"
        "var lx = flip ? X0 - 11 : X0 + 11;"
        "lx = Math.min(Math.max(lx, 8), W - 8);"
        "var ly = Math.min(Math.max(Y0 - 9 - 13 * idx, 14), H - 6);"
        "ctx.textAlign = flip ? 'right' : 'left';"
        "ctx.fillText(NAMES[idx] + ' 初值', lx, ly); })(i, X, Y);"
    )
    assert old_label in html, "未命中初值标签绘制行"
    html = html.replace(old_label, new_label)

    # 3) 页脚：标明仅布局修订，数据未改动
    old_foot = "<footer>数据与图表由 simulate_three_body.py 生成"
    assert old_foot in html, "未命中页脚文本"
    html = html.replace(
        old_foot,
        "<footer>可视化修订版（仅调整 HUD 位置与初值标签对齐，内嵌数值与原文件逐值一致）"
        " · 原数据与图表由 simulate_three_body.py 生成")

    # 4) 硬校验：数据一字未改，且与 CSV 逐值相同；控件与说明仍在；无外部依赖
    assert payload_of(html) == payload_of(orig), "内嵌数据被改动"
    emb = np.array(json.loads(payload_of(html))["rows"], dtype=float)
    assert np.array_equal(emb, csv_matrix()), "内嵌数据与 CSV 不一致"
    assert emb.shape == (1266, 13), f"内嵌样本形状异常: {emb.shape}"
    for keep in ("暂停", "继续", "重置", "拖动滑块定位", "不是三体问题的通解", "模拟时间 t"):
        assert keep in html, f"关键控件或说明文本缺失: {keep}"
    assert not re.search(r"https?://|<script[^>]+src=|<link[^>]+href=|@import", html), "出现外部依赖"

    open(HTML_OUT, "w", encoding="utf-8").write(html)
    return emb.shape[0]


def main() -> int:
    metrics = json.load(open(METRICS_PATH, encoding="utf-8"))
    conv = json.load(open(CONV_PATH, encoding="utf-8")) if os.path.exists(CONV_PATH) else None

    n_t = make_png(metrics, conv)
    n_html = make_html()

    print("PNG  ->", PNG_OUT, "%d KB" % (os.path.getsize(PNG_OUT) // 1024), "轨迹点/星:", n_t)
    print("HTML ->", HTML_OUT, "%d KB" % (os.path.getsize(HTML_OUT) // 1024), "内嵌样本:", n_html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())