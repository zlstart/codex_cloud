#!/usr/bin/env python3
"""Build an offline Chinese QA report from reviewed artifacts; stdlib only.

python /workspace/qa-artifacts/build_final_report.py
Optional final facts: --facts /workspace/qa-artifacts/final/report-overrides.json
Never reads auth-state, cookies, credentials, private oracle files, or raw reasoning.
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import os
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Shanghai")
STATUS = {"passed": "通过", "failed": "未通过", "pending": "进行中 / 待确认", "partial": "部分通过",
          "completed": "运行完成", "running": "运行中", "cancelled": "已取消", "not_verified": "未验证", "returned": "已返回"}
SENSITIVE_KEY = re.compile(r"api.?key|authorization|password|secret|access.?token|refresh.?token|cookie|encrypted_content|reasoning", re.I)
SENSITIVE_PATH = re.compile(r"auth[-_]state|storage[-_]state|credential|cookie|(^|/)private(/|$)|\.env", re.I)
SECRET_VALUES = [os.environ[k] for k in ("AGENT_API_KEY", "OPENAI_API_KEY", "OPENAI_TRACING_API_KEY")
                 if len(os.environ.get(k, "")) > 8]


def sanitize(value):
    if isinstance(value, dict):
        return {str(k): sanitize(v) for k, v in value.items() if not SENSITIVE_KEY.search(str(k))}
    if isinstance(value, list):
        return [sanitize(v) for v in value]
    if isinstance(value, str):
        for secret in SECRET_VALUES:
            value = value.replace(secret, "[凭据已脱敏]")
        value = re.sub(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+", "Bearer [已脱敏]", value)
        value = re.sub(r"\bsk-[A-Za-z0-9_-]{16,}", "[API 密钥已脱敏]", value)
        return value
    return value


def local_time(value):
    if not value:
        return "未记录"
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            return str(value) + "（原始值无时区）"
        return dt.astimezone(TZ).strftime("%Y-%m-%d %H:%M:%S UTC+8")
    except ValueError:
        return str(value)


def as_json(value):
    return json.dumps(value, ensure_ascii=False, indent=2)


def check_status(value):
    if not isinstance(value, dict):
        return "pending"
    for key in ("overall_pass", "passed"):
        if isinstance(value.get(key), bool):
            return "passed" if value[key] else "failed"
    if value.get("result") in ("passed", "failed"):
        return value["result"]
    checks = value.get("checks")
    if isinstance(checks, dict) and checks:
        flags = [v if isinstance(v, bool) else v.get("passed") if isinstance(v, dict) else None
                 for v in checks.values()]
        if all(v is True for v in flags):
            return "passed"
        if any(v is False for v in flags):
            return "failed"
    if isinstance(checks, list) and checks:
        flags = [v.get("passed") for v in checks if isinstance(v, dict)]
        if len(flags) == len(checks) and all(v is True for v in flags):
            return "passed"
        if any(v is False for v in flags):
            return "failed"
    return "pending"


class Evidence:
    def __init__(self, root):
        self.root = root
        self.sources = {}
        self.errors = []

    def read(self, rel):
        if SENSITIVE_PATH.search(rel):
            raise ValueError("Sensitive source is excluded")
        path = self.root / rel
        if not path.is_file():
            return {}
        try:
            value = sanitize(json.loads(path.read_text()))
            self.sources[rel] = value
            return value
        except (OSError, ValueError) as exc:
            self.errors.append({"source": rel, "error": type(exc).__name__,
                                "note": "文件可能仍在写入；本次不将其当成通过。"})
            return {}

    def text(self, rel):
        path = self.root / rel
        return sanitize(path.read_text(errors="replace")) if path.is_file() else ""

    def first(self, *rels):
        for rel in rels:
            data = self.read(rel)
            if data:
                return rel, data
        return rels[0], {}


def log_result(evidence, rel):
    text = evidence.text(rel)
    tail = text[-15000:]
    fail = re.findall(r"\b(\d+) failed\b", tail)
    if any(int(v) > 0 for v in fail) or re.search(r"[ℹ#]\s*fail\s+[1-9]", tail):
        return {"status": "failed", "summary": "日志包含测试失败", "source": rel}
    counts = re.findall(r"\b(\d+) passed\b", tail)
    if counts:
        return {"status": "passed", "summary": f"{counts[-1]} 项通过", "source": rel}
    if "All checks passed" in tail or "✓ built in" in tail or "PASS:" in tail or "PASS authored" in tail:
        return {"status": "passed", "summary": "命令日志有明确成功标记", "source": rel}
    return {"status": "pending", "summary": "缺少可自动确认的命令终态；可用最终事实覆盖", "source": rel}


def collect_tools(events):
    calls = {}
    order = []
    for event in events:
        kind = event.get("type", "")
        if kind not in {"tool.started", "tool.completed", "tool.failed"}:
            continue
        d = event.get("data") or {}
        key = (event.get("run_id"), d.get("agent_id"), d.get("parent_call_id"), d.get("call_id", d.get("item_id")))
        if key not in calls:
            calls[key] = {"run_id": key[0], "call_id": key[3], "agent_id": key[1], "parent_call_id": key[2],
                          "name": d.get("name", "未知工具"), "events": [], "status": "pending"}
            order.append(key)
        call = calls[key]
        call["events"].append({"sequence": event.get("sequence"), "type": kind,
                               "created_at": event.get("created_at"), "created_at_local": local_time(event.get("created_at"))})
        if "arguments" in d:
            call["arguments"] = d["arguments"]
        if kind == "tool.started":
            call["started_at"] = event.get("created_at")
        else:
            call["completed_at"] = event.get("created_at")
            call["output"] = d.get("output", d.get("error", ""))
            call["reported_status"] = d.get("status")
            output = str(call["output"])
            exits = [int(v) for v in re.findall(r"Process exited with code\s+(-?\d+)", output)]
            call["exit_codes"] = exits
            explicit_error = d.get("status") in {"failed", "error", "cancelled"} or kind == "tool.failed"
            try:
                structured = json.loads(output)
                explicit_error |= isinstance(structured, dict) and structured.get("isError") is True
            except (ValueError, TypeError):
                pass
            call["status"] = "failed" if explicit_error or any(v != 0 for v in exits) else "returned"
            call["status_basis"] = "明确失败字段 / 原生 shell 退出码" if call["status"] == "failed" else "工具已返回；不等价于业务结果正确"
    for call in calls.values():
        try:
            start = datetime.fromisoformat(call["started_at"].replace("Z", "+00:00"))
            end = datetime.fromisoformat(call["completed_at"].replace("Z", "+00:00"))
            call["duration_seconds"] = round((end - start).total_seconds(), 3)
        except (KeyError, ValueError, TypeError):
            call["duration_seconds"] = None
    return [calls[key] for key in order]


def collect_run(evidence, title, report_rel, events_rel):
    report = evidence.read(report_rel)
    events = evidence.read(events_rel)
    if isinstance(events, dict):
        events = events.get("events", [])
    if not isinstance(events, list):
        events = []
    descriptor = (report.get("runs") or [{}])[-1] if isinstance(report.get("runs"), list) else report
    expected_id = descriptor.get('run_id', descriptor.get('id'))
    if expected_id:
        events = [event for event in events if event.get('run_id') == expected_id]
    state_rel = (Path(report_rel).parent / 'run-state.json').as_posix()
    state = evidence.read(state_rel)
    if not isinstance(state, dict) or state.get('id') != expected_id:
        state = descriptor if descriptor.get('id') == expected_id else {}
    terminal = next((e for e in reversed(events) if e.get("type") in
                     {"run.completed", "run.failed", "run.cancelled"}), None)
    status = terminal["type"].split(".", 1)[1] if terminal else descriptor.get("status", "pending")
    if status not in {"completed", "failed", "cancelled"}:
        status = "running" if events or status == "running" else "pending"
    calls = collect_tools(events)
    run_id = descriptor.get("run_id", descriptor.get("id")) or next((e.get("run_id") for e in events), None)
    started_event = next((e for e in events if e.get('type') == 'run.started'), {})
    created_at = state.get('created_at') or descriptor.get('created_at')
    execution_started_at = created_at or started_event.get('created_at')
    execution_finished_at = (terminal or {}).get('created_at')
    if not execution_finished_at and state.get('status') in ('completed', 'failed', 'cancelled'):
        execution_finished_at = state.get('updated_at')
    duration_basis = ('API run.created_at → 终态事件时间' if created_at else
                      'run.started 事件时间 → 终态事件时间（未取得 API created_at）')
    if not execution_started_at:
        duration_basis = '缺少服务器运行开始时间，未使用测试脚本耗时代替'
    result = {"title": title, "run_id": run_id, "session_id": report.get("session_id", descriptor.get("session_id")),
              "status": status, "error": (terminal or {}).get("data", {}).get("error", descriptor.get("error")),
              "created_at": created_at, "started_at": execution_started_at,
              "finished_at": execution_finished_at, "duration_seconds": None,
              "duration_basis": duration_basis,
              "harness_duration_seconds": descriptor.get('duration_seconds', descriptor.get('elapsed_seconds')),
              "harness_started_at": descriptor.get('submitted_at', report.get('started_at')),
              "harness_finished_at": descriptor.get('finished_at'),
              "live_provider": True, "tool_calls": calls, "event_count": len(events),
              "event_types": dict(Counter(e.get("type") for e in events)),
              "event_sequences_increasing": all(events[i].get("sequence", 0) < events[i + 1].get("sequence", 0)
                                                for i in range(len(events) - 1)),
              "sources": [report_rel, events_rel] + ([state_rel] if state_rel in evidence.sources else []),
              "terminal_evidence": terminal is not None}
    if result["duration_seconds"] is None and result["started_at"] and result["finished_at"]:
        try:
            result["duration_seconds"] = round((datetime.fromisoformat(result["finished_at"].replace("Z", "+00:00")) -
                                                  datetime.fromisoformat(result["started_at"].replace("Z", "+00:00"))).total_seconds(), 3)
        except ValueError:
            pass
    result['execution_duration_seconds'] = result['duration_seconds']
    return result


def build_data(evidence, facts):
    physics = evidence.read("three-body/physics-verification.json")
    oracle = evidence.read("factory/oracle-validation.json")
    interaction = evidence.read("three-body/interaction-verification.json")
    factory_offline = evidence.read("factory/ui-baseline.json")
    preview = evidence.read("preview/after/preview-live-updates.json")
    live = evidence.read("final/diagnostic-live/checks.json")
    live_browser = evidence.read("final/diagnostic-live/browser-checks.json")
    compaction = evidence.read("compaction/live-provider-results.json")
    evidence.read("compaction/live-runtime-results.json")
    for rel in ("three-body/initial-run-tool-audit.json", "three-body/followup/tool-audit.json",
                "factory/audit-independent.json", "factory/recovery/audit-independent.json"):
        evidence.read(rel)
    removal_rel, removal = evidence.first("artifact-removal/frontend/after/artifact-removal.json",
                                         "artifact-removal/after/artifact-removal.json")
    html_rel, html_after = evidence.first("html-preview/after/checks.json", "html-preview/after/report.json",
                                        "html-preview/final-checks.json", "html-preview/after.json",
                                        "html-preview/real-artifact-verification.json")
    evidence.read("html-preview/diagnostic.json")
    runs = [collect_run(evidence, *args) for args in [
        ("三体任务·首轮", "three-body/report.json", "three-body/events.json"),
        ("三体任务·同会话续作", "three-body/followup/report.json", "three-body/followup/events.json"),
        ("工厂报表·首轮", "factory/report.json", "factory/events.json"),
        ("工厂报表·同会话恢复", "factory/recovery/report.json", "factory/recovery/events.json"),
        ("真实诊断·压缩状态与补丁恢复", "final/diagnostic-live/run.json", "final/diagnostic-live/events.json"),
    ]]
    used_reports = {run['sources'][0] for run in runs}
    for scenario in ('three-body', 'factory'):
        for path in sorted((evidence.root / scenario).rglob('report.json')):
            rel = path.relative_to(evidence.root).as_posix()
            if rel in used_reports or not path.with_name('events.json').is_file() or SENSITIVE_PATH.search(rel):
                continue
            scenario_title = '三体任务' if scenario == 'three-body' else '工厂报表'
            stage_title = {'visual-final': '视觉最终修订', 'visual-fix': '视觉修订',
                           'visual-polish': '视觉优化', 'convergence-final': '收敛说明文案更正（第4轮）',
                           'print-final': '静态图最终排版', 'print': '静态图排版修订',
                           'final': '最终复测'}.get(path.parent.name, path.parent.name)
            runs.append(collect_run(evidence, f'{scenario_title}·{stage_title}', rel,
                                    path.with_name('events.json').relative_to(evidence.root).as_posix()))
    def run_order(run):
        source = run['sources'][0]
        group = 0 if source.startswith('three-body/') else 1 if source.startswith('factory/') else 2
        try:
            timestamp = datetime.fromisoformat(run['started_at'].replace('Z', '+00:00')).timestamp()
        except (TypeError, ValueError, AttributeError):
            timestamp = float('inf')
        return group, timestamp
    runs.sort(key=run_order)
    for run in runs:
        base = Path(run['sources'][0]).parent.as_posix()
        audit_candidates = [f'{base}/audit-independent.json', f'{base}/tool-audit.json']
        if base == 'three-body':
            audit_candidates.insert(0, 'three-body/initial-run-tool-audit.json')
        for audit_rel in audit_candidates:
            audit = evidence.read(audit_rel)
            if not isinstance(audit, dict):
                continue
            indexed = {item.get('call_id'): item for item in audit.get('calls', [])}
            for call in run['tool_calls']:
                extra = indexed.get(call['call_id'])
                if not extra:
                    continue
                call['independent_audit'] = {k: v for k, v in extra.items() if k not in ('arguments', 'output')}
                call['independent_audit_source'] = audit_rel
                failure = (extra.get('actual_status') == 'failed' or
                           extra.get('error_classification') not in (None, 'none') or
                           extra.get('masked_command_failure_despite_exit_zero') is True or
                           bool(extra.get('artifact_validation_failure')))
                if failure:
                    call['status'] = 'failed'
                    call['status_basis'] = '独立逐工具审计（含错误输入、管道掩盖或产物自检失败）；保留原 API 状态供比较'
    # Later source files are discoverable without importing arbitrary files or credentials.
    supplemental = []
    for directory in ("html-preview", "artifact-removal", "three-body/followup", "factory/recovery", "final"):
        for path in sorted((evidence.root / directory).rglob("*.json")):
            rel = path.relative_to(evidence.root).as_posix()
            if rel in evidence.sources or SENSITIVE_PATH.search(rel) or path.name in {"events.json", "session.json", "run-state.json", "report-overrides.json"}:
                continue
            value = evidence.read(rel)
            supplemental.append({"source": rel, "status": check_status(value)})
    matrix = [
        {"name": "Python 完整回归", "kind": "自动化 / 含 SDK 协议替身", **log_result(evidence, "final/pytest.log")},
        {"name": "代码规范", "kind": "静态检查", **log_result(evidence, "final/ruff.log")},
        {"name": "前端生产构建", "kind": "真实构建", **log_result(evidence, "final/build.log")},
        {"name": "实时/回放时间线", "kind": "真实浏览器 + authored fixtures", **log_result(evidence, "final/timeline.log")},
        {"name": "文件预览与动态更新", "kind": "真实浏览器 + authored fixtures", **log_result(evidence, "final/previews.log")},
        {"name": "工具/Markdown 显示", "kind": "真实浏览器 + authored fixtures", **log_result(evidence, "final/rendering.log")},
        {"name": "三体数值独立核验", "kind": "真实模型文件 + 独立数值求解", "status": check_status(physics),
         "summary": f"{len(physics.get('checks', {}))} 项检查；CSV 与更小步长 RK4 比对", "source": "three-body/physics-verification.json"},
        {"name": "工厂指标独立核验", "kind": "真实模型文件 + 合成数据独立 oracle", "status": check_status(oracle),
         "summary": f"{oracle.get('passed_count', '?')} / {oracle.get('checks_count', '?')} 项通过", "source": "factory/oracle-validation.json"},
        {"name": "工厂原始 HTML 离线交互", "kind": "未修改真实模型 HTML + 浏览器离线", "status": check_status(factory_offline),
         "summary": "KPI、筛选、导出、空状态、桌面/手机布局", "source": "factory/ui-baseline.json"},
        {"name": "真实诊断后端", "kind": "真实 provider + Docker + API", "status": "passed" if live and all(v is True for v in live.values()) else "pending",
         "summary": "错误补丁 → 失败状态 → 正确补丁 → file/cat；真实 context.status", "source": "final/diagnostic-live/checks.json"},
        {"name": "真实诊断浏览器", "kind": "真实 provider / backend，无 fixture", "status": check_status(live_browser),
         "summary": "错误状态、超阈值未压缩提示、刷新回放", "source": "final/diagnostic-live/browser-checks.json"},
        {"name": "供应商原生压缩", "kind": "真实 provider", "status": "not_verified",
         "summary": "本次未返回 compaction，未通过真实压缩支持验收", "source": "compaction/live-provider-results.json"},
        {"name": "HTML 预览脚本修复复测", "kind": "以新增 after 证据为准", "status": check_status(html_after),
         "summary": "不得以原始文件离线通过替代应用内预览通过", "source": html_rel},
        {"name": "删除文件同步复测", "kind": "API / 浏览器，见证据范围", "status": check_status(removal),
         "summary": "删除后卡片及已打开预览应同步，不再留下 404", "source": removal_rel},
    ]
    issues = [
        {"id": "preview-starvation", "title": "更新中的文件预览长期加载", "status": check_status(preview),
         "before": "运行事件不断更新文件列表时，预览请求反复被取消，用户无法在任务进行中查看文件。",
         "cause": "effect 依赖文件修订元数据（size/created_at 等），更新触发请求清理/取消；并发更新时还需回收被移除的 sheet/page 选择。",
         "fix": "按稳定文件身份管理请求，内容更新后追赶最新修订；只在关闭/换文件时取消；数据缩小时重置分页和工作表选择。",
         "after": f"修复后 fixture 浏览器记录 {preview.get('revisions', '?')} 次修订、{preview.get('contentRequests', '?')} 次请求；预览保持可读并收敛到最新内容。",
         "evidence": ["preview/before/preview-live-updates.json", "preview/before-pagination-reset/preview-live-updates.json", "preview/after/preview-live-updates.json"]},
        {"id": "compaction-boundary", "title": "同一任务压缩后仍发送旧工具历史", "status": log_result(evidence, "compaction/regression.log")["status"],
         "before": "新增真实 SDK 协议测试在第三次模型请求发现旧 call_id；原测试只验证新 run，因此漏检。",
         "cause": "SDK 0.24 沙箱准备处理 original input，模型循环后拼接本轮新产物，原生边界未覆盖该完整请求。",
         "fix": "官方 call_model_input_filter 组合原生 ToolOutputTrimmer 与 Compaction.process_context；只在有真实 compaction 条目时移除旧请求历史。",
         "after": "专项 44 项通过，覆盖压缩后两个工具配对、重复压缩、SQLite 重开及 provider 失败恢复；协议替身不算真实供应商支持。",
         "evidence": ["compaction/REPORT.md", "compaction/regression.log", "compaction/full-regression.log"]},
        {"id": "compaction-observability", "title": "超阈值但没有压缩时缺少可见诊断", "status": "passed" if live.get("real_context_status") and check_status(live_browser) == "passed" else "pending",
         "before": "仅收到 compaction 时发成功事件，未压缩时没有输入量与阈值证据。",
         "cause": "界面把没有成功事件表现为空白，无法区分未达阈值、供应商未返回与显示缺失。",
         "fix": "增加每响应 context.status；显示实际输入 tokens、阈值及真实条目数量；实时/回放同 reducer，子代理独立归属。",
         "after": "真实模型/API/浏览器验证准确显示“输入超过阈值，未观测到压缩”，刷新后保持；不把裁剪称为压缩。",
         "evidence": ["final/diagnostic-live/checks.json", "final/diagnostic-live/browser-checks.json", "compaction-ui/browser-green.log"]},
        {"id": "provider-compaction", "title": "当前供应商原生压缩仍未通过验收", "status": "not_verified",
         "before": "历史报告使用 glm-5.3；本次环境实际为 qwen3.8-flash，必须重新验证。",
         "cause": "四次直接流式请求接受 context_management，但输入超阈值仍未返回 compaction。供应商内部原因未获证实。",
         "fix": "保留当前模型和 Responses 协议，增加诚实诊断；未伪造摘要或静默切换服务。",
         "after": "默认 32,000 阈值下实际输入 41,296 / 41,167，条目均为 0。事实保留通过的是未压缩历史，真实压缩后语义保真未验证。",
         "evidence": ["compaction/live-provider-results.json", "compaction/live-runtime-results.json"]},
        {"id": "patch-error-status", "title": "原生 apply_patch 失败被展示为普通返回", "status": "passed" if live.get("native_patch_failed_status") and live.get("correct_patch_recovered") else "pending",
         "before": "缺少 Begin Patch 的输入返回原生错误文本，但原事件缺少失败标记。",
         "cause": "SDK 0.24 custom tool 异常分支未经过 RunConfig.tool_error_formatter，不能靠该回调修复。",
         "fix": "用官方 Filesystem.configure_tools 包装原生 apply_patch，记录真实异常 call_id 后原样抛出，由 custom_data_extractor传出失败状态。",
         "after": "真实 8002 诊断按错误补丁→正确补丁恢复→file/cat 全链路通过；不正则猜测任意输出，也不隐藏原错误。",
         "evidence": ["final/diagnostic-live/checks.json", "final/diagnostic-live/browser-checks.json", "baseline/patch-status-before.log", "baseline/patch-status-after.log"]},
        {"id": "sandbox-tools", "title": "沙箱缺少 file/time，管道可能掩盖退出码", "status": "passed" if live.get("file_command_success") and "PASS" in evidence.text("environment/docker-sdk-smoke-final.log") else "pending",
         "before": "真实任务触发 file/time 缺失；部分命令经 tail 管道后仍显示退出 0。",
         "cause": "最小镜像未提供任务需要的基础诊断工具；shell 默认管道退出规则不能反映前段失败。",
         "fix": "镜像补齐 file/time；提示明确 POSIX/Bash 与 pipefail、补丁 Begin/End/+ 行，以及 write_stdin 必须使用真实 session ID。提示用于降低错误概率，不保证模型永不犯错。",
         "after": "file 在真实诊断任务中成功；新版 Docker smoke 四组 PASS。提示改进不把历史错误改写为成功，管道掩盖失败仍保留在独立审计中。",
         "evidence": ["environment/file-command-before.json", "environment/file-command-after.log", "environment/time-command-before.log", "environment/docker-sdk-smoke-final.log"]},
        {"id": "artifact-removal", "title": "生成文件删除后保留过期卡片和 404", "status": check_status(removal),
         "before": "工厂验收下载已删除生成物时遇到 404；需要同步持久化清单、事件与已打开预览。",
         "cause": "文件扫描/事件链路未完整表达删除，与浏览器现有清单状态不一致。",
         "fix": "协作分支正在补 artifact.removed 的后端扫描、实时和回放、选中预览处理；最终实现以新证据为准。",
         "after": "未找到 after 成功证据时保持待确认，不能把首轮 404 归为已修复。",
         "evidence": ["artifact-removal/frontend/before/artifact-removal.json", removal_rel]},
        {"id": "html-preview-scripts", "title": "HTML 预览清理误删脚本，报表与动画未初始化", "status": check_status(html_after),
         "before": "应用内工厂 KPI 为 —，三体 canvas 不动；同一下载原件离线交互正常。",
         "cause": "HTML 预览净化逻辑处理包含标记字符串的多个脚本时误删有效脚本；原文件与净化后脚本数量不一致。",
         "fix": "协作分支正在修复净化过程并保留隔离与网络限制；修复后必须复测原始真实产物。",
         "after": "原件离线通过不能替代应用内通过；after 结果到位前保留待确认。",
         "evidence": ["html-preview/diagnostic.json", "factory/preview-baseline.json", "three-body/interaction-verification.json", html_rel]},
        {"id": "threebody-visual", "title": "三体原 PNG / 手机画面注释遮挡与裁切", "status": "pending",
         "before": "数值验收通过，但首轮 PNG 与手机画面仍存在注释遮挡或裁切，不能把数值正确等同于视觉交付合格。",
         "cause": "生成产物的排版与响应式布局需要单独验收，属于产物质量问题。",
         "fix": "先保持原 CSV/JSON/HTML/PNG 不变完成收敛复核，再另存 final.html / final.png 修订视觉。",
         "after": "只有 final 对应的截图与交互检查到位后才能更新通过；原件继续保留。",
         "evidence": ["three-body/physics-verification.json", "three-body/followup/report.json", "three-body/interaction-verification.json"]},
        {"id": "html-preview-csp", "title": "head 带属性时字符串替换漏注入隔离策略", "status": "pending",
         "before": "恢复合法 id 后，review 发现 head 若带属性，原字符串替换可能漏注入 CSP。",
         "cause": "安全策略注入依赖固定 <head> 字符串，不能覆盖带属性或其他合法序列化形式。",
         "fix": "正在改为 DOM 注入，并补攻击 fixture 验证外部请求在发出前被阻断；不发真实外网请求。",
         "after": "最终 DOM 注入、攻击 fixture 和真实原件预览复测完成前保持待确认。",
         "evidence": ["html-preview/diagnostic.json", "final/previews.log"]},
        {"id": "html-preview-canvas-layout", "title": "真实三体预览的 canvas 初始尺寸仍可能为 1×1", "status": "pending",
         "before": "恢复脚本及合法标识后，真实应用预览仍出现 canvas 初始 1×1，需要继续检查布局。",
         "cause": "尺寸测量与预览容器布局的关系尚在定位；不能把脚本数量恢复当成画布已正确渲染。",
         "fix": "对真实原始模型产物继续定位布局与初始化时机，并复测暂停、继续、拖动和重置。",
         "after": "必须看到真实应用中非零有效尺寸、画面变化和交互断言后才可通过。",
         "evidence": ["html-preview/real-artifact-verification.json", "three-body/interaction-verification.json"]},
    ]
    if check_status(removal) == 'passed':
        issue = next(i for i in issues if i['id'] == 'artifact-removal')
        issue['fix'] = '补齐 artifact.removed 与文件清单、实时/回放和当前预览的同步；具体后端/前端范围见证据。'
        issue['after'] = 'after 浏览器结果通过，覆盖删除后全局清单、当前预览和历史回放；完整后端检查由最终日志补充。'
    if check_status(html_after) == 'passed':
        issue = next(i for i in issues if i['id'] == 'html-preview-scripts')
        issue['fix'] = '修复 HTML 净化过程中对合法内联脚本的误删，保留原有隔离和外部请求限制。'
        issue['after'] = '实际未修改模型产物经真实应用 FilePreview 复测通过；检查范围以对应 JSON 为准。'
    required_issue_fields = {'id', 'title', 'status', 'before', 'cause', 'fix', 'after', 'evidence'}
    for extra in facts.get('additional_issues', []):
        if not isinstance(extra, dict) or not required_issue_fields <= extra.keys():
            raise ValueError('additional_issues entries must contain id/title/status/before/cause/fix/after/evidence')
        if any(issue['id'] == extra['id'] for issue in issues):
            raise ValueError('Duplicate additional issue id; update issues.<id> instead')
        issues.append(sanitize(extra))
    for issue in issues:
        change = (facts.get("issues") or {}).get(issue["id"], {})
        issue.update({k: sanitize(v) for k, v in change.items() if k in {"status", "cause", "fix", "after", "evidence", "title"}})
    for row in matrix:
        row.update(sanitize((facts.get("matrix") or {}).get(row["name"], {})))
    for extra in facts.get('additional_matrix', []):
        matrix.append(sanitize(extra))
    # Final facts may cite newly arrived evidence outside the discovery folders.
    # Load only explicitly referenced JSON, retaining the source/privacy boundary.
    referenced = [source for issue in issues for source in issue.get('evidence', [])]
    referenced += [source.strip() for row in matrix for source in re.split('[；;]', row.get('source', ''))]
    referenced += ['three-body/run-summary.json']
    for source in referenced:
        if source.endswith('.json') and not SENSITIVE_PATH.search(source):
            evidence.read(source)
    return {"runs": runs, "matrix": matrix, "issues": issues, "physics": physics, "factory_oracle": oracle,
            "factory_offline": factory_offline, "three_body_interaction": interaction, "compaction": compaction,
            "supplemental_evidence": supplemental, "executive_notes": facts.get("executive_notes", []),
            "limitations": facts.get("limitations", [])}


FIGURES = [
    ("preview/before/preview-failure.png", "修复前：更新中的预览无法完成加载", "浏览器 fixture"),
    ("preview/after/preview-during-updates.png", "修复后：持续更新期间预览可读", "浏览器 fixture"),
    ("preview/after/preview-shrinking-workbook.png", "修复后：工作表缩小时分页复位", "浏览器 fixture"),
    ("final/diagnostic-live/real-compaction-status.png", "真实模型：超过阈值但未返回原生压缩条目", "真实 provider / API / UI"),
    ("final/diagnostic-live/real-patch-failure-fixed.png", "真实模型：补丁失败被正确标记并恢复", "真实 provider / API / UI"),
    ("three-body/screenshots/03-final-answer.png", "三体首轮：终态失败，不能以文件存在替代成功", "真实 provider / UI"),
    ("three-body/screenshots/05-app-html-desktop-failure.png", "修复前：应用内三体动画未初始化", "真实模型产物 / 应用预览"),
    ("three-body/screenshots/06-offline-desktop-interaction.png", "三体原件：离线暂停、继续、滑块与重置", "真实模型原件 / 离线 Chromium"),
    ("three-body/screenshots/06-offline-mobile-interaction.png", "三体原件：390px 浏览器视口交互", "浏览器模拟手机视口"),
    ("factory/screenshots/app-preview-initialization-failure.png", "修复前：应用内工厂 KPI 未初始化", "真实模型产物 / 应用预览"),
    ("factory/screenshots/baseline-desktop-full.png", "工厂原件：独立核对后的离线报表", "真实模型原件 / 离线 Chromium"),
    ("factory/screenshots/baseline-desktop-filtered.png", "工厂原件：产线、班次筛选改变 KPI", "真实模型原件 / 离线 Chromium"),
    ("factory/screenshots/baseline-empty-filter.png", "工厂原件：空筛选不会产生 NaN / Infinity", "真实模型原件 / 离线 Chromium"),
    ("factory/screenshots/baseline-mobile-filtered.png", "工厂原件：手机视口筛选与布局", "浏览器模拟手机视口"),
    ("artifact-removal/frontend/before/failure.png", "修复前：删除产物清单与预览未同步", "浏览器 fixture"),
]


def collect_figures(evidence, facts):
    entries = list(FIGURES)
    for directory in ("html-preview/after", "html-preview/screenshots", "artifact-removal/frontend/after", "three-body/followup/screenshots", "factory/recovery/screenshots", "final/screenshots"):
        for path in sorted((evidence.root / directory).glob("*.png")):
            entries.append((path.relative_to(evidence.root).as_posix(), "后续复测截图 · " + path.stem, "以对应 JSON 记录的测试范围为准"))
    for item in facts.get("figures", []):
        entries.append((item["source"], item["caption"], item.get("kind", "最终复测")))
    result = []
    seen = set()
    for rel, caption, kind in entries:
        if rel in seen or SENSITIVE_PATH.search(rel):
            continue
        path = evidence.root / rel
        if not path.is_file() or path.suffix.lower() != ".png":
            continue
        seen.add(rel)
        result.append({"source": rel, "caption": caption, "kind": kind, "bytes": path.stat().st_size,
                       "file_mtime_local": datetime.fromtimestamp(path.stat().st_mtime, TZ).isoformat()})
    return result


def badge(status):
    return f'<span class="badge {html.escape(status)}">{html.escape(STATUS.get(status, status))}</span>'


def table(headers, rows):
    return '<div class="table-wrap"><table><thead><tr>' + ''.join(f'<th>{html.escape(h)}</th>' for h in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join(f'<td>{v}</td>' for v in row) + '</tr>' for row in rows) + '</tbody></table></div>'


def make_markdown(data):
    lines = ["# AI 会话项目测试与修复报告", "", f"生成时间：{data['generated_at_local']}。时区：Asia/Shanghai（UTC+8）。",
             "", "本报告分开记录任务运行终态、产物正确性、应用预览和真实压缩支持。文件可下载、命令已返回或参数被接受，都不自动等于任务或能力通过。",
             "", "## 测试矩阵", "", "| 检查 | 证据类型 | 结果 | 说明 |", "| --- | --- | --- | --- |"]
    for row in data['matrix']:
        lines.append(f"| {row['name']} | {row['kind']} | {STATUS.get(row['status'],row['status'])} | {row['summary']} |")
    lines.extend(["", "## 真实复杂任务", ""])
    for run in data['runs']:
        lines.extend([f"### {run['title']}", "", f"- 运行：{STATUS.get(run['status'],run['status'])}；run_id：`{run['run_id']}`。",
                      f"- 服务器运行：{local_time(run['started_at'])} → {local_time(run['finished_at'])}；实际运行 {run.get('duration_seconds')} 秒。",
                      f"- 计时依据：{run['duration_basis']}；测试脚本记录耗时 {run.get('harness_duration_seconds')} 秒（可能包含截图、轮询与采集延迟，不作为模型任务耗时）。",
                      f"- 记录：{run['event_count']} 个事件，{len(run['tool_calls'])} 次工具调用；终态证据：{run['terminal_evidence']}。",
                      f"- 终态错误：{run.get('error') or '无；逐工具失败见下方审计'}。", ""])
    lines.extend(["## 问题、修复与复测", ""])
    for issue in data['issues']:
        lines.extend([f"### {issue['title']} · {STATUS.get(issue['status'],issue['status'])}", "",
                      f"修复前：{issue['before']}", "", f"根因：{issue['cause']}", "", f"修复：{issue['fix']}", "",
                      f"复测：{issue['after']}", "", "证据：" + "、".join(f"`{p}`" for p in issue['evidence']), ""])
    lines.extend(["## 数值验收", "", "三体独立求解与 CSV 再计算：", "", "```json", as_json(data['physics'].get('recomputed_from_csv', {})), "```", "",
                  f"工厂独立 oracle：{data['factory_oracle'].get('passed_count','?')} / {data['factory_oracle'].get('checks_count','?')} 项通过。", "",
                  "## 逐工具审计", "", "完整脱敏参数、输出、事件序号和 call_id 在同目录 `results.json` 的 runs[].tool_calls；HTML 提供逐项折叠阅读。"])
    for run in data['runs']:
        lines.extend(["", f"### {run['title']}", "", "| 次序 | 工具 | 状态 | 时长（秒） | call_id |", "| --- | --- | --- | ---: | --- |"])
        for i, call in enumerate(run['tool_calls'], 1):
            lines.append(f"| {i} | {call['name']} | {STATUS.get(call['status'],call['status'])} | {call['duration_seconds']} | `{call['call_id']}` |")
    lines.extend(["", "## 截图与边界", "", "关键截图已嵌入 `report.html`，无需网络。截图原始界面时间可能是浏览器 UTC；报告表格统一北京时间。", "",
                  "浏览器 mobile 表示模拟视口，不等于实体手机；离线 HTML 通过断网 context + setContent 检查，受管理浏览器禁止 file://，未宣称 file:// 导航测试。",
                  "", "真实供应商未返回 compaction 时，压缩后语义保真仍为未验证。SDK HTTP fixture 验证应用协议处理，不证明供应商支持。",
                  "", "首轮任务失败与后续续作终态独立记录；pending 不视为完成。完整工具输出只保留产品事件允许的内容，不含密钥、auth-state、私有 reasoning 或压缩密文。"])
    for note in data.get('executive_notes', []) + data.get('limitations', []):
        lines.extend(["", str(note)])
    return "\n".join(lines) + "\n"


CSS = """
:root{color-scheme:light;--ink:#142338;--muted:#58667b;--line:#dce4ec;--orange:#ef7424;--paper:#f5f7fa}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:var(--paper);font:15px/1.75 system-ui,-apple-system,'Segoe UI','Microsoft YaHei',sans-serif}a{color:#195bbb}header{background:#142338;color:white;padding:55px max(24px,calc((100vw - 1180px)/2)) 45px}header small{color:#ffc690;letter-spacing:.12em}h1{font-size:clamp(28px,4.6vw,46px);line-height:1.25;margin:12px 0 18px}header p{max-width:860px;color:#d5dfec}nav{position:sticky;top:0;z-index:3;background:#fff;border-bottom:1px solid var(--line);padding:12px 24px;display:flex;gap:24px;justify-content:center;flex-wrap:wrap}nav a{text-decoration:none;font-weight:650;color:var(--ink)}main{max-width:1240px;margin:auto;padding:25px 30px 80px}section{scroll-margin-top:78px;margin:28px 0 55px}h2{font-size:27px;margin:0 0 18px;padding-bottom:10px;border-bottom:2px solid var(--ink)}h3{font-size:20px;margin:0 0 10px}p{margin:10px 0}.lead{font-size:18px}.muted,small{color:var(--muted)}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.card,article{background:white;border:1px solid var(--line);border-radius:10px;padding:22px}.card strong{font-size:28px;display:block}.card small{display:block}.table-wrap{overflow:auto;background:white;border:1px solid var(--line);border-radius:8px}table{border-collapse:collapse;width:100%;min-width:650px}th,td{text-align:left;padding:12px 15px;border-bottom:1px solid var(--line);vertical-align:top}th{background:#eaf0f6;font-size:13px}tr:last-child td{border-bottom:0}.badge{font-size:12px;font-weight:700;padding:4px 9px;border-radius:5px;white-space:nowrap;display:inline-block;background:#e8edf3}.passed,.completed{background:#dff2e7;color:#145c38}.failed{background:#ffe3df;color:#912c25}.pending,.running,.not_verified{background:#fff0cb;color:#805800}.partial{background:#e3ebff;color:#254b9d}.issues{display:grid;gap:16px}.issue-head{display:flex;align-items:start;gap:15px;justify-content:space-between}.issue-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px 25px}.label{font-weight:750;color:#253e5b}.source{font:12px/1.65 ui-monospace,SFMono-Regular,monospace;overflow-wrap:anywhere;color:var(--muted)}details{background:#fff;border:1px solid var(--line);border-radius:8px;margin:10px 0}summary{cursor:pointer;padding:13px 17px;font-weight:650;overflow-wrap:anywhere}details .inside{padding:0 18px 18px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.65 ui-monospace,SFMono-Regular,Consolas,monospace;background:#f1f4f8;border-radius:5px;padding:16px;max-height:600px;overflow:auto}.figures{display:grid;grid-template-columns:1fr 1fr;gap:20px}figure{margin:0;background:#fff;border:1px solid var(--line);border-radius:9px;overflow:hidden}figure img{display:block;width:100%;height:340px;object-fit:contain;background:#e7edf4}figcaption{padding:15px}figcaption strong,figcaption small{display:block}figure details{margin:0;border-radius:0;border:0;border-top:1px solid var(--line)}figure details img{height:auto;max-height:none}figure:has(details[open]){grid-column:1/-1}.note{background:#fff3e7;border-left:4px solid var(--orange);padding:16px 20px;margin:18px 0}.checklist{display:grid;grid-template-columns:1fr 1fr;gap:8px}.checklist div{background:white;padding:12px;border:1px solid var(--line);border-radius:6px}footer{color:var(--muted);font-size:12px;border-top:1px solid var(--line);padding-top:20px}@media(max-width:760px){main{padding:18px 16px 50px}.cards{grid-template-columns:1fr 1fr}.issue-grid,.figures,.checklist{grid-template-columns:1fr}header{padding:35px 20px}nav{gap:8px 18px;padding:10px;font-size:13px}figure img{height:260px}h2{font-size:23px}}@media print{nav{position:static}header{background:#fff;color:#142338;padding:20px}header p{color:#333}main{max-width:none;padding:10px}.card,article,figure{break-inside:avoid}details{break-inside:avoid}summary{font-size:12px}pre{max-height:none}a{color:inherit}}
"""


def make_html(data, root):
    esc = html.escape
    counts = Counter(i['status'] for i in data['issues'])
    parts = ['<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
             '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; base-uri \'none\'">',
             '<title>AI 会话项目测试与修复报告 · 2026-11-04</title><style>' + CSS + '</style></head><body>',
             '<header><small>FAMSUN / 可追溯验收记录</small><h1>AI 会话项目<br>测试与修复报告</h1>',
             '<p class="lead">应用侧缺陷逐项修复与复测；真实任务、数值正确性和供应商能力分别验收。</p>',
             f'<p>生成时间 {esc(data["generated_at_local"])} · Asia/Shanghai（UTC+8）<br>当前模型：qwen3.8-flash · Responses API · Python Agents SDK 0.24.0</p></header>',
             '<nav><a href="#overview">结论与范围</a><a href="#matrix">测试矩阵</a><a href="#runs">真实任务</a><a href="#issues">根因与修复</a><a href="#numbers">数值核验</a><a href="#screenshots">截图</a><a href="#tools">逐工具审计</a></nav><main>',
             '<section id="overview"><h2>结论与范围</h2><div class="cards">',
             f'<div class="card"><strong>{counts["passed"]}</strong><small>问题已有通过证据</small></div>',
             f'<div class="card"><strong>{counts["pending"] + counts["running"]}</strong><small>待最终复测确认</small></div>',
             f'<div class="card"><strong>{sum(len(r["tool_calls"]) for r in data["runs"])}</strong><small>本报告逐项收录工具调用</small></div>',
             f'<div class="card"><strong>{len(data["figures"])}</strong><small>离线内嵌证据截图</small></div></div>',
             '<div class="note"><b>当前供应商原生压缩尚未通过真实验收。</b> 输入超过配置阈值时服务仍未返回 compaction。应用已增加诚实状态，并修复收到真实压缩条目后的同任务输入边界。SDK 协议替身通过不能替代供应商支持。</div>',
             '<p>首轮三体与工厂任务均出现运行失败，但已有产物经独立数值校验通过。报告保留首轮失败，续作与恢复单独展示；仍在运行的任务不会标成完成。</p>',
             '<p class="muted">证据层级：真实 provider / API / Docker；真实模型原件的独立检查；SDK HTTP 协议 fixture；真实浏览器 + authored API/SSE fixture。浏览器模拟手机视口不等于实体手机。</p>']
    for note in data.get('executive_notes', []):
        parts.append('<p>' + esc(str(note)) + '</p>')
    parts.append('</section><section id="matrix"><h2>测试矩阵</h2>')
    parts.append(table(['检查', '证据类型', '结果', '范围 / 来源'], [[esc(r['name']), esc(r['kind']), badge(r['status']), esc(r['summary']) + '<br><span class="source">' + esc(r['source']) + '</span>'] for r in data['matrix']]))
    parts.append('</section><section id="runs"><h2>真实复杂任务与续作</h2>')
    parts.append(table(['场景', '运行终态', '服务器运行时间 / 实际耗时', '测试脚本耗时', '事件与工具', '终态错误'], [[esc(r['title']), badge(r['status']), esc(local_time(r['started_at'])) + '<br>→ ' + esc(local_time(r['finished_at'])) + '<br><b>' + esc(str(r['duration_seconds'])) + ' 秒</b><br><small>' + esc(r['duration_basis']) + '</small>', esc(str(r['harness_duration_seconds'])) + ' 秒<br><small>可能含轮询、截图和采集延迟</small>', f'{r["event_count"]} 事件 / {len(r["tool_calls"])} 工具<br><span class="source">{esc(str(r["run_id"]))}</span>', esc(r.get('error') or '无；逐工具失败见下方审计')] for r in data['runs']]))
    parts.append('<p class="muted">实际运行按 API run.created_at 到对应 run 的明确终态事件计算，包含沙箱准备、模型调用及工具执行；缺 API 开始时间时明确使用 run.started 事件。测试脚本耗时独立列示，不作为提供方推理时长。事件序号允许跨 run 的间隔，不能要求连续。</p></section><section id="issues"><h2>问题、根因、修复与前后复测</h2><div class="issues">')
    for i, issue in enumerate(data['issues'], 1):
        parts.append(f'<article id="issue-{esc(issue["id"])}"><div class="issue-head"><h3>{i:02d} · {esc(issue["title"])}</h3>{badge(issue["status"])}</div><div class="issue-grid">')
        for key, label in [('before', '修复前'), ('cause', '根因'), ('fix', '修复'), ('after', '复测与最终结果')]:
            parts.append(f'<div><span class="label">{label}</span><p>{esc(issue[key])}</p></div>')
        parts.append('</div><p class="source">证据：' + '<br>'.join(esc(p) for p in issue['evidence']) + '</p></article>')
    parts.append('</div></section><section id="numbers"><h2>数值与交互验收</h2><h3>三体：独立 Newton 引力 RK4 验证</h3>')
    physics = data['physics']
    checks = physics.get('checks', {})
    rows = [[esc(k), esc(str(v))] for k, v in physics.get('recomputed_from_csv', {}).items()]
    parts.append(table(['从下载 CSV 重新计算的指标', '结果'], rows))
    parts.append('<p>独立积分步长 0.0001，比生成器要求小 10 倍；CSV 四舍五入与全精度内部指标分别核验，避免混用误差口径。</p>')
    parts.append('<details><summary>展开全部三体检查与独立误差依据</summary><div class="inside"><pre>' + esc(as_json(checks)) + '</pre></div></details>')
    oracle = data['factory_oracle']
    parts.append(f'<h3>工厂：合成数据独立 oracle，{oracle.get("passed_count", "?")} / {oracle.get("checks_count", "?")} 项通过</h3>')
    parts.append('<p>原始 HTML 离线浏览器核对覆盖全量 KPI、产线/班次/日期筛选、CSV 导出、空筛选、重置及 390px 布局。原件正确与应用预览正确分别记录。</p>')
    parts.append('<details><summary>展开工厂指标与交互检查</summary><div class="inside"><pre>' + esc(as_json(data['factory_offline'].get('checks', []))) + '</pre></div></details>')
    comp_rows = []
    for case in data['compaction'].get('cases', []):
        for index, response in enumerate(case.get('responses', []), 1):
            comp_rows.append([esc(str(case['threshold'])), str(index), esc(str((response.get('usage') or {}).get('input_tokens'))), esc(str(response.get('compaction_item_count'))), esc(str(response.get('status')))])
    parts.append('<h3>真实压缩探针：阈值、用量与实际产物</h3>' + table(['配置阈值', '轮次', '实际输入 tokens', 'compaction 数量', '响应状态'], comp_rows))
    parts.append('</section><section id="screenshots"><h2>关键问题与最终结果截图</h2><p class="muted">截图原图保持不变。界面内部时间可能为浏览器 UTC；本报告表格统一 UTC+8。点击“查看大图”展开整行读取细节。</p><div class="figures">')
    for figure in data['figures']:
        encoded = base64.b64encode((root / figure['source']).read_bytes()).decode('ascii')
        uri = 'data:image/png;base64,' + encoded
        parts.append(f'<figure><img loading="lazy" src="{uri}" alt="{esc(figure["caption"])}"><figcaption><strong>{esc(figure["caption"])}</strong><small>{esc(figure["kind"])}</small><span class="source">{esc(figure["source"])}</span></figcaption><details><summary>查看大图</summary><img loading="lazy" src="{uri}" alt="{esc(figure["caption"])}（大图）"></details></figure>')
    parts.append('</div></section><section id="tools"><h2>每一步工具调用审计</h2><p>按运行、agent、父调用和 call_id 配对，记录真实参数、输出、时间和终态。工具已返回不代表业务结果正确；管道可能掩盖前段退出码，需结合独立审计与数值核验。完整脱敏内容保存在同目录 results.json 的 runs[].tool_calls。</p>')
    for run in data['runs']:
        parts.append(f'<h3>{esc(run["title"])} · {badge(run["status"])} · {len(run["tool_calls"])} 次</h3>')
        for i, call in enumerate(run['tool_calls'], 1):
            output = as_json(call.get('output')) if not isinstance(call.get('output'), str) else call.get('output', '')
            truncated = len(output) > 20000
            parts.append(f'<details><summary>{i:02d} · {esc(call["name"])} · {badge(call["status"])} · {esc(str(call["duration_seconds"]))} 秒 · <span class="source">{esc(str(call["call_id"]))}</span></summary><div class="inside">')
            parts.append('<p class="muted">' + esc(local_time(call.get('started_at'))) + ' → ' + esc(local_time(call.get('completed_at'))) + '</p>')
            parts.append('<p>' + esc(call.get('status_basis', '尚无工具终态')) + '</p>')
            if call.get('independent_audit'):
                audit = call['independent_audit']
                classification = ('产物自检失败（API返回与业务验收分开）' if audit.get('artifact_validation_failure')
                                  else audit.get('error_classification', audit.get('actual_status', '已核查')))
                parts.append('<p>独立审计：' + esc(str(classification)) + '。' + esc(str(audit.get('recovery_note', audit.get('classification_reason') or ''))) + '</p>')
            parts.append('<p class="source">事件：' + esc(as_json(call['events'])) + '</p><p class="label">参数</p><pre>' + esc(as_json(call.get('arguments'))) + '</pre><p class="label">输出</p><pre>' + esc(output[:20000]) + '</pre>')
            if truncated:
                parts.append('<p>HTML 展示前 20,000 字符；完整输出未截断保存在 results.json。</p>')
            parts.append('</div></details>')
    parts.append('</section><section><h2>剩余边界与证据清单</h2><p>本次未观察到真实 compaction，故压缩后语义保真仍未验证；不以普通续聊事实保留代替。离线 HTML 验证通过断网浏览器 context + setContent 完成；受管理浏览器禁止 file://，未宣称 file:// 导航已测。</p><p>所有生成数据均为合成验收资料。auth-state、Cookie、密钥、完整私有推理和压缩密文不进入报告。仍在写入或缺少终态的证据保持 pending；本报告不创建归档包。</p>')
    for note in data.get('limitations', []):
        parts.append('<p>' + esc(str(note)) + '</p>')
    parts.append('<details><summary>展开本次使用的结构化来源</summary><div class="inside"><pre>' + esc('\n'.join(sorted(data['sources']))) + '</pre></div></details>')
    if data['read_errors']:
        parts.append('<pre>' + esc(as_json(data['read_errors'])) + '</pre>')
    parts.append('<footer>由 build_final_report.py 从已有证据重新生成。HTML 自包含，无外部字体、脚本或资源；Markdown 与 results.json 提供文本和机器可读审计。生成时间：' + esc(data['generated_at_local']) + '</footer></section></main></body></html>')
    return ''.join(parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/workspace/qa-artifacts'))
    parser.add_argument('--output', type=Path, default=Path('/workspace/test-report-2026-11-04'))
    parser.add_argument('--facts', type=Path)
    args = parser.parse_args()
    facts_path = args.facts or args.root / 'final/report-overrides.json'
    facts = sanitize(json.loads(facts_path.read_text())) if facts_path.is_file() else {}
    evidence = Evidence(args.root)
    data = build_data(evidence, facts)
    data['figures'] = collect_figures(evidence, facts)
    data['generated_at'] = datetime.now(timezone.utc).isoformat()
    data['generated_at_local'] = local_time(data['generated_at'])
    data['timezone'] = 'Asia/Shanghai'
    data['source_root'] = str(args.root)
    data['sources'] = evidence.sources
    data['read_errors'] = evidence.errors
    data['redaction_policy'] = 'No credential/auth-state/cookie/private reasoning/encrypted compaction fields. Full product tool parameters and outputs are retained after credential redaction.'
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'results.json').write_text(as_json(data) + '\n')
    (args.output / 'report.md').write_text(make_markdown(data))
    (args.output / 'report.html').write_text(make_html(data, args.root))
    print(as_json({'output': str(args.output), 'runs': len(data['runs']),
                   'tools': sum(len(r['tool_calls']) for r in data['runs']), 'figures': len(data['figures']),
                   'issue_statuses': dict(Counter(i['status'] for i in data['issues'])),
                   'read_errors': evidence.errors,
                   'files': {name: (args.output / name).stat().st_size for name in ['report.html', 'report.md', 'results.json']}}))


if __name__ == '__main__':
    main()
