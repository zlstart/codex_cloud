"""Build a private, credential-checked QA delivery without publishing anything."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import zipfile

ROOT = Path('/workspace/codex_cloud')
EVIDENCE = Path('/workspace/qa-artifacts')
OUT = Path('/workspace/test-report-2026-11-04')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def eligible(path):
    parts = set(path.relative_to(EVIDENCE).parts)
    return not (parts & {'private', '__pycache__', 'buildx', 'mount-smoke'}) and not re.search(
        r'(auth-state|storage-state|admin-state|credentials|\.pyc$|\.zip$)', path.name, re.I
    )


def main():
    OUT.mkdir(exist_ok=True)
    changed = git('diff', '--name-only', '-z').decode().split('\0')
    added = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    files = sorted(set(filter(None, changed + added)))
    patch = git('diff', '--binary', 'HEAD')
    for filename in filter(None, added):
        result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', filename],
                                cwd=ROOT, capture_output=True)
        if result.returncode != 1:
            raise RuntimeError(f'Cannot create patch for {filename}')
        patch += result.stdout
    (OUT / 'source-changes.patch').write_bytes(patch)
    with tempfile.TemporaryDirectory(prefix='qa-patch-check-', dir='/tmp') as temp:
        temp_path = Path(temp)
        base_archive = temp_path / 'base.tar'
        base_archive.write_bytes(git('archive', 'HEAD'))
        base_checkout = temp_path / 'checkout'
        base_checkout.mkdir()
        with tarfile.open(base_archive) as archive:
            archive.extractall(base_checkout, filter='data')
        result = subprocess.run(['git', 'apply', '--check', str(OUT / 'source-changes.patch')],
                                cwd=base_checkout, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError('Patch does not apply to base: ' + result.stderr)
    source = OUT / 'source-files'
    if source.exists():
        shutil.rmtree(source)
    for filename in files:
        if (ROOT / filename).is_file():
            dest = source / filename
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / filename, dest)
    evidence_paths = [p for p in EVIDENCE.rglob('*') if p.is_file() and eligible(p)]
    known_secrets = {v for k, v in os.environ.items()
                     if re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD)', k, re.I) and len(v) > 10}
    for path in Path('/workspace/qa-runtime').rglob('*.json'):
        if any(part in str(path).lower() for part in ('auth', 'state')):
            try:
                payload = json.loads(path.read_text())
                known_secrets.update(c['value'] for c in payload.get('cookies', []) if len(c.get('value', '')) > 10)
            except (OSError, ValueError, AttributeError):
                pass
    deliverable_paths = [p for p in OUT.rglob('*') if p.is_file() and p.suffix != '.zip'
                         and p.name not in {'SHA256SUMS', 'delivery-checks.json'}]
    hits = []
    for path in evidence_paths + deliverable_paths:
        content = path.read_bytes()
        if any(secret.encode() in content for secret in known_secrets):
            hits.append(str(path))
    if hits:
        raise RuntimeError('Credential match in artifact paths: ' + ', '.join(hits))
    archive_files = [(p, str(p.relative_to(OUT))) for p in deliverable_paths]
    archive_files += [(p, 'evidence/' + str(p.relative_to(EVIDENCE))) for p in evidence_paths]
    checks = {
        'repository': 'https://github.com/zlstart/codex_cloud.git',
        'base_commit': git('rev-parse', 'HEAD').decode().strip(),
        'branch': git('branch', '--show-current').decode().strip(),
        'source_files': files,
        'credential_scan_matches': 0,
        'patch_applies_to_base': True,
        'excluded': ['qa-runtime/**', 'private/**', '**/buildx/**', '**/__pycache__/**', 'auth/storage-state files'],
        'artifact_count_without_manifest': len(archive_files) + 1,
    }
    checks_path = OUT / 'delivery-checks.json'
    checks_path.write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    archive_files.append((checks_path, checks_path.name))
    manifest = ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {name}\n'
                       for p, name in sorted(archive_files, key=lambda item: item[1]))
    (OUT / 'SHA256SUMS').write_text(manifest)
    archive_files.append((OUT / 'SHA256SUMS', 'SHA256SUMS'))
    archive_path = OUT / 'qa-report-and-evidence.zip'
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, name in archive_files:
            archive.write(path, name)
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Archive CRC validation failed')
        for line in manifest.splitlines():
            expected, name = line.split('  ', 1)
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                raise RuntimeError('Archive hash mismatch: ' + name)
    print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size,
                      'files': len(archive_files), 'credential_matches': 0,
                      'zip_crc': 'passed', 'all_sha256': 'passed'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
