# 最终报告生成器

运行：

```bash
python /workspace/qa-artifacts/build_final_report.py
```

默认输出：`/workspace/test-report-2026-11-04/report.html`、`report.md`、`results.json`。HTML 自包含并内嵌截图，无网络、外部字体或脚本依赖。脚本只使用 Python 标准库，不修改业务代码，不创建 ZIP/PDF。

最终事实覆盖文件默认读取 `/workspace/qa-artifacts/final/report-overrides.json`，不存在时使用当前证据。参考 `/workspace/qa-artifacts/report-overrides.example.json`；示例不会自动应用。

- `issues.<id>` 可覆盖 `status/cause/fix/after/evidence/title`。状态可用 `passed/failed/pending/partial/not_verified`。人工更新必须有对应证据，不能把源码已改等同于已验收。
- `additional_issues` 可加入收尾时新发现的问题（字段 `id/title/status/before/cause/fix/after/evidence`），之后也能用 `issues.<id>` 更新状态；重复 ID 会明确报错。
- `matrix.<中文检查名>` 可覆盖矩阵相应行；`additional_matrix` 可新增检查行（字段 `name/kind/status/summary/source`）。
- `figures` 追加截图：`{"source":"相对 qa-artifacts 的 PNG 路径","caption":"说明","kind":"真实 provider 或 fixture 的准确范围"}`。
- `executive_notes` 与 `limitations` 为段落数组。
- 对新出现的 `three-body/**/report.json + events.json` 或 `factory/**/report.json + events.json`，脚本自动增加独立运行，不覆盖首轮结果。状态优先读取明确终态事件。
- 实际运行耗时按同一 run 的 `run-state.json:created_at` 到终态事件 `created_at` 计算（包含沙箱/模型/工具）；无 API 开始时间时明确使用 `run.started` 事件。原测试脚本耗时保存在 `harness_duration_seconds`，不与实际运行混用。三体视觉轮约 434 秒，旧 641.249 秒为采集脚本耗时。
- 工具审计在 `results.json:runs[].tool_calls`，保留完整参数与产品事件输出（凭据脱敏）；HTML 单个输出超过 20,000 字符会注明完整内容在 JSON。已有独立审计补充语义错误/管道掩盖失败，API 原状态仍保留。
- 不读取 auth-state/storage-state/Cookie/凭据/private 目录。结构化 reasoning 与 encrypted_content 字段排除；环境中已知密钥与常见 Bearer/sk-模式脱敏。报告截图是原验收截图，不改变原图内容。
- 报告统一 Asia/Shanghai UTC+8；截图内部文字可能保留浏览器 UTC。

最终状态可更新的问题 ID 包括：`html-preview-scripts`、`html-preview-csp`、`html-preview-canvas-layout`、`threebody-visual`。当前具体状态以 `final/report-overrides.json` 与最新证据为准；canvas 已通过真实强验收；PNG 第5轮修订后也已通过独立边界、哈希与目视检查，原缺陷及中间失败保留在审计中。当前供应商 `provider-compaction` 仍为 `not_verified`，报告明确它未通过真实压缩支持验收，不应因为应用协议测试通过而改成通过。

报告自身已用真实 Chromium 检查：1440px 桌面与 390px 手机视口无横向溢出，逐工具折叠展开可用、无页面错误、无外部请求。记录在 `/workspace/qa-artifacts/report-validation/browser-checks.json`，截图位于同目录。运行浏览器使用环境提供的 `/usr/bin/chromium`；Playwright 默认下载目录没有浏览器，不需要为报告另行安装。

业务复测全部结束后，先更新事实覆盖文件，再重跑生成器；主代理负责最终证据包、哈希、PDF/ZIP，不需要从报告生成器导出认证状态。
