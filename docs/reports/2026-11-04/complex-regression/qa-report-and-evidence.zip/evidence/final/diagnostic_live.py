import json
import os
import time
import uuid
from pathlib import Path

import httpx

root = Path('/workspace/qa-artifacts/final/diagnostic-live')
root.mkdir(parents=True, exist_ok=True)
client = httpx.Client(base_url='http://127.0.0.1:8002', timeout=30)

def request(method, path, **kwargs):
    r = client.request(method, path, **kwargs)
    r.raise_for_status()
    return r.json()

request('POST','/api/auth/register',json={'email':f'diagnostics-{uuid.uuid4().hex[:8]}@example.test','password':uuid.uuid4().hex,'name':'修复复测'})
private = Path('/workspace/qa-runtime/diagnostics-auth.json')
private.write_text(json.dumps({'cookies':[{'name':c.name,'value':c.value,'domain':'127.0.0.1','path':'/','expires':-1,'httpOnly':True,'secure':False,'sameSite':'Lax'} for c in client.cookies.jar],'origins':[]}))
os.chmod(private,0o600)
sid = request('POST','/api/sessions',json={'title':'修复后：压缩观测与工具错误恢复'})['id']
prompt = '''这是隔离工作区的回归测试，请依次执行且保留真实错误：
1. 用 apply_patch 提交下面这个故意缺少 Begin Patch 的输入一次，用来验证工具失败状态。不要先纠正：
*** Add File: outputs/probe.txt
+ALPHA-731
*** End Patch
2. 观察失败后，用完整的正确补丁创建同一文件，内容 ALPHA-731。
3. 使用 exec_command 执行 file --mime-type outputs/probe.txt 并 cat 此文件，验证类型和内容。
最终简短报告发生的错误、恢复及文件检查结果。以后再问时请记住本次检查标记 ALPHA-731。'''
run=request('POST',f'/api/sessions/{sid}/runs',json={'content':prompt,'client_request_id':uuid.uuid4().hex})
manifest={'session_id':sid,'run_id':run['id'],'model':request('GET','/api/settings')['provider']['model'],'threshold':1024,'prompt':prompt,'live_provider':True}
(root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
deadline=time.monotonic()+300
while time.monotonic()<deadline:
    run=request('GET',f'/api/runs/{run["id"]}')
    (root/'run.json').write_text(json.dumps(run,ensure_ascii=False,indent=2))
    if run['status'] in ('completed','failed','cancelled'): break
    time.sleep(2)
events=[]; cursor=0
while True:
    page=request('GET',f'/api/runs/{run["id"]}/timeline?after={cursor}')
    events.extend(page['events'])
    if not page['has_more']: break
    cursor=page['next_cursor']
(root/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
(root/'session.json').write_text(json.dumps(request('GET',f'/api/sessions/{sid}'),ensure_ascii=False,indent=2))
checks={
 'completed':run['status']=='completed',
 'real_context_status':any(e['type']=='context.status' and e['data']['status']=='threshold_exceeded' and e['data']['input_tokens']>1024 for e in events),
 'native_patch_failed_status':any(e['type']=='tool.completed' and e['data'].get('name')=='apply_patch' and e['data'].get('status')=='failed' for e in events),
 'correct_patch_recovered':any(e['type']=='tool.completed' and e['data'].get('name')=='apply_patch' and 'Created outputs/probe.txt' in e['data'].get('output','') for e in events),
 'file_command_success':any(e['type']=='tool.completed' and e['data'].get('name')=='exec_command' and 'Process exited with code 0' in e['data'].get('output','') and 'text/plain' in e['data'].get('output','') for e in events),
}
(root/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps({'run':run['status'],'checks':checks},ensure_ascii=False))
