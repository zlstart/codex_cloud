import hashlib
import json
import urllib.request
from pathlib import Path

BASE = 'http://127.0.0.1:8000'
state = json.loads(Path('/workspace/qa-runtime/auth/admin-state.json').read_text())
cookie = '; '.join(c['name'] + '=' + c['value'] for c in state['cookies'])


def get(url):
    request = urllib.request.Request(BASE + url, headers={'Cookie': cookie})
    with urllib.request.urlopen(request, timeout=20) as response:
        return response.status, response.read()


result = {'health_status': get('/health')[0], 'app_status': get('/')[0],
          'sessions': [], 'passed': True}
for sid in ['b53b665724f84bf4a75c5b74f6efa70f', 'f8d6980b74be40658b09c5569f153640']:
    status, body = get('/api/sessions/' + sid)
    data = json.loads(body)
    entry = {'session_id': sid, 'http_status': status,
             'runs': [{'id': r['id'], 'status': r['status']} for r in data['runs']], 'files': []}
    for artifact in data['files']:
        http, content = get(artifact['url'])
        assert len(content) == artifact['size'], artifact['name']
        entry['files'].append({'name': artifact['name'], 'http_status': http,
                               'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
    assert all(r['status'] not in ['queued', 'running', 'waiting_approval'] for r in data['runs'])
    removed = {'9f7aa38a6f1c42b7a19dc06b97d0d984', '8373a90c254047419b8a7cf345dccf1a'}
    assert not any(f['id'] in removed for f in data['files'])
    result['sessions'].append(entry)
result['global_files_status'] = get('/api/files')[0]
result['test_harness_notes'] = [
    'An initial harness request used /api/health and received 404; source defines /health. Corrected without a product change.',
    'Cloud policy blocked reading /proc/<pid>/cwd during restart verification; the known QA process was verified by its exact command line instead.',
]
Path('/workspace/qa-artifacts/final/post-restart.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'health': result['health_status'], 'app': result['app_status'],
                  'files': sum(len(s['files']) for s in result['sessions']),
                  'all_downloads': 200, 'passed': True}))
