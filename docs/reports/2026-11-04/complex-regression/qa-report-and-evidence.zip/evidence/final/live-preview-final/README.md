# 最新生产版：真实运行中预览验收

Run: bcbeabff56aa497abe1376b4566b446d
Production: http://127.0.0.1:8000; bundle: /assets/index-7OjuiY0u.js

| 文件 | 加载耗时 | 预览前 | 预览后 | 结果 |
|---|---:|---|---|---|
| three_body.csv | 0.185s | running | running | 通过 |
| three_body_final.html | 0.312s | running | running | 通过 |
| three_body.png | 0.157s | running | running | 通过 |

独立新建Chromium浏览器；只浏览和读取文件，未发送任何模型请求。三个预览都在任务running期间完成，无页面或控制台错误，未出现预览挂起。CSV实际表格行、HTML真实脚本/Canvas及PNG像素尺寸均记录在report.json。
