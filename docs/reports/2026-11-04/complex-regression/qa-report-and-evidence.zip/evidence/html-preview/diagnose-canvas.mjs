import { chromium } from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
const report = JSON.parse(await readFile('/workspace/qa-artifacts/three-body/report.json', 'utf8'));
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
try {
  const context = await browser.newContext({ baseURL: 'http://127.0.0.1:8000', storageState: '/workspace/qa-runtime/auth/admin-state.json', viewport: { width: 1440, height: 1000 } });
  await context.addInitScript(() => {
    const rect = Element.prototype.getBoundingClientRect;
    window.canvasGeometry = [];
    Element.prototype.getBoundingClientRect = function (...args) {
      const value = rect.apply(this, args);
      if (this.id === 'cv') window.canvasGeometry.push({ kind: 'measure', rect: value.toJSON(), state: document.readyState, innerWidth, innerHeight, time: performance.now() });
      return value;
    };
    window.addEventListener('resize', () => window.canvasGeometry.push({ kind: 'resize', innerWidth, innerHeight, time: performance.now() }));
  });
  const page = await context.newPage();
  const detail = await (await context.request.get(`/api/sessions/${report.session_id}`)).json();
  await page.goto('/');
  await page.locator('.session-select').filter({ hasText: detail.session.title }).first().click();
  if (!/\bactive\b/.test(await page.locator('.workspace-toggle').getAttribute('class') || '')) await page.locator('.workspace-toggle').click();
  await page.getByRole('button', { name: '预览 three_body.html', exact: true }).first().click();
  const iframe = page.getByRole('dialog').locator('iframe'); await iframe.waitFor();
  const frame = await (await iframe.elementHandle()).contentFrame(); await frame.waitForLoadState('load');
  await frame.locator('#reset').click();
  await page.waitForTimeout(250);
  await frame.locator('#toggle').click();
  await frame.waitForFunction(() => Number(document.querySelector('#tslider').value) > 3);
  const evidence = await frame.evaluate(() => ({
    geometry: window.canvasGeometry,
    canvas: [...document.querySelectorAll('canvas')].map(node => ({ width: node.width, height: node.height, rect: node.getBoundingClientRect().toJSON() })),
    styleCount: document.querySelectorAll('style').length,
    viewport: document.querySelector('meta[name=viewport]')?.content,
  }));
  console.log(JSON.stringify(evidence));
  await writeFile('/workspace/qa-artifacts/html-preview/canvas-geometry.json', JSON.stringify(evidence, null, 2));
  await page.screenshot({ path: '/workspace/qa-artifacts/html-preview/canvas-before.png' });
} catch (error) {
  console.error(error.name + ': ' + error.message.split('\n')[0]); process.exitCode = 1;
} finally { await browser.close(); }
