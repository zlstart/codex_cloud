import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { chromium } from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';
const output='/workspace/qa-artifacts/html-preview';
const report=JSON.parse(await readFile('/workspace/qa-artifacts/three-body/report.json','utf8'));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const checks=[];
try {
  for(const [file,prefix] of [['three_body.html','three-body'],['three_body_final.html','three-body-final']]) {
    for(const [viewport,width,height] of [['desktop',1440,1000],['mobile',390,844]]) {
      const context=await browser.newContext({baseURL:'http://127.0.0.1:8000',storageState:'/workspace/qa-runtime/auth/admin-state.json',viewport:{width,height}});
      const page=await context.newPage();
      const errors=[];page.on('pageerror',error=>errors.push(error.message));
      const detail=await(await context.request.get(`/api/sessions/${report.session_id}`)).json();
      await page.goto('/');
      if(viewport==='mobile') await page.getByRole('button',{name:'打开导航',exact:true}).click();
      await page.locator('.session-select').filter({hasText:detail.session.title}).first().click();
      if(!/\bactive\b/.test(await page.locator('.workspace-toggle').getAttribute('class')||''))await page.locator('.workspace-toggle').click();
      await page.getByRole('button',{name:`预览 ${file}`,exact:true}).first().click();
      const iframe=page.getByRole('dialog').locator('iframe');await iframe.waitFor();
      const frame=await(await iframe.elementHandle()).contentFrame();
      await frame.waitForURL('about:srcdoc');await frame.waitForLoadState('load');
      await frame.waitForFunction(()=>Number(document.querySelector('#tslider').value)>5);
      const evidence=await frame.locator('canvas').evaluate(node=>({width:node.width,height:node.height,rect:node.getBoundingClientRect().toJSON(),scrollY,innerHeight}));
      assert.ok(evidence.width>100&&evidence.height>100);
      assert.equal(evidence.scrollY,0,'Fresh artifact opens at the top without a resize');
      assert.deepEqual(errors,[]);
      await page.screenshot({path:`${output}/${prefix}-overview-${viewport}.png`,animations:'disabled'});
      checks.push({file,viewport,...evidence,passed:true});
      await context.close();
    }
  }
}catch(error){checks.push({error:error.name+': '+error.message.split('\n')[0],passed:false});process.exitCode=1;}
finally{await writeFile(`${output}/overview-verification.json`,JSON.stringify(checks,null,2));console.log(JSON.stringify(checks));await browser.close();}
