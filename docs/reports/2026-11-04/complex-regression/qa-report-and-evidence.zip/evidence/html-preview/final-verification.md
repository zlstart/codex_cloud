# HTML 预览修复与最终验证

结论：生产入口 `http://127.0.0.1:8000` 的真实产物验证 6/6 通过。原始模型生成 HTML 未修改，API 下载与原文件 SHA-256 一致；三体原版、最终版和工厂报表的所有内联脚本文本及顺序均完整保留。

## 修复

- DOMPurify 会移除含 HTML 模板字符串的脚本，导致三体初始化脚本消失、工厂报表只剩数据脚本。现在仅暂存 HTML namespace script 的原始文本，节点和属性照常清洗后，仅向仍保留的节点恢复文本。
- DOMPurify 会移除与表单 API 同名的 `id="reset"`，破坏三体事件绑定。清洗结束后恢复仍保留的 HTML 元素 ID；不恢复被移除节点或 `name` 属性。
- 带属性的 head 无法匹配原来的字符串注入，可能缺少 CSP。现在直接向实际 head 首部插入 CSP/referrer/viewport，保证早于用户脚本。该缺口在测试中发现并修复，未作外部部署。
- iframe 的 srcdoc 在 DOM 挂载期间即可执行，脚本首次测量到 0×0，画布缓冲区被初始化为 1×1。现在等待 ResizeObserver 确认 iframe 已有非零布局尺寸后才加载 srcdoc。没有改写产物脚本，也没有注入或人工触发 resize。

## 真实产物验证

| 产物 | 桌面 | 手机 | 交互与结果 |
| --- | --- | --- | --- |
| three_body.html | 670×670 画布，通过 | 334×334 画布，通过 | 暂停稳定；继续更新时间与画面；滑块定位第 20 个样本；重置返回 0 |
| three_body_final.html | 670×670 画布，通过 | 334×334 画布，通过 | 同上，首次打开即可看到完整轨迹 |
| factory_report.html | 通过 | 通过 | 实际产量 8584 → 筛选“制粒A线＋白班”975 → 重置 8584 |

所有检查均无页面脚本错误、无外网请求、无横向溢出。首屏截图使用全新浏览器上下文直接打开；四个上下文均 `scrollY=0`，没有通过人工 resize 恢复画布。

## 安全边界与回归

iframe 仍仅使用 `sandbox="allow-scripts"`，不允许 same-origin、下载或顶层导航。CSP 的网络、嵌套 frame、worker、对象和表单限制保持不变。脚本、标识符和画布问题均有先失败后通过的回归证据。

- `interactive-preview.mjs`：HTML 模板、JSON 数据、多脚本依赖、reset ID、布局初始化、head 属性 CSP 顺序及早期 connect-src 拦截通过；父页面访问、外网、图片、嵌套 frame、自导航仍被阻止。
- `preview-live-updates.mjs`：持续修订、保留已加载内容、成功刷新重建 iframe、真实画布尺寸、关闭后迟到响应不覆盖其他文件通过。
- TypeScript 类型检查通过；独立代码复核未发现剩余 P2 及以上问题。

网页内导出仍受 sandbox 限制；可下载原 HTML 后在浏览器中使用其导出功能。此限制未被放宽。

## 证据

- 最终实际交互：`real-artifact-verification.json`（6/6）
- 首屏尺寸验证：`overview-verification.json`（4/4）
- 首屏：`three-body-final-overview-desktop.png`、`three-body-final-overview-mobile.png`
- 原版首屏：`three-body-overview-desktop.png`、`three-body-overview-mobile.png`
- 工厂筛选：`factory-desktop-filtered.png`、`factory-mobile-filtered.png`
- 失败证据保留：`fixture-red.log`、`identifier-red.log`、`csp-red.log`、`canvas-red.log`、`real-artifact-before-canvas.json`
- 通过证据：`canvas-green.log`、`loaded-frame-regression.log`
