import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { chromium } from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';

const output = '/workspace/qa-artifacts/html-preview';
await mkdir(output, { recursive: true });
const hash = (value) => createHash('sha256').update(value).digest('hex');
const result = { evidence: 'Actual unmodified model-generated files through the real authenticated application FilePreview', checks: [], errors: [], external_requests: [] };
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
const sourceHashes = {};
let activePage;
try {
  for (const scenario of [
    { directory: 'three-body', file: 'three_body.html', kind: 'three-body' },
    { directory: 'three-body', file: 'three_body_final.html', downloadDirectory: 'visual-final', kind: 'three-body-final' },
    { directory: 'factory', file: 'factory_report.html', kind: 'factory' },
  ]) {
    const source = `/workspace/qa-artifacts/${scenario.directory}`;
    const original = await readFile(`${source}/${scenario.downloadDirectory || 'downloads'}/${scenario.file}`);
    sourceHashes[scenario.file] = hash(original);
    const report = JSON.parse(await readFile(`${source}/report.json`, 'utf8'));
    const context = await browser.newContext({ baseURL: 'http://127.0.0.1:8000', storageState: '/workspace/qa-runtime/auth/admin-state.json', viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage(); activePage = page;
    page.on('pageerror', (error) => result.errors.push({ scenario: scenario.kind, error: error.message }));
    page.on('console', (entry) => { if (entry.type() === 'error') result.errors.push({ scenario: scenario.kind, error: entry.text() }); });
    page.on('request', (request) => {
      if (/^https?:/.test(request.url()) && !request.url().startsWith('http://127.0.0.1:8000/')) result.external_requests.push(request.url());
    });
    const detail = await (await context.request.get(`/api/sessions/${report.session_id}`)).json();
    const file = detail.files.find((item) => item.name === scenario.file);
    assert.ok(file, scenario.file);
    const delivered = await context.request.get(file.url);
    assert.equal(hash(await delivered.body()), hash(original), 'Real app serves the unchanged downloaded HTML');
    await page.goto('/');
    await page.locator('.session-select').filter({ hasText: detail.session.title }).first().click();
    if (!/\bactive\b/.test(await page.locator('.workspace-toggle').getAttribute('class') || '')) await page.locator('.workspace-toggle').click();
    await page.getByRole('button', { name: `预览 ${scenario.file}`, exact: true }).first().click();
    const iframe = page.getByRole('dialog').locator('iframe');
    await iframe.waitFor();
    const frame = await (await iframe.elementHandle()).contentFrame();
    await frame.waitForURL('about:srcdoc');
    await frame.waitForLoadState('load');
    assert.equal(await iframe.getAttribute('sandbox'), 'allow-scripts');
    const originalScripts = await page.evaluate((html) => [...new DOMParser().parseFromString(html, 'text/html').scripts].map((script) => script.textContent), original.toString('utf8'));
    const retainedScripts = await frame.locator('script').allTextContents();
    assert.deepEqual(retainedScripts.map(hash), originalScripts.map(hash), 'Inline scripts retain exact text and order');
    assert.ok((await iframe.getAttribute('srcdoc')).includes("connect-src 'none'"));
    for (const [viewport, width, height] of [['desktop', 1440, 1000], ['mobile', 390, 844]]) {
      if (viewport === 'mobile') await page.setViewportSize({ width, height });
      const check = { scenario: scenario.kind, viewport, source_sha256: hash(original), retained_script_count: retainedScripts.length, sandbox: 'allow-scripts' };
      result.checks.push(check);
      if (scenario.kind.startsWith('three-body')) {
        const slider = frame.locator('#tslider');
        await frame.waitForFunction(() => Number(document.querySelector('#tslider').max) > 1);
        assert.equal(await slider.getAttribute('max'), '1265');
        await frame.locator('#reset').click();
        const value = async () => Number(await slider.inputValue());
        const canvas = async () => hash(await frame.locator('canvas').evaluate((node) => node.toDataURL()));
        check.canvas_before = await frame.locator('canvas').evaluate(node=>({width:node.width,height:node.height,rect:node.getBoundingClientRect().toJSON()}));
        assert.ok(check.canvas_before.width > 100 && check.canvas_before.height > 100, 'Canvas initializes with a usable drawing buffer before any resize');
        const pausedCanvas = await canvas();
        await page.waitForTimeout(250);
        assert.equal(await value(), 0);
        assert.equal(await canvas(), pausedCanvas);
        await frame.locator('#toggle').click();
        await frame.waitForFunction(() => Number(document.querySelector('#tslider').value) > 3);
        assert.notEqual(await canvas(), pausedCanvas);
        await frame.locator('#toggle').click();
        const pausedValue = await value();
        await page.waitForTimeout(200);
        assert.equal(await value(), pausedValue);
        await slider.focus(); await slider.press('Home');
        for (let i = 0; i < 20; i++) await slider.press('ArrowRight');
        assert.equal(await value(), 20);
        await frame.locator('#reset').click();
        assert.equal(await value(), 0);
        check.actions = ['pause keeps time/canvas stable', 'continue advances time and redraws', 'slider seeks to sample 20', 'reset returns sample 0'];
        check.canvas = await frame.locator('canvas').evaluate((node) => ({ width: node.width, height: node.height }));
      } else {
        const value = async () => Number((await frame.locator('#metric-actual').innerText()).replace(/,/g, '').match(/\d+(?:\.\d+)?/)?.[0]);
        await frame.waitForFunction(() => /\d/.test(document.querySelector('#metric-actual')?.textContent || ''));
        assert.equal(await value(), 8584);
        await frame.locator('#filter-line').selectOption({ label: '制粒A线' });
        await frame.locator('#filter-shift').selectOption({ label: '白班' });
        assert.equal(await value(), 975);
        await frame.locator('body').evaluate(() => window.scrollTo(0, 0));
        await page.screenshot({ path: `${output}/factory-${viewport}-filtered.png`, animations: 'disabled' });
        await frame.locator('#reset-filters').click();
        assert.equal(await value(), 8584);
        check.actions = ['baseline actual total 8584', 'line + shift filter actual total 975', 'reset actual total 8584'];
        check.metrics = await frame.locator('[id^="metric-"]').evaluateAll((nodes) => nodes.map((node) => ({ id: node.id, text: node.textContent })));
      }
      await frame.locator('body').evaluate(() => window.scrollTo(0, 0));
      check.layout = await frame.evaluate(() => ({ width: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth }));
      assert.ok(check.layout.scrollWidth <= check.layout.width, 'Artifact fits the iframe viewport');
      await page.screenshot({ path: `${output}/${scenario.kind}-${viewport}.png`, animations: 'disabled' });
      check.passed = true;
    }
    assert.equal(hash(await readFile(`${source}/${scenario.downloadDirectory || 'downloads'}/${scenario.file}`)), sourceHashes[scenario.file]);
    await context.close();
  }
  assert.deepEqual(result.errors, []);
  assert.deepEqual(result.external_requests, []);
  result.passed = true;
} catch (error) {
  result.passed = false; result.error = error.name + ': ' + error.message.split('\n')[0]; process.exitCode = 1;
  if (activePage) await activePage.screenshot({path: `${output}/real-failure.png`,animations:'disabled'}).catch(()=>{});
} finally {
  await writeFile(`${output}/real-artifact-verification.json`, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
  await browser.close();
}
