"""Independent synthetic-factory acceptance oracle; never upload this file.

Reads uploaded source bytes and compares downloaded model output. It does not
modify outputs. Auth credentials, cookies, and API keys are never accessed.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ["记录编号", "日期", "产线", "班次", "产品", "计划产量_吨", "实际产量_吨", "合格产量_吨", "不良产量_吨", "停机分钟", "电耗_kWh"]
NUMERIC = set(FIELDS[5:])
SUM_COLUMNS = {"planned_tonnes": "计划产量_吨", "actual_tonnes": "实际产量_吨", "good_tonnes": "合格产量_吨", "defective_tonnes": "不良产量_吨"}
ROUNDED = {"weighted_quality_pct", "attainment_pct", "specific_energy_kwh_per_tonne"}


def read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        return reader.fieldnames or [], list(reader)


def rounded(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def aggregate(rows: list[dict]) -> dict:
    totals = {key: sum(int(row[column]) for row in rows) for key, column in SUM_COLUMNS.items()}
    totals["records"] = len(rows)
    totals["weighted_quality_pct"] = rounded(Decimal(totals["good_tonnes"]) * 100 / totals["actual_tonnes"])
    totals["attainment_pct"] = rounded(Decimal(totals["actual_tonnes"]) * 100 / totals["planned_tonnes"])
    energy = [row for row in rows if row["电耗_kWh"] and int(row["实际产量_吨"]) > 0]
    totals["energy_eligible_rows"] = len(energy)
    totals["energy_eligible_actual_tonnes"] = sum(int(row["实际产量_吨"]) for row in energy)
    totals["energy_eligible_kwh"] = sum(int(row["电耗_kWh"]) for row in energy)
    totals["specific_energy_kwh_per_tonne"] = rounded(Decimal(totals["energy_eligible_kwh"]) / totals["energy_eligible_actual_tonnes"])
    totals["known_downtime_minutes"] = sum(int(row["停机分钟"]) for row in rows if row["停机分钟"])
    totals["known_energy_kwh"] = sum(int(row["电耗_kWh"]) for row in rows if row["电耗_kWh"])
    return totals


def expected_metrics() -> tuple[dict, list[dict], dict]:
    original = json.loads((ROOT / "private/expected-results.json").read_text())
    _, source = read_csv(ROOT / "inputs" / original["inputs"]["production_csv"])
    by_id = {}
    for row in source:
        if row["记录编号"] in by_id:
            assert row == by_id[row["记录编号"]], "Input has conflicting duplicate"
        by_id.setdefault(row["记录编号"], row)
    rows = list(by_id.values())
    production = original["production"]
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["日期"]].append(row)
    daily = [{"date": day, "records": len(records), **{key: sum(int(r[column]) for r in records) for key, column in SUM_COLUMNS.items()}} for day, records in sorted(grouped.items())]
    expected = {
        "schema_version": 1,
        "synthetic": True,
        "period": original["period"],
        "data_quality": {
            "source_rows": production["source_rows"],
            "unique_rows": production["unique_rows"],
            "duplicate_rows": production["duplicate_rows"],
            "duplicate_ids": production["duplicate_ids"],
            "missing_downtime": production["missing_after_dedup"]["停机分钟"],
            "missing_energy": production["missing_after_dedup"]["电耗_kWh"],
            "zero_output_ids": production["zero_output_ids"],
        },
        "totals": production["totals"],
        "shipments": original["shipments"],
        "per_line": production["line_ranking"],
        "daily": daily,
    }
    selected = [row for row in rows if row["产线"] == "制粒A线" and row["班次"] == "白班"]
    original["daily"] = daily
    original["ui_filters"] = {
        "all": {"filter": {}, "totals": aggregate(rows)},
        "line_a_day": {"filter": {"line": "制粒A线", "shift": "白班"}, "totals": aggregate(selected), "record_ids": [row["记录编号"] for row in selected]},
        "line_a": {"filter": {"line": "制粒A线"}, "totals": aggregate([row for row in rows if row["产线"] == "制粒A线"])},
    }
    return expected, rows, original


def validate(metrics_path: Path, cleaned_path: Path) -> dict:
    expected, source_rows, _ = expected_metrics()
    checks = []

    def check(name, passed, want=None, got=None, detail=None):
        item = {"check": name, "passed": bool(passed)}
        if want is not None:
            item["expected"] = want
        if got is not None:
            item["actual"] = got
        if detail:
            item["detail"] = detail
        checks.append(item)

    def compare(want, got, where):
        if isinstance(want, dict):
            check(where + ".object", isinstance(got, dict))
            if not isinstance(got, dict):
                return
            for key, value in want.items():
                if key not in got:
                    check(where + "." + key, False, value, detail="Required key absent")
                else:
                    compare(value, got[key], where + "." + key)
        elif isinstance(want, list):
            check(where + ".array", isinstance(got, list))
            if not isinstance(got, list):
                return
            check(where + ".length", len(want) == len(got), len(want), len(got))
            # Duplicate and zero-output identifiers have set semantics; rankings
            # and daily data have explicitly requested presentation ordering.
            if where.endswith(("duplicate_ids", "zero_output_ids")):
                check(where + ".members", sorted(want) == sorted(got), sorted(want), sorted(got))
            else:
                for index, (left, right) in enumerate(zip(want, got)):
                    compare(left, right, f"{where}[{index}]")
        elif isinstance(want, bool):
            check(where, type(got) is bool and want == got, want, got)
        else:
            try:
                desired = Decimal(str(want))
                observed = Decimal(str(got))
                tolerance = Decimal("0.005") if where.split(".")[-1] in ROUNDED else Decimal(0)
                okay = observed.is_finite() and abs(desired - observed) <= tolerance
                check(where, okay, want, got)
            except (InvalidOperation, ValueError, TypeError):
                check(where, want == got, want, got)

    check("metrics.json.exists", metrics_path.is_file())
    if metrics_path.is_file():
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8-sig"))
            compare(expected, metrics, "metrics")
        except (ValueError, UnicodeError) as error:
            check("metrics.json.parses", False, detail=str(error))
    check("cleaned_production.csv.exists", cleaned_path.is_file())
    if cleaned_path.is_file():
        try:
            columns, cleaned = read_csv(cleaned_path)
            check("cleaned.columns", columns == FIELDS, FIELDS, columns)
            check("cleaned.rows", len(cleaned) == len(source_rows), len(source_rows), len(cleaned))
            actual_ids = [row.get("记录编号") for row in cleaned]
            check("cleaned.unique_ids", len(actual_ids) == len(set(actual_ids)), len(cleaned), len(set(actual_ids)))
            source_map = {row["记录编号"]: row for row in source_rows}
            check("cleaned.id_members", set(actual_ids) == set(source_map), sorted(source_map), sorted(str(x) for x in actual_ids))
            changes = []
            for row in cleaned:
                wanted = source_map.get(row.get("记录编号"))
                if wanted is None:
                    continue
                for field in FIELDS:
                    left, right = wanted[field], row.get(field)
                    if field in NUMERIC and left != "" and right not in ("", None):
                        try:
                            same = Decimal(left) == Decimal(right)
                        except InvalidOperation:
                            same = False
                    else:
                        same = left == right
                    if not same:
                        changes.append({"record": row.get("记录编号"), "field": field, "expected": left, "actual": right})
            check("cleaned.source_values_preserved", not changes, detail=changes)
            for field in ("停机分钟", "电耗_kWh"):
                want = sum(row[field] == "" for row in source_rows)
                got = sum(row.get(field) == "" for row in cleaned)
                check("cleaned.missing." + field, want == got, want, got)
            zero_ids = [row.get("记录编号") for row in cleaned if row.get("实际产量_吨") and Decimal(row["实际产量_吨"]) == 0]
            check("cleaned.zero_output_retained", set(zero_ids) == set(expected["data_quality"]["zero_output_ids"]), expected["data_quality"]["zero_output_ids"], zero_ids)
        except (ValueError, UnicodeError, InvalidOperation) as error:
            check("cleaned.csv.parses", False, detail=str(error))
    failed = [item for item in checks if not item["passed"]]
    return {"scenario": "factory-synthetic-independent-oracle", "synthetic": True, "passed": not failed, "checks_count": len(checks), "passed_count": len(checks) - len(failed), "failed_count": len(failed), "checks": checks, "failures": failed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--metrics", type=Path, default=ROOT / "downloads/metrics.json")
    parser.add_argument("--cleaned", type=Path, default=ROOT / "downloads/cleaned_production.csv")
    parser.add_argument("--output", type=Path, default=ROOT / "oracle-validation.json")
    args = parser.parse_args()
    if args.prepare:
        expected, _, original = expected_metrics()
        (ROOT / "private/expected-results.json").write_text(json.dumps(original, ensure_ascii=False, indent=2) + "\n")
        (ROOT / "private/expected-metrics.json").write_text(json.dumps(expected, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"prepared": True, "source_rows": expected["data_quality"]["source_rows"], "unique_rows": expected["data_quality"]["unique_rows"]}))
        return
    result = validate(args.metrics, args.cleaned)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("passed", "checks_count", "passed_count", "failed_count")}, ensure_ascii=False))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
