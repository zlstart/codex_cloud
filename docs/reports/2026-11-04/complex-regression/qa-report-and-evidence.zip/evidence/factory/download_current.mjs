import {request} from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';
const root='/workspace/qa-artifacts/factory';const report=JSON.parse(await readFile(root+'/report.json','utf8'));
const client=await request.newContext({baseURL:'http://127.0.0.1:5173',storageState:'/workspace/qa-runtime/auth/admin-state.json'});
try{const r=await client.get('/api/sessions/'+report.session_id);if(r.status()!==200)throw Error('Session status '+r.status());const detail=await r.json();const files=detail.files.filter(f=>f.kind==='output');const outcomes=[];for(const f of files){const v=await client.get(f.url+'?download=true');outcomes.push({name:f.name,size:f.size,status:v.status(),url:f.url});if(v.status()!==200)continue;await writeFile(root+'/downloads/'+f.name,await v.body());}await writeFile(root+'/download-status.json',JSON.stringify(outcomes,null,2));console.log(JSON.stringify(outcomes));}finally{await client.dispose();}
