import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {chromium} from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';
const root='/workspace/qa-artifacts/factory';const stage=process.argv[2]||'context-followup';const prompt=await readFile(process.argv[3]||root+'/followup-prompt.txt','utf8');
const original=JSON.parse(await readFile(root+'/report.json','utf8'));const dir=root+'/'+stage;await mkdir(dir,{recursive:true});
const redact=s=>String(s).replace(/\b(cookie|authorization|x-api-key|api-key):[^\r\n]*/gi,'$1: [redacted]').replace(/famsun_session=[A-Za-z0-9_-]+/g,'famsun_session=[redacted]');
const save=(name,v)=>writeFile(dir+'/'+name,redact(typeof v==='string'?v:JSON.stringify(v,null,2)));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const report={stage,session_id:original.session_id,started_at:new Date().toISOString(),browser_errors:[]};
try{const context=await browser.newContext({baseURL:'http://127.0.0.1:5173',storageState:'/workspace/qa-runtime/auth/admin-state.json',viewport:{width:1440,height:1000}});const page=await context.newPage();page.on('pageerror',e=>report.browser_errors.push(redact(e.message)));
const get=async(url)=>{const r=await context.request.get(url);assert.equal(r.status(),200);return r.json();};
const timeline=async(id)=>{let out=[],after=0;for(;;){const r=await get(`/api/runs/${id}/timeline?after=${after}&limit=1000`);out.push(...r.events);if(!r.has_more)return out;after=r.next_cursor;}};
await page.goto('/');await page.locator('.session-select').filter({hasText:'复杂工厂运行报表·真实模型验收'}).first().click();await page.getByLabel('发送给丰尚助手的消息').fill(prompt);await save('prompt.txt',prompt);
const wait=page.waitForResponse(r=>/\/api\/sessions\/[^/]+\/runs$/.test(new URL(r.url()).pathname)&&r.request().method()==='POST');const start=Date.now();await page.getByRole('button',{name:'发送消息',exact:true}).click();const response=await wait;assert.equal(response.status(),201);const run=await response.json();report.run_id=run.id;await save('report.json',report);console.log('SUBMITTED '+JSON.stringify({stage,run_id:run.id}));
let ev=[];let last=0;while(Date.now()-start<1020000){const state=await get('/api/runs/'+run.id);ev=await timeline(run.id);report.status=state.status;report.error=state.error;report.duration_seconds=(Date.now()-start)/1000;await save('report.json',report);await save('events.json',ev);if(Date.now()-last>20000){console.log('PROGRESS '+JSON.stringify({stage,status:state.status,seconds:Math.round(report.duration_seconds),events:ev.length}));last=Date.now();}if(['completed','failed','cancelled'].includes(state.status))break;await page.waitForTimeout(2000);}
const detail=await get('/api/sessions/'+original.session_id);report.answer=detail.messages.filter(m=>m.run_id===run.id&&m.role==='assistant').map(m=>m.content).join('\n\n');await save('answer.md',report.answer);await save('session.json',detail);await save('report.json',report);await page.screenshot({path:dir+'/final.png',animations:'disabled'});console.log('FINISHED '+JSON.stringify({stage,status:report.status,seconds:report.duration_seconds,answer_length:report.answer.length}));
}catch(e){report.error=redact(e.message);await save('report.json',report);console.error(redact(e.message));process.exitCode=1;}finally{await browser.close();}
