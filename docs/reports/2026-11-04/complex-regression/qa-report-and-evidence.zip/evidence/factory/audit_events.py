"""Audit actual persisted tools, preserving failures even when event says completed."""
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/qa-artifacts/factory')
events = json.loads((ROOT / 'events.json').read_text())
starts = [e for e in events if e['type'] == 'tool.started']
ends = [e for e in events if e['type'] in {'tool.completed', 'tool.failed'}]
calls = []
for start in starts:
    data = start['data']
    matching = [e for e in ends if e['data'].get('call_id') == data['call_id']]
    end = matching[-1] if matching else None
    out = str(end['data'].get('output', '')) if end else ''
    match = re.search(r'Process exited with code (-?\d+)', out)
    exit_code = int(match[1]) if match else None
    actual_status = 'unpaired' if not end else 'completed'
    reason = None
    if end and (end['type'] == 'tool.failed' or end['data'].get('status') in {'failed', 'error', 'cancelled'}):
        actual_status, reason = 'failed', 'explicit API failure'
    if exit_code is not None and exit_code != 0:
        actual_status, reason = 'failed', f'actual process exit {exit_code}'
    if data['name'] == 'apply_patch' and (out.startswith('apply_patch input must ') or out.startswith('Invalid ') or out.startswith('Failed to ')):
        actual_status, reason = 'failed', 'patch rejected by actual tool output'
    if re.search(r'Process running with session ID|Script running with cell ID', out) and actual_status == 'completed':
        actual_status = 'background'
    calls.append({
        'call_id': data['call_id'], 'tool': data['name'],
        'start_sequence': start['sequence'], 'end_sequence': end['sequence'] if end else None,
        'started_at': start['created_at'], 'ended_at': end['created_at'] if end else None,
        'duration_seconds': (datetime.fromisoformat(end['created_at']) - datetime.fromisoformat(start['created_at'])).total_seconds() if end else None,
        'terminal_count': len(matching), 'event_type': end['type'] if end else None,
        'api_status': end['data'].get('status') if end else None,
        'actual_exit_code': exit_code, 'actual_status': actual_status, 'classification_reason': reason,
        'arguments': data.get('arguments'), 'output': out,
    })
    if exit_code == 0 and ('npm: not found' in out or 'Traceback (most recent call last)' in out):
        calls[-1]['diagnostic_note'] = 'Dependency probe printed an unavailable dependency while shell exited 0; retained as diagnostic, not misclassified as failed tool.'
for call in calls:
    if call['actual_status'] == 'failed':
        later = [c for c in calls if c['tool'] == call['tool'] and c['start_sequence'] > call['start_sequence'] and c['actual_status'] == 'completed']
        call['later_success_same_tool'] = [c['call_id'] for c in later]
        if 'file: not found' in call['output']:
            recovery = next((c for c in later if 'head -8' in json.dumps(c['arguments'])), None)
            call['recovery'] = {'classification': 'recovered with head/tail/Python inspection' if recovery else 'not observed', 'call_id': recovery['call_id'] if recovery else None}
        elif 'apply_patch input must' in call['output']:
            recovery = next((c for c in later if 'Created outputs/progress.md' in c['output']), None)
            call['recovery'] = {'classification': 'recovered with valid Begin Patch wrapper' if recovery else 'not observed', 'call_id': recovery['call_id'] if recovery else None}
        elif 'PTY session not found' in call['output']:
            continued = next((c for c in calls if c['start_sequence'] > call['start_sequence'] and c['actual_status'] == 'completed'), None)
            call['recovery'] = {'classification': 'spurious write_stdin session; abandoned, subsequent independent commands continued', 'call_id': continued['call_id'] if continued else None}
        elif 'Invalid Add File line:' in call['output']:
            recovery = next((c for c in calls if c['start_sequence'] > call['start_sequence'] and c['tool'] == 'exec_command' and c['actual_status'] == 'completed' and 'report_core.js' in json.dumps(c['arguments'])), None)
            call['recovery'] = {'classification': 'recovered by writing core through heredoc and validating with Node' if recovery else 'not observed', 'call_id': recovery['call_id'] if recovery else None}
result = {
    'event_count': len(events), 'event_type_counts': dict(Counter(e['type'] for e in events)),
    'strictly_ordered': all(b['sequence'] > a['sequence'] for a,b in zip(events, events[1:])),
    'tool_count': len(calls), 'terminal_count': len(ends),
    'unpaired': [c['call_id'] for c in calls if c['terminal_count'] != 1],
    'orphan_terminals': [e['data'].get('call_id') for e in ends if not any(s['data']['call_id'] == e['data'].get('call_id') for s in starts)],
    'actual_status_counts': dict(Counter(c['actual_status'] for c in calls)),
    'calls': calls,
}
artifacts = {}
for event in events:
    if event['type'] == 'artifact.created':
        artifact = event['data']['artifact']
        item = artifacts.setdefault(artifact['name'], {'first_seen': event['created_at'], 'versions': 0})
        item.update(last_seen=event['created_at'], last_size=artifact['size'], versions=item['versions'] + 1)
result['artifacts'] = artifacts
(ROOT / 'audit-independent.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
rows = ['| Tool | Call ID | Duration (s) | Exit | API status | Actual status |', '|---|---|---:|---:|---|---|']
for c in calls:
    rows.append(f"| {c['tool']} | {c['call_id']} | {c['duration_seconds']} | {c['actual_exit_code']} | {c['api_status']} | {c['actual_status']} |")
(ROOT / 'tool-audit-table.md').write_text('\n'.join(rows)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'calls'}, ensure_ascii=False))
