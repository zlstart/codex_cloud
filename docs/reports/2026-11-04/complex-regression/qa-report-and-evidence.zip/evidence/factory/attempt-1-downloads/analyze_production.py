#!/usr/bin/env python3
"""合成验收数据分析脚本：去重 -> cleaned_production.csv + metrics.json + report_payload.json
口径来源：《2026年10月经营补充.xlsx》工作表「口径说明」。
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
CSV_IN = ROOT / "uploads" / "fb24444b9b064b5d8c4b2e8726911fe5_2026年10月生产明细.csv"
XLSX_IN = ROOT / "uploads" / "eac6b7b19c934e67b6789a612069a4b1_2026年10月经营补充.xlsx"
OUT = ROOT / "outputs"
BUILD = ROOT / "build"

COLUMNS = ["记录编号", "日期", "产线", "班次", "产品", "计划产量_吨", "实际产量_吨",
           "合格产量_吨", "不良产量_吨", "停机分钟", "电耗_kWh"]
INT_COLS = ["计划产量_吨", "实际产量_吨", "合格产量_吨", "不良产量_吨", "停机分钟", "电耗_kWh"]


def r2(x: float | int | None) -> float | None:
    """保留两位小数；无效值返回 None（绝不产出 NaN/Infinity）。"""
    if x is None:
        return None
    v = float(x)
    if not math.isfinite(v):
        return None
    return round(v + 0.0, 2)


def num(x: float | int | None) -> float | int:
    """整数值输出为 int，其余保留两位小数。"""
    v = float(x)
    return int(v) if v.is_integer() else round(v, 2)


def specific_energy(frame: pd.DataFrame) -> float | None:
    """单位电耗 = 电耗合计 / 同范围实际产量合计，仅取电耗有效且实际产量>0 的记录。"""
    ok = frame["电耗_kWh"].notna() & (frame["实际产量_吨"] > 0)
    sub = frame[ok]
    tonnes = float(sub["实际产量_吨"].sum())
    if sub.empty or tonnes <= 0:
        return None
    return r2(float(sub["电耗_kWh"].sum()) / tonnes)


def pct(part: float, whole: float) -> float | None:
    if whole <= 0:
        return None
    return r2(part / whole * 100.0)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(parents=True, exist_ok=True)

    # ---------- 1. 读取生产明细 ----------
    raw = pd.read_csv(CSV_IN, encoding="utf-8-sig", dtype={"记录编号": str})
    assert list(raw.columns) == COLUMNS, f"列名/顺序变化: {list(raw.columns)}"
    source_rows = int(raw.shape[0])

    dup_ids = sorted(raw.loc[raw.duplicated("记录编号", keep=False), "记录编号"].unique().tolist())
    # 校验：同号记录是否逐列完全相同（无冲突才允许“保留首条”）
    conflicts = [k for k, g in raw[raw.duplicated("记录编号", keep=False)].groupby("记录编号")
                 if g.drop_duplicates().shape[0] > 1]

    df = raw.drop_duplicates(subset=["记录编号"], keep="first").reset_index(drop=True)
    unique_rows = int(df.shape[0])
    duplicate_rows = source_rows - unique_rows

    for c in INT_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("Int64")

    # ---------- 2. cleaned_production.csv（11列原字段名、缺失留空、保留零产量） ----------
    out_csv = df.copy()
    out_csv.to_csv(OUT / "cleaned_production.csv", index=False, encoding="utf-8-sig",
                   na_rep="", lineterminator="\n")

    # ---------- 3. Excel：口径说明 / 产线目标 / 发货记录 ----------
    xl = pd.read_excel(XLSX_IN, sheet_name=None)
    caliber = xl["口径说明"].astype(str)
    tgt = xl["产线目标"].copy()
    targets = {}
    for _, r in tgt.iterrows():
        targets[str(r["产线"])] = {
            "quality_pct": r2(float(r["良品率目标"]) * 100),          # 0.98 -> 98.00
            "attainment_pct": r2(float(r["产量达成率目标"]) * 100),   # 0.97 -> 97.00
            "energy_kwh_per_tonne": r2(float(r["单位电耗目标_kWh每吨"])),
        }
    ship = xl["发货记录"].copy()
    ship["日期"] = pd.to_datetime(ship["日期"]).dt.strftime("%Y-%m-%d")
    ship["revenue"] = ship["发货量_吨"].astype(float) * ship["单价_元每吨"].astype(float)
    shipments = [
        {"id": str(r["发货单号"]), "date": r["日期"], "line": str(r["产线"]),
         "product": str(r["产品"]), "qty": num(float(r["发货量_吨"])),
         "price": num(float(r["单价_元每吨"])), "revenue": num(float(r["revenue"]))}
        for _, r in ship.iterrows()
    ]

    # ---------- 4. 数据质量 ----------
    missing_downtime = int(df["停机分钟"].isna().sum())
    missing_energy = int(df["电耗_kWh"].isna().sum())
    zero_output_ids = df.loc[df["实际产量_吨"] == 0, "记录编号"].tolist()
    balance_violations = int((df["实际产量_吨"] != df["合格产量_吨"] + df["不良产量_吨"]).sum())
    date_min, date_max = str(df["日期"].min()), str(df["日期"].max())

    # ---------- 5. 全量统计 ----------
    planned = float(df["计划产量_吨"].sum())
    actual = float(df["实际产量_吨"].sum())
    good = float(df["合格产量_吨"].sum())
    defective = float(df["不良产量_吨"].sum())
    energy_ok = df["电耗_kWh"].notna() & (df["实际产量_吨"] > 0)
    totals = {
        "planned_tonnes": num(planned),
        "actual_tonnes": num(actual),
        "good_tonnes": num(good),
        "defective_tonnes": num(defective),
        "weighted_quality_pct": pct(good, actual),
        "attainment_pct": pct(actual, planned),
        "energy_eligible_rows": int(energy_ok.sum()),
        "energy_eligible_actual_tonnes": num(float(df.loc[energy_ok, "实际产量_吨"].sum())),
        "energy_eligible_kwh": num(float(df.loc[energy_ok, "电耗_kWh"].sum())),
        "specific_energy_kwh_per_tonne": specific_energy(df),
        "known_downtime_minutes": num(float(df["停机分钟"].sum(skipna=True))),
        "known_energy_kwh": num(float(df["电耗_kWh"].sum(skipna=True))),
    }

    # ---------- 6. 分产线（按实际产量降序） ----------
    per_line = []
    for line, g in df.groupby("产线", sort=False):
        p, a = float(g["计划产量_吨"].sum()), float(g["实际产量_吨"].sum())
        gd, dd = float(g["合格产量_吨"].sum()), float(g["不良产量_吨"].sum())
        t = targets.get(line, {})
        se = specific_energy(g)
        per_line.append({
            "line": str(line), "records": int(g.shape[0]),
            "planned_tonnes": num(p), "actual_tonnes": num(a),
            "good_tonnes": num(gd), "defective_tonnes": num(dd),
            "weighted_quality_pct": pct(gd, a), "attainment_pct": pct(a, p),
            "specific_energy_kwh_per_tonne": se,
            "known_downtime_minutes": num(float(g["停机分钟"].sum(skipna=True))),
            "missing_downtime": int(g["停机分钟"].isna().sum()),
            "missing_energy": int(g["电耗_kWh"].isna().sum()),
            "zero_output_rows": int((g["实际产量_吨"] == 0).sum()),
            "target_quality_pct": t.get("quality_pct"),
            "target_attainment_pct": t.get("attainment_pct"),
            "target_energy_kwh_per_tonne": t.get("energy_kwh_per_tonne"),
        })
    per_line.sort(key=lambda x: (-x["actual_tonnes"], x["line"]))
    for i, row in enumerate(per_line, 1):
        row["rank"] = i
        row["gap_quality_pct"] = None if (row["weighted_quality_pct"] is None or row["target_quality_pct"] is None) else r2(row["weighted_quality_pct"] - row["target_quality_pct"])
        row["gap_attainment_pct"] = None if (row["attainment_pct"] is None or row["target_attainment_pct"] is None) else r2(row["attainment_pct"] - row["target_attainment_pct"])
        row["gap_energy_kwh_per_tonne"] = None if (row["specific_energy_kwh_per_tonne"] is None or row["target_energy_kwh_per_tonne"] is None) else r2(row["specific_energy_kwh_per_tonne"] - row["target_energy_kwh_per_tonne"])

    # metrics.json 的 per_line 严格只含规定字段；扩展字段（排名/目标/差距）只进入前端 payload
    METRIC_LINE_KEYS = ["line", "records", "planned_tonnes", "actual_tonnes", "good_tonnes",
                        "defective_tonnes", "weighted_quality_pct", "attainment_pct",
                        "specific_energy_kwh_per_tonne"]
    per_line_metrics = [{k: row[k] for k in METRIC_LINE_KEYS} for row in per_line]

    # ---------- 7. 分日（按日期升序） ----------
    daily = []
    for d, g in df.groupby("日期", sort=True):
        daily.append({
            "date": str(d), "records": int(g.shape[0]),
            "planned_tonnes": num(float(g["计划产量_吨"].sum())),
            "actual_tonnes": num(float(g["实际产量_吨"].sum())),
            "good_tonnes": num(float(g["合格产量_吨"].sum())),
            "defective_tonnes": num(float(g["不良产量_吨"].sum())),
        })

    # ---------- 8. metrics.json（固定结构） ----------
    metrics = {
        "schema_version": 1,
        "synthetic": True,
        "period": {"start": date_min, "end": date_max},
        "data_quality": {
            "source_rows": source_rows, "unique_rows": unique_rows,
            "duplicate_rows": duplicate_rows, "duplicate_ids": dup_ids,
            "missing_downtime": missing_downtime, "missing_energy": missing_energy,
            "zero_output_ids": zero_output_ids,
        },
        "totals": totals,
        "shipments": {
            "records": int(ship.shape[0]),
            "quantity_tonnes": num(float(ship["发货量_吨"].sum())),
            "revenue_yuan": num(float(ship["revenue"].sum())),
        },
        "per_line": per_line_metrics,
        "daily": daily,
    }
    (OUT / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # ---------- 9. 报表内嵌数据（含明细行，供前端筛选实时计算） ----------
    rows = []
    for _, r in df.iterrows():
        rows.append({
            "id": r["记录编号"], "date": r["日期"], "line": r["产线"], "shift": r["班次"],
            "product": r["产品"],
            "planned": None if pd.isna(r["计划产量_吨"]) else int(r["计划产量_吨"]),
            "actual": None if pd.isna(r["实际产量_吨"]) else int(r["实际产量_吨"]),
            "good": None if pd.isna(r["合格产量_吨"]) else int(r["合格产量_吨"]),
            "defective": None if pd.isna(r["不良产量_吨"]) else int(r["不良产量_吨"]),
            "downtime": None if pd.isna(r["停机分钟"]) else int(r["停机分钟"]),
            "energy": None if pd.isna(r["电耗_kWh"]) else int(r["电耗_kWh"]),
        })
    payload = {
        "meta": {
            "synthetic": True,
            "period": {"start": date_min, "end": date_max},
            "sourceFiles": [CSV_IN.name, XLSX_IN.name],
            "columns": COLUMNS,
            "caliberRules": [f"{a}｜{b}" for a, b in zip(caliber.iloc[:, 0], caliber.iloc[:, 1])],
            "conflictIds": conflicts,
            "balanceViolations": balance_violations,
        },
        "rows": rows, "targets": targets, "shipments": shipments,
        "perLine": per_line, "totals": totals,
    }
    (BUILD / "payload.json").write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    print(json.dumps({"source_rows": source_rows, "unique_rows": unique_rows,
                      "duplicate_rows": duplicate_rows, "duplicate_ids": dup_ids,
                      "conflict_ids": conflicts, "balance_violations": balance_violations,
                      "missing_downtime": missing_downtime, "missing_energy": missing_energy,
                      "zero_output_ids": zero_output_ids, "totals": totals,
                      "shipments": metrics["shipments"]}, ensure_ascii=False, indent=2))
    print("\nPER_LINE(按实际产量降序):")
    for row in per_line:
        print(" ", row["rank"], row["line"], "actual=", row["actual_tonnes"], "quality=", row["weighted_quality_pct"],
              "attain=", row["attainment_pct"], "kWh/t=", row["specific_energy_kwh_per_tonne"],
              "| gap q/a/e:", row["gap_quality_pct"], row["gap_attainment_pct"], row["gap_energy_kwh_per_tonne"])


if __name__ == "__main__":
    main()