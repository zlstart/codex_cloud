#!/usr/bin/env python3
"""把计算核心(report_core.js) + 全量数据内联进模板，生成自包含单文件报表 factory_report.html。
合成验收数据：不联网、不引用任何外部资源。
"""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
OUT = ROOT / "outputs"

TEMPLATE = BUILD / "report_template.html"
CORE = BUILD / "report_core.js"
PAYLOAD = BUILD / "payload.json"
METRICS = OUT / "metrics.json"
DEST = OUT / "factory_report.html"

REQUIRED_IDS = [
    "filter-line", "filter-shift", "filter-start", "filter-end",
    "reset-filters", "export-csv",
    "metric-actual", "metric-planned", "metric-quality", "metric-records",
]
EXTERNAL_PATTERNS = {
    "http(s) 链接": re.compile(r"https?://", re.I),
    "协议相对链接": re.compile(r"(?<![:'\"])//[a-z0-9.-]+\.(com|net|org|io|dev|cn)", re.I),
    "外链 <link>": re.compile(r"<link\b[^>]*>", re.I),
    "<script src>": re.compile(r"<script[^>]*\bsrc\b", re.I),
    "<img src>": re.compile(r"<img\b[^>]*\bsrc\b", re.I),
    "@import": re.compile(r"@import", re.I),
    "url() 外部资源": re.compile(r"url\(\s*['\"]?(https?:|//)", re.I),
    "iframe": re.compile(r"<iframe", re.I),
    "fetch/XHR": re.compile(r"\b(fetch\s*\(|XMLHttpRequest)", re.I),
}


def main() -> None:
    template = TEMPLATE.read_text(encoding="utf-8")
    core = CORE.read_text(encoding="utf-8").strip()
    payload = json.loads(PAYLOAD.read_text(encoding="utf-8"))
    metrics = json.loads(METRICS.read_text(encoding="utf-8"))

    meta = dict(payload["meta"])
    meta["buildDate"] = dt.date.today().strftime("%Y-%m-%d")
    data = {
        "rows": payload["rows"],
        "targets": payload["targets"],
        "shipments": payload["shipments"],
        "perLine": payload["perLine"],
        "meta": meta,
        "metrics": metrics,
    }
    blob = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    blob = blob.replace("<", "\\u003c").replace(">", "\\u003e")  # 防止 </script> 提前闭合
    assert "</script" not in core.lower(), "核心脚本含有会提前闭合的片段"

    assert template.count("/*__COREJS__*/") == 1 and template.count("/*__PAYLOAD__*/") == 1
    html = template.replace("/*__COREJS__*/", core)
    html = html.replace("/*__PAYLOAD__*/", "window.REPORT_DATA = " + blob + ";")
    DEST.write_text(html, encoding="utf-8")

    text = DEST.read_text(encoding="utf-8")
    problems = []
    if "__COREJS__" in text or "__PAYLOAD__" in text:
        problems.append("模板占位符未替换完")
    for i in REQUIRED_IDS:
        if f'id="{i}"' not in text:
            problems.append(f"缺少固定 id: {i}")
    for name, pat in EXTERNAL_PATTERNS.items():
        hits = pat.findall(text)
        if hits:
            problems.append(f"发现外部引用[{name}]: {str(hits[:3])}")
    if "合成验收数据" not in text:
        problems.append("缺少合成验收数据标注")

    print(f"写入 {DEST.relative_to(ROOT)}  {DEST.stat().st_size:,} bytes")
    print(f"内联生产记录 {len(data['rows'])} 条 / 发货记录 {len(data['shipments'])} 条 / 产线目标 {len(data['targets'])} 条")
    print(f"构建日期 {meta['buildDate']}")
    if problems:
        print("\n[FAIL] 构建自检:")
        for p in problems:
            print("  -", p)
        raise SystemExit(1)
    print("[OK] 构建自检通过：无外部引用、必需 id 齐全、合成数据标注存在")


if __name__ == "__main__":
    main()
