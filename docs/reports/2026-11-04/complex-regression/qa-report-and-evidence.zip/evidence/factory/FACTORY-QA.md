# 工厂生产运行报表真实端到端验收

结论：经一次同会话模型恢复及应用预览修复后，三个核心交付文件的独立数值验算、离线交互和生产版本内嵌预览均通过。首轮在产出 HTML 后运行失败的事实保留；原始文件未被人工修补，恢复前后及最终下载的三个文件 SHA256 相同。

## 环境与真实执行

- 初始开发前端 `http://127.0.0.1:5173`，后端 `http://127.0.0.1:8000`；最终复验使用8000生产静态入口，bundle `/assets/index-7OjuiY0u.js`。独立一次性验收数据目录，实际 Docker 沙箱。
- Browser JavaScript工具经主代理发现后不可调用，按授权使用已有Playwright/Chromium；没有模拟API响应。
- 实际模型 `qwen3.8-flash`，Responses API，未更换模型，无模拟模型响应。
- 会话 `f8d6980b74be40658b09c5569f153640`。
- 首轮 `822c45733ce447fca53dbcae87f64c82`：2026-11-04 00:45:47 UTC 提交，880.426 秒后 failed；提示“模型返回了无法执行的工具请求或响应格式”。底层具体原因未保留，不能断言为某项提供方协议缺失，也不是900秒超时。
- 唯一恢复轮 `32c842db3ee9480b9734bdca7e3e2616`：149.982 秒 completed，只读复核核心产物并补充终答/能耗口径；已有 progress.md 更新完成状态。
- 已上传两份明确标注合成性质的 CSV/XLSX；独立 oracle 留在 `private/`，从未上传到模型。

## 数值验算：173/173 通过

| 项目 | 独立预期与模型一致 |
|---|---:|
| 原始/去重后/重复记录 | 99 / 96 / 3 |
| 停机缺失/电耗缺失/零产量记录 | 2 / 3 / 1 |
| 计划/实际产量，吨 | 8664 / 8584 |
| 合格/不良，吨 | 8414 / 170 |
| 加权良品率/达成率 | 98.02% / 99.08% |
| 有效能耗记录/有效产量/有效电耗 | 92 / 8289 吨 / 330557 kWh |
| 单位电耗 | 39.88 kWh/吨 |
| 已知停机/已知电耗 | 3663 分钟 / 331197 kWh |
| 发货量/收入 | 7972 吨 / 23023425 元 |
| 产量第一 | 混合D线，2637 吨 |

还逐项验证了四条产线排名、12天每日聚合、原始11列、96条清洗数据的全部字段，确认空缺没有填零、零产量没有删除。结果见 `oracle-validation.json`。

## 浏览器交互与视觉

原始 HTML 未修改。Playwright 在断网浏览器上下文中载入原文件内容：14/14 检查通过，另验证能耗/品质切换。

- 全量实际8584吨、计划8664吨、96条；筛选制粒A线为1989吨/24条，再选白班为975吨/12条、质量98.15%；图表同步改变。
- 进一步选2026-10-19：71吨/1条；空筛选明确显示0条与“数据不足/—”，没有NaN/Infinity；重置恢复96条。
- 实际点击“导出当前明细 CSV”并得到浏览器下载文件，12个记录编号与独立 oracle 完全一致。
- 三个真实 SVG 图表分别为产线计划与实际、每日趋势、单位能耗/品质目标对比，含可读标签、坐标与单位；页内12项自检一致。
- 桌面1440×1000、手机390×844均无页面横向溢出，手机筛选与重置可用。
- 离线零远程请求、零JavaScript/console错误。
- 管理 Chromium 禁止 `file://` 导航，实际离线测试使用同一未改动HTML的 `page.setContent`；未关闭浏览器策略，未声称测试了文件管理器双击动作。

## 运行中预览、历史与恢复

- 实际运行中点击上传 CSV 和新生成 progress.md，两个预览均正常；每次预览前后API状态均为 running。
- 重新打开页面后，首轮23个工具节点与API事件一一对应、无重复；恢复轮548事件跨500分页载入后4个工具完整，最终答案独立显示且只出现一次。
- 恢复终答逐条解释 SC0011/SC0039/SC0074 的缺失电耗以及 SC0062 的零产量；331197−330557=640，正确330557÷8289=39.88，错误331197÷8584=38.58，均与原始CSV独立验算一致。
- 恢复浏览器会话在开发服务器代码修复期间记录过一次React hook异常并重置了会话选择；稳定新页面历史回放正常。不能仅凭时间重合断言是HMR导致，错误原文保留于 `recovery/report.json`。

## 生产静态版本最终复验

`preview-production-final.json` 全部通过：原始三段脚本完整执行、同一HTML在opaque iframe中实际筛选/重置（8584→975→8584）、外层下载按钮得到与原始HTML相同字节；手机再次筛选得到975吨、重置恢复8584，iframe viewport与document宽度均360px，无横向溢出。生产页无pageerror、consoleerror或HMR hook异常。

真实点击iframe内CSV导出没有下载，这是保留 `sandbox=allow-scripts`、不加入allow-downloads的预览限制；独立HTML内该按钮已实际下载正确12行CSV。最终生产复验同时确认“如需使用网页内的导出功能，请先下载 HTML 文件，再用浏览器打开。”提示真实可见，保留隔离边界。

## 工具审计与暴露的问题

首轮209事件、23工具，全部started/terminal按call_id唯一配对且严格有序；实际成功19、失败4。恢复轮548事件、4工具全部成功。

| 首轮失败 | 实际结果 | 恢复情况 |
|---|---|---|
| exec_command 使用 file 命令 | 退出127，命令不存在 | 改用head/tail/Python读取成功 |
| write_stdin 使用不存在会话1 | 退出1 | 放弃无效会话，后续独立命令继续 |
| apply_patch 缺少Begin Patch | 纯文本拒绝 | 改为完整补丁成功 |
| apply_patch Add File缺行前缀 | 纯文本拒绝 | 改heredoc写核心并Node自检成功 |

逐工具ID、参数、输出、起止时间、耗时、实际退出码、API状态与恢复分类见 `audit-independent.json`、`tool-audit.json`、`tool-audit-table.md`；恢复轮相应文件在 `recovery/`。

业务问题证据：

1. 两个patch错误原API没有failed状态，UI仅“已返回”；exec127/write_stdin1明确显示失败。主代理已单独修复SDK异常状态传播，首轮保留修复前证据。
2. 模型把report_payload.json从outputs移走后，旧artifact仍在文件空间/API列表，下载404。修复前证据 `download-status-before-fix.json`。最终API列表已移除该旧记录，六个真实输出下载全部200，证据 `download-status.json`。
3. 应用HTML净化器把原始三段script删除为一段数据脚本，核心计算及交互消失，内嵌预览KPI全部“—”。同一原始HTML离线所有交互正常。修复前证据 `preview-diagnostic.json`、`preview-sanitized.html`、`screenshots/app-preview-initialization-failure.png`。修复后同一原始HTML已在生产8000通过桌面/手机和真实交互复验，未改写模型文件。

## 主要文件与截图

- 核心产物：`downloads/factory_report.html`、`downloads/metrics.json`、`downloads/cleaned_production.csv`。
- 首轮原产物留档：`attempt-1-downloads/`；校验摘要：`attempt-1-manifest.json`、`recovery/answer-validation.json`。
- 桌面KPI：`screenshots/baseline-desktop-initial.png`；三图：`screenshots/baseline-charts.png`、`screenshots/baseline-energy-ranking.png`。
- 手机：`screenshots/baseline-mobile-initial.png`、`screenshots/baseline-mobile-filtered.png`。
- 运行中预览：`screenshots/01-upload-during-running.png`、`screenshots/02-generated-during-running.png`。
- 首轮真实失败：`screenshots/03-run-final.png`；恢复终答：`screenshots/recovered-final-answer.png`。

- 生产修复后真实应用图表：`screenshots/production-final-app-preview-charts.png`；手机筛选KPI：`screenshots/production-final-app-preview-mobile-filtered.png`。

最终静态版复测时间：2026-11-04 01:31:48–01:31:54 UTC；bundle SHA256 `8e04ebb718d9306a2773e7215f88e6deecec8b34be2d4c4b74bfbf27efb9067d`；HTML SHA256 `f7588165b8c259291b9f350b57e050d7112cbffb3ecd7d6e1f392c88e48ae11f`，与模型首轮原件完全一致。
