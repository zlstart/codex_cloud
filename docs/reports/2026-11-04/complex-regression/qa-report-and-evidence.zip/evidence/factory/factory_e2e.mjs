import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from '/workspace/codex_cloud/frontend/node_modules/playwright/index.mjs';

const root='/workspace/qa-artifacts/factory';
const baseURL='http://127.0.0.1:5173';
const mode=process.argv[2]||'run';
const title='复杂工厂运行报表·真实模型验收';
const uploadNames=['2026年10月生产明细.csv','2026年10月经营补充.xlsx'];
const redact=s=>String(s).replace(/\b(cookie|authorization|x-api-key|api-key):[^\r\n]*/gi,'$1: [redacted]').replace(/famsun_session=[A-Za-z0-9_-]+/g,'famsun_session=[redacted]');
await mkdir(path.join(root,'screenshots'),{recursive:true});
await mkdir(path.join(root,'downloads'),{recursive:true});
const save=async(name,data)=>writeFile(path.join(root,name),redact(typeof data==='string'?data:JSON.stringify(data,null,2))+'\n');
let report;
try{report=JSON.parse(await readFile(path.join(root,'report.json'),'utf8'));}catch{report={scenario:'factory-interactive-html',live_provider:true,synthetic_inputs:true,ui_base_url:baseURL,browser_path:'Playwright; Browser JavaScript tools were unavailable after tool discovery',started_at:new Date().toISOString(),runs:[],previews:[],browser_errors:[],console_errors:[],checks:[]};}
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const context=await browser.newContext({baseURL,storageState:'/workspace/qa-runtime/auth/admin-state.json',acceptDownloads:true,viewport:{width:1440,height:1000}});
const page=await context.newPage();
page.setDefaultTimeout(20000);
page.on('pageerror',e=>report.browser_errors.push(redact(e.message)));
page.on('console',e=>{if(e.type()==='error')report.console_errors.push(redact(e.text()));});
const persist=()=>save('report.json',report);
const shot=async(name)=>{const target=path.join(root,'screenshots',name+'.png');await page.screenshot({path:target,animations:'disabled',fullPage:false});return target;};
async function get(url){const r=await context.request.get(url);assert.equal(r.status(),200,'GET '+url);return r.json();}
async function events(id){let after=0,all=[];for(;;){const p=await get(`/api/runs/${id}/timeline?after=${after}&limit=1000`);all.push(...p.events);if(!p.has_more)break;assert.ok(p.next_cursor>after);after=p.next_cursor;}assert.ok(all.every((e,i)=>!i||e.sequence>all[i-1].sequence));return all;}
async function preview(file,label,runId){
 const record={file_name:file.name,file_id:file.id,label,started_at:new Date().toISOString()};
 try{
  if(runId)record.run_before=await get('/api/runs/'+runId);
  const toggle=page.locator('.workspace-toggle');if(await toggle.count()&&!/\bactive\b/.test(await toggle.getAttribute('class')||''))await toggle.click();
  await page.getByRole('button',{name:`预览 ${file.name}`,exact:true}).first().click();
  const dialog=page.getByRole('dialog');await dialog.waitFor();
  await page.waitForFunction(()=>document.querySelector('.preview-body')?.getAttribute('aria-busy')==='false');
  record.text=await dialog.innerText();record.alerts=await dialog.getByRole('alert').allTextContents();record.kind=await dialog.locator('.preview-body').getAttribute('class');
  record.screenshot=await shot(label);
  if(runId){record.run_after=await get('/api/runs/'+runId);record.remained_running=record.run_before.status==='running'&&record.run_after.status==='running';}
  await page.keyboard.press('Escape');await dialog.waitFor({state:'hidden'});
 }catch(e){record.error=redact(e.message);await shot(label+'-error').catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}
 report.previews.push(record);await persist();return record;
}
function audit(timeline){
 const started=timeline.filter(e=>e.type==='tool.started');
 const finished=timeline.filter(e=>['tool.completed','tool.failed'].includes(e.type));
 const calls=started.map(s=>{const matches=finished.filter(e=>e.data.call_id===s.data.call_id);const f=matches.at(-1);const out=String(f?.data.output??'');const exitMatch=out.match(/Process exited with code (-?\d+)/);const exitCode=exitMatch?Number(exitMatch[1]):null;const failed=f?.type==='tool.failed'||['failed','error','cancelled'].includes(f?.data.status)||(exitCode!==null&&exitCode!==0)||(s.data.name==='apply_patch'&&/^(apply_patch input must|Invalid |Failed to )/.test(out));return{call_id:s.data.call_id,name:s.data.name,started_sequence:s.sequence,finished_sequence:f?.sequence,started_at:s.created_at,finished_at:f?.created_at,duration_seconds:f?(Date.parse(f.created_at)-Date.parse(s.created_at))/1000:null,terminal_count:matches.length,event_status:f?.data.status??null,actual_exit_code:exitCode,status:failed?'failed':f?'completed':'unpaired',arguments:s.data.arguments,output:f?.data.output,parent_call_id:s.data.parent_call_id};});
 for(const c of calls.filter(c=>c.status==='failed'))c.later_success_same_tool=calls.filter(n=>n.name===c.name&&n.status==='completed'&&n.started_sequence>c.started_sequence).map(n=>n.call_id);
 return{event_count:timeline.length,ordered:timeline.every((e,i)=>!i||e.sequence>timeline[i-1].sequence),event_types:Object.fromEntries([...new Set(timeline.map(e=>e.type))].map(t=>[t,timeline.filter(e=>e.type===t).length])),started_tools:started.length,terminal_tools:finished.length,unpaired: calls.filter(c=>c.terminal_count!==1).map(c=>c.call_id),orphan_terminals:finished.filter(f=>!started.some(s=>s.data.call_id===f.data.call_id)).map(f=>f.data.call_id),failed_tools:calls.filter(c=>c.status==='failed').length,calls};
}
try{
 await page.goto('/');await page.getByLabel('发送给丰尚助手的消息').waitFor();
 const settings=await get('/api/settings');report.settings={provider:{configured:settings.provider.configured,model:settings.provider.model,api_mode:settings.provider.api_mode},sandbox:settings.sandbox,limits:settings.limits};
 assert.equal(settings.provider.api_mode,'responses');
 if(!report.session_id){
  await page.getByRole('button',{name:/新建对话/}).click();
  const created=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/sessions'&&r.request().method()==='POST');
  await page.locator('.composer input[type="file"]').setInputFiles(uploadNames.map(n=>path.join(root,'inputs',n)));
  const response=await created;assert.equal(response.status(),201);report.session_id=(await response.json()).id;
  await page.getByText('已上传 2 个文件，可以开始提问了。',{exact:true}).waitFor();
  await page.locator('.session-row.selected').hover();await page.locator('.session-row.selected .session-more').click();
  await page.getByRole('button',{name:'重命名',exact:true}).click();await page.getByLabel('对话名称',{exact:true}).fill(title);await page.getByRole('button',{name:'保存名称',exact:true}).click();
  report.uploads=(await get('/api/sessions/'+report.session_id)).files.filter(f=>f.kind==='upload');
  assert.equal(report.uploads.length,2);report.upload_screenshot=await shot('00-uploaded-inputs');await persist();
 }else{const detail=await get('/api/sessions/'+report.session_id);await page.locator('.session-select').filter({hasText:detail.session.title}).first().click();}
 if(mode==='prepare'){console.log('PREPARED '+report.session_id);await persist();}
 else{
  let run=report.runs.at(-1);
  if(!run){
   const prompt=await readFile(path.join(root,'prompt.txt'),'utf8');await page.getByLabel('发送给丰尚助手的消息').fill(prompt);
   const response=page.waitForResponse(r=>/\/api\/sessions\/[^/]+\/runs$/.test(new URL(r.url()).pathname)&&r.request().method()==='POST');
   const submitted=Date.now();await page.getByRole('button',{name:'发送消息',exact:true}).click();const r=await response;assert.equal(r.status(),201);const state=await r.json();
   run={run_id:state.id,session_id:state.session_id,submitted_at:new Date(submitted).toISOString(),model:settings.provider.model,status:state.status};report.runs.push(run);await persist();console.log('SUBMITTED '+JSON.stringify(run));
  }
  const deadline=Date.now()+1050*1000;let lastLog=0;let timeline=[];
  while(Date.now()<deadline){
   const state=await get('/api/runs/'+run.run_id);timeline=await events(run.run_id);run.status=state.status;run.error=state.error;run.event_count=timeline.length;run.elapsed_seconds=(Date.now()-Date.parse(run.submitted_at))/1000;
   await save('events.json',timeline);await save('run-state.json',state);await persist();
   if(state.status==='running'&&!report.previews.some(p=>p.label==='01-upload-during-running'))await preview(report.uploads[0],'01-upload-during-running',run.run_id);
   if(state.status==='running'&&!report.previews.some(p=>p.label==='02-generated-during-running')){
    const detail=await get('/api/sessions/'+report.session_id);const file=detail.files.find(f=>f.kind==='output');if(file)await preview(file,'02-generated-during-running',run.run_id);
   }
   if(Date.now()-lastLog>20000){console.log('PROGRESS '+JSON.stringify({status:run.status,events:timeline.length,elapsed_seconds:Math.round(run.elapsed_seconds),tools:timeline.filter(e=>e.type==='tool.completed').length}));lastLog=Date.now();}
   if(['completed','failed','cancelled'].includes(state.status))break;
   await page.waitForTimeout(2000);
  }
  run.finished_at=new Date().toISOString();run.duration_seconds=(Date.now()-Date.parse(run.submitted_at))/1000;
  const detail=await get('/api/sessions/'+report.session_id);report.files=detail.files;
  report.answer=detail.messages.filter(m=>m.run_id===run.run_id&&m.role==='assistant').map(m=>m.content).join('\n\n');
  await save('answer.md',report.answer);await save('session.json',detail);await save('tool-audit.json',audit(timeline));
  await page.waitForTimeout(800);report.final_screenshot=await shot('03-run-final');
  const toolsToggle=page.getByRole('button',{name:'执行记录',exact:true}).last();if(await toolsToggle.count()){await toolsToggle.click();await shot('04-tool-timeline');}
  report.downloads=[];for(const file of detail.files.filter(f=>f.kind==='output')){const res=await context.request.get(file.url+'?download=true');report.downloads.push({name:file.name,status:res.status()});if(res.status()!==200)continue;await writeFile(path.join(root,'downloads',file.name),await res.body());}
  const html=detail.files.find(f=>f.name==='factory_report.html');if(html)await preview(html,'05-report-preview');
  await persist();console.log('FINISHED '+JSON.stringify({run_id:run.run_id,status:run.status,seconds:run.duration_seconds,files:detail.files.map(f=>f.name),failed_tools:audit(timeline).failed_tools}));
 }
}catch(e){report.harness_error=redact(e.message);await shot('harness-error').catch(()=>{});await persist();console.error(redact(e.message));process.exitCode=1;}finally{await browser.close();}
